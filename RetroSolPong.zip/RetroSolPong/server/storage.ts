import { users, type User, type InsertUser, type Transaction } from "@shared/schema";
import { Transaction as TransactionType } from "@shared/types";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createTransaction(transaction: TransactionType): Promise<void>;
  getTransactionsByWallet(walletAddress: string): Promise<TransactionType[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private transactions: TransactionType[];
  currentId: number;

  constructor() {
    this.users = new Map();
    this.transactions = [];
    this.currentId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { 
      ...insertUser, 
      id,
      walletAddress: insertUser.walletAddress || null 
    };
    this.users.set(id, user);
    return user;
  }

  async createTransaction(transaction: TransactionType): Promise<void> {
    // Add a transaction ID if not present
    if (!transaction.id) {
      transaction.id = this.transactions.length + 1;
    }
    this.transactions.push(transaction);
  }

  async getTransactionsByWallet(walletAddress: string): Promise<TransactionType[]> {
    return this.transactions.filter(tx => tx.walletAddress === walletAddress);
  }
}

export const storage = new MemStorage();
