import { EventEmitter } from "events";
import { PaddlePosition, BallPosition, Scores, GameState } from "@shared/types";

export class GameRoom extends EventEmitter {
  gameId: string;
  player1: string;
  player2: string | null;
  wagerAmount: number;
  status: 'waiting' | 'starting' | 'active' | 'ended';
  startTime: number;
  
  private player1Score: number;
  private player2Score: number;
  private player1PaddlePos: number;
  private player2PaddlePos: number;
  private ballPosX: number;
  private ballPosY: number;
  private ballSpeedX: number;
  private ballSpeedY: number;
  private gameInterval: NodeJS.Timeout | null;
  private disconnectionTimers: Map<string, NodeJS.Timeout>;
  
  constructor(gameId: string, player1: string, wagerAmount: number) {
    super();
    this.gameId = gameId;
    this.player1 = player1;
    this.player2 = null;
    this.wagerAmount = wagerAmount;
    this.status = 'waiting';
    this.startTime = Date.now();
    
    // Game state
    this.player1Score = 0;
    this.player2Score = 0;
    this.player1PaddlePos = 40; // Middle position (0-80 range)
    this.player2PaddlePos = 40;
    this.ballPosX = 50; // Middle of game area
    this.ballPosY = 50;
    this.ballSpeedX = (Math.random() > 0.5 ? 1 : -1) * 1.5;
    this.ballSpeedY = (Math.random() * 2 - 1) * 1;
    this.gameInterval = null;
    this.disconnectionTimers = new Map();
  }
  
  // Add player 2 to the game
  addPlayer2(player2: string): void {
    if (this.status !== 'waiting') {
      throw new Error('Game is not in waiting state');
    }
    
    this.player2 = player2;
    this.status = 'starting';
  }
  
  // Start the game
  startGame(): void {
    if (this.status !== 'starting' || !this.player2) {
      throw new Error('Game is not ready to start');
    }
    
    this.status = 'active';
    
    // Start the game loop
    this.gameInterval = setInterval(() => {
      this.updateGameState();
    }, 50); // 20 fps
  }
  
  // Stop the game
  stopGame(): void {
    if (this.gameInterval) {
      clearInterval(this.gameInterval);
      this.gameInterval = null;
    }
    
    // Clear any disconnection timers
    for (const timer of this.disconnectionTimers.values()) {
      clearTimeout(timer);
    }
    
    this.status = 'ended';
  }
  
  // Update player paddle position
  updatePlayerPaddle(playerWalletAddress: string, position: number): void {
    if (this.status !== 'active') return;
    
    // Clamp position between 0 and 80 (to account for paddle height)
    const clampedPosition = Math.max(0, Math.min(80, position));
    
    if (playerWalletAddress === this.player1) {
      this.player1PaddlePos = clampedPosition;
    } else if (playerWalletAddress === this.player2) {
      this.player2PaddlePos = clampedPosition;
    }
  }
  
  // Handle player disconnection
  playerDisconnected(playerWalletAddress: string): void {
    if (this.status !== 'active') return;
    
    // Set a timer to end the game if the player doesn't reconnect within 15 seconds
    const timer = setTimeout(() => {
      this.emit('playerDisconnectedTooLong', playerWalletAddress);
    }, 15000);
    
    this.disconnectionTimers.set(playerWalletAddress, timer);
  }
  
  // Handle player reconnection
  playerReconnected(playerWalletAddress: string): void {
    const timer = this.disconnectionTimers.get(playerWalletAddress);
    
    if (timer) {
      clearTimeout(timer);
      this.disconnectionTimers.delete(playerWalletAddress);
    }
  }
  
  // Get current game state
  getState(): GameState {
    return {
      gameId: this.gameId,
      status: this.status,
      startTime: this.startTime,
      paddlePositions: {
        player1: this.player1PaddlePos,
        player2: this.player2PaddlePos
      },
      ballPosition: {
        x: this.ballPosX,
        y: this.ballPosY
      },
      scores: {
        player1: this.player1Score,
        player2: this.player2Score
      },
      wagerAmount: this.wagerAmount
    };
  }
  
  // Update game state - game loop
  private updateGameState(): void {
    // Skip if game is not active
    if (this.status !== 'active' || !this.player2) return;
    
    // Update ball position
    let ballPrevX = this.ballPosX;
    let ballPrevY = this.ballPosY;
    this.ballPosX += this.ballSpeedX;
    this.ballPosY += this.ballSpeedY;
    
    let hitPaddle = false;
    let hitWall = false;
    let scored = false;
    
    // Check collisions with top and bottom walls
    if (this.ballPosY <= 0 || this.ballPosY >= 100) {
      this.ballSpeedY = -this.ballSpeedY;
      hitWall = true;
      
      // Clamp Y position
      if (this.ballPosY < 0) this.ballPosY = 0;
      if (this.ballPosY > 100) this.ballPosY = 100;
    }
    
    // Check collision with left paddle (player 1)
    if (this.ballPosX <= 3 && ballPrevX > 3 && 
        this.ballPosY >= this.player1PaddlePos && 
        this.ballPosY <= this.player1PaddlePos + 20) {
      this.ballSpeedX = -this.ballSpeedX;
      // Add random Y velocity based on where the ball hit the paddle
      const hitPosition = (this.ballPosY - this.player1PaddlePos) / 20; // 0 to 1
      this.ballSpeedY = (hitPosition - 0.5) * 3; // -1.5 to 1.5
      hitPaddle = true;
    }
    
    // Check collision with right paddle (player 2)
    if (this.ballPosX >= 97 && ballPrevX < 97 && 
        this.ballPosY >= this.player2PaddlePos && 
        this.ballPosY <= this.player2PaddlePos + 20) {
      this.ballSpeedX = -this.ballSpeedX;
      // Add random Y velocity based on where the ball hit the paddle
      const hitPosition = (this.ballPosY - this.player2PaddlePos) / 20; // 0 to 1
      this.ballSpeedY = (hitPosition - 0.5) * 3; // -1.5 to 1.5
      hitPaddle = true;
    }
    
    // Check if ball went beyond left or right boundaries (scoring)
    if (this.ballPosX < 0) {
      // Player 2 scores
      this.player2Score++;
      scored = true;
      this.resetBall();
    } else if (this.ballPosX > 100) {
      // Player 1 scores
      this.player1Score++;
      scored = true;
      this.resetBall();
    }
    
    // Emit update event
    this.emit('update', {
      paddlePositions: {
        player1: this.player1PaddlePos,
        player2: this.player2PaddlePos
      },
      ballPosition: {
        x: this.ballPosX,
        y: this.ballPosY,
        hitPaddle,
        hitWall,
        scored
      },
      scores: {
        player1: this.player1Score,
        player2: this.player2Score
      }
    });
    
    // Check win condition (first to 5 points)
    if (this.player1Score >= 5 || this.player2Score >= 5) {
      const winner = this.player1Score >= 5 ? this.player1 : this.player2;
      const loser = winner === this.player1 ? this.player2 : this.player1;
      
      // End the game
      this.stopGame();
      this.emit('end', winner, loser);
    }
  }
  
  // Reset ball to center after scoring
  private resetBall(): void {
    this.ballPosX = 50;
    this.ballPosY = 50;
    
    // Randomize ball direction
    const angle = Math.random() * 2 * Math.PI;
    this.ballSpeedX = Math.cos(angle) * 1.5;
    this.ballSpeedY = Math.sin(angle) * 1;
    
    // Ensure ball is moving left or right
    if (Math.abs(this.ballSpeedX) < 0.5) {
      this.ballSpeedX = this.ballSpeedX < 0 ? -1 : 1;
    }
  }
}
