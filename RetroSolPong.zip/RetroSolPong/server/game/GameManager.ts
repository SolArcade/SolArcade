import { EventEmitter } from "events";
import { GameRoom } from "./GameRoom";
import { PaddlePosition, BallPosition, Scores } from "@shared/types";

export class GameManager extends EventEmitter {
  private games: Map<string, GameRoom>;
  private matchmakingQueue: { gameId: string, wagerAmount: number }[];
  private playerGameMap: Map<string, string[]>; // maps player walletAddress to array of gameIds
  
  constructor() {
    super();
    this.games = new Map();
    this.matchmakingQueue = [];
    this.playerGameMap = new Map();
  }
  
  // Create a new game with a player
  createGame(gameId: string, player1: string, wagerAmount: number): GameRoom {
    const game = new GameRoom(gameId, player1, wagerAmount);
    this.games.set(gameId, game);
    
    // Add to player's game list
    this.addPlayerGame(player1, gameId);
    
    // Add game to matchmaking queue
    this.matchmakingQueue.push({ gameId, wagerAmount });
    
    // Check for potential matches
    this.checkForMatches();
    
    // Set up game event handlers
    this.setupGameEvents(game);
    
    return game;
  }
  
  // Get a game by ID
  getGame(gameId: string): GameRoom | undefined {
    return this.games.get(gameId);
  }
  
  // Remove a game
  removeGame(gameId: string): boolean {
    const game = this.games.get(gameId);
    
    if (!game) return false;
    
    // Remove from matchmaking queue if it's there
    this.matchmakingQueue = this.matchmakingQueue.filter(item => item.gameId !== gameId);
    
    // Remove from player game maps
    if (game.player1) {
      this.removePlayerGame(game.player1, gameId);
    }
    if (game.player2) {
      this.removePlayerGame(game.player2, gameId);
    }
    
    // Stop the game
    game.stopGame();
    
    // Delete the game
    return this.games.delete(gameId);
  }
  
  // Update player paddle position
  updatePlayerPaddle(gameId: string, playerWalletAddress: string, position: number): void {
    const game = this.games.get(gameId);
    
    if (!game) {
      throw new Error(`Game ${gameId} not found`);
    }
    
    game.updatePlayerPaddle(playerWalletAddress, position);
  }
  
  // Get all games for a player
  getPlayerGames(playerWalletAddress: string): GameRoom[] {
    const gameIds = this.playerGameMap.get(playerWalletAddress) || [];
    return gameIds.map(id => this.games.get(id)).filter(Boolean) as GameRoom[];
  }
  
  // Add game to player's list
  private addPlayerGame(playerWalletAddress: string, gameId: string): void {
    const playerGames = this.playerGameMap.get(playerWalletAddress) || [];
    playerGames.push(gameId);
    this.playerGameMap.set(playerWalletAddress, playerGames);
  }
  
  // Remove game from player's list
  private removePlayerGame(playerWalletAddress: string, gameId: string): void {
    const playerGames = this.playerGameMap.get(playerWalletAddress) || [];
    const updatedGames = playerGames.filter(id => id !== gameId);
    
    if (updatedGames.length > 0) {
      this.playerGameMap.set(playerWalletAddress, updatedGames);
    } else {
      this.playerGameMap.delete(playerWalletAddress);
    }
  }
  
  // Check for potential matches in the queue
  private checkForMatches(): void {
    if (this.matchmakingQueue.length < 2) return;
    
    // Group games by wager amount
    const wagerGroups = new Map<number, string[]>();
    
    for (const { gameId, wagerAmount } of this.matchmakingQueue) {
      const games = wagerGroups.get(wagerAmount) || [];
      games.push(gameId);
      wagerGroups.set(wagerAmount, games);
    }
    
    // Check each wager group for potential matches
    for (const [wagerAmount, gameIds] of wagerGroups.entries()) {
      if (gameIds.length >= 2) {
        const gameId1 = gameIds[0];
        const gameId2 = gameIds[1];
        
        const game1 = this.games.get(gameId1);
        const game2 = this.games.get(gameId2);
        
        if (game1 && game2) {
          // Match these two players
          this.matchGames(game1, game2);
          
          // Remove matched games from queue
          this.matchmakingQueue = this.matchmakingQueue.filter(
            item => item.gameId !== gameId1 && item.gameId !== gameId2
          );
        }
      }
    }
  }
  
  // Match two players in a game
  private matchGames(game1: GameRoom, game2: GameRoom): void {
    // Keep game1 and add player2 from game2
    const matchedGame = game1;
    const player2 = game2.player1;
    
    // Add player2 to game1
    matchedGame.addPlayer2(player2);
    
    // Remove game2 and update player2's game mapping
    this.games.delete(game2.gameId);
    this.removePlayerGame(player2, game2.gameId);
    this.addPlayerGame(player2, matchedGame.gameId);
    
    // Emit game ready event
    this.emit('gameReady', matchedGame.gameId, matchedGame.player1, matchedGame.player2);
    
    // Start the game after a short delay
    setTimeout(() => {
      matchedGame.startGame();
      this.emit('gameStart', matchedGame.gameId, matchedGame.player1, matchedGame.player2);
    }, 3000);
  }
  
  // Set up event handlers for a game
  private setupGameEvents(game: GameRoom): void {
    game.on('update', (updateData: { paddlePositions?: PaddlePosition, ballPosition?: BallPosition, scores?: Scores }) => {
      if (game.player1 && game.player2) {
        this.emit('gameUpdate', game.gameId, game.player1, game.player2, updateData);
      }
    });
    
    game.on('end', (winner: string, loser: string) => {
      this.emit('gameEnd', game.gameId, winner, loser, game.wagerAmount);
      this.removeGame(game.gameId);
    });
    
    game.on('playerDisconnectedTooLong', (disconnectedPlayer: string) => {
      const otherPlayer = disconnectedPlayer === game.player1 ? game.player2 : game.player1;
      
      if (otherPlayer) {
        // End the game with the connected player as winner
        this.emit('gameEnd', game.gameId, otherPlayer, disconnectedPlayer, game.wagerAmount);
        this.removeGame(game.gameId);
      }
    });
  }
}
