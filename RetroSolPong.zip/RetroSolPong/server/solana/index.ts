import { Connection, PublicKey, LAMPORTS_PER_SOL, Transaction, SystemProgram } from '@solana/web3.js';

// House wallet address
const HOUSE_WALLET_ADDRESS = '45GGPAkoxwisBWj5YtHj1BH1tekmoFbRigSNJ4fT9UD2';

// QuickNode RPC endpoint with priority fees
const RPC_ENDPOINT = 'https://solemn-orbital-energy.solana-mainnet.quiknode.pro/d2b2c179d598f4724ea95f9544944ecb266843fc/';

// Create a connection to the Solana network
export const createConnection = (): Connection => {
  return new Connection(RPC_ENDPOINT, {
    commitment: 'confirmed',
    confirmTransactionInitialTimeout: 60000,
  });
};

// Get SOL balance for a wallet
export const getWalletBalance = async (walletAddress: string): Promise<number> => {
  try {
    const connection = createConnection();
    const publicKey = new PublicKey(walletAddress);
    const balance = await connection.getBalance(publicKey);
    return balance / LAMPORTS_PER_SOL; // Convert lamports to SOL
  } catch (error) {
    console.error('Error getting wallet balance:', error);
    throw error;
  }
};

// Check if a wallet has enough SOL for a wager
export const hasEnoughBalance = async (walletAddress: string, wagerAmount: number): Promise<boolean> => {
  try {
    const balance = await getWalletBalance(walletAddress);
    return balance >= wagerAmount;
  } catch (error) {
    console.error('Error checking balance:', error);
    return false;
  }
};

// Calculate reward for a winning game
export const calculateReward = (wagerAmount: number): number => {
  // Winner gets 1.5x their wager
  return wagerAmount * 1.5;
};

// NOTE: In a real implementation, this would interact with a Solana wallet
// to send transactions. For this example, we're just simulating the process.

// Send SOL from house wallet to winner
export const sendReward = async (walletAddress: string, amount: number): Promise<boolean> => {
  try {
    console.log(`[MOCK] Sending ${amount} SOL reward to ${walletAddress}`);
    // This would actually send a transaction in a real implementation
    return true;
  } catch (error) {
    console.error('Error sending reward:', error);
    return false;
  }
};

// Refund a player's wager
export const refundWager = async (walletAddress: string, amount: number): Promise<boolean> => {
  try {
    console.log(`[MOCK] Refunding ${amount} SOL to ${walletAddress}`);
    // This would actually send a transaction in a real implementation
    return true;
  } catch (error) {
    console.error('Error refunding wager:', error);
    return false;
  }
};

// Verify a transaction on the Solana blockchain
export const verifyTransaction = async (transactionId: string, expectedAmount: number, sender: string, receiver: string = HOUSE_WALLET_ADDRESS): Promise<boolean> => {
  try {
    console.log(`[MOCK] Verifying transaction ${transactionId} for ${expectedAmount} SOL`);
    // This would actually verify the transaction in a real implementation
    return true;
  } catch (error) {
    console.error('Error verifying transaction:', error);
    return false;
  }
};
