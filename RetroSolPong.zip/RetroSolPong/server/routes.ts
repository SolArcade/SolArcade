import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { GameManager } from "./game/GameManager";
import { v4 as uuidv4 } from "uuid";
import { Transaction } from "@shared/types";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Initialize game manager
  const gameManager = new GameManager();
  
  // Create WebSocket server
  const wss = new WebSocketServer({ 
    server: httpServer, 
    path: '/ws' 
  });
  
  // Map to store clients by wallet address
  const clients = new Map<string, WebSocket>();
  
  wss.on('connection', (ws) => {
    let clientWalletAddress = '';
    
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        // Handle different message types
        switch (data.type) {
          case 'auth':
            clientWalletAddress = data.publicKey;
            clients.set(clientWalletAddress, ws);
            console.log(`Client authenticated: ${clientWalletAddress}`);
            break;
            
          case 'create-game':
            if (!clientWalletAddress) {
              sendError(ws, 'Not authenticated');
              break;
            }
            
            try {
              // Record transaction
              await storage.createTransaction({
                id: 0, // Will be assigned in storage
                walletAddress: data.publicKey,
                amount: data.wagerAmount,
                type: 'game-start',
                status: 'completed',
                transactionHash: data.transactionId,
                timestamp: Date.now()
              });
              
              // Create new game
              const gameId = uuidv4();
              const game = gameManager.createGame(gameId, data.publicKey, data.wagerAmount);
              
              // Send confirmation to client
              ws.send(JSON.stringify({
                type: 'game-created',
                gameId
              }));
              
              console.log(`Game created: ${gameId} by player ${data.publicKey} with wager ${data.wagerAmount}`);
            } catch (err) {
              console.error('Error creating game:', err);
              sendError(ws, 'Failed to create game');
            }
            break;
            
          case 'update-paddle':
            if (!clientWalletAddress) {
              sendError(ws, 'Not authenticated');
              break;
            }
            
            try {
              gameManager.updatePlayerPaddle(data.gameId, clientWalletAddress, data.position);
            } catch (err) {
              console.error('Error updating paddle:', err);
              sendError(ws, 'Failed to update paddle position');
            }
            break;
            
          case 'cancel-game':
            if (!clientWalletAddress) {
              sendError(ws, 'Not authenticated');
              break;
            }
            
            try {
              const game = gameManager.getGame(data.gameId);
              
              if (!game) {
                sendError(ws, 'Game not found');
                break;
              }
              
              if (game.player1 !== clientWalletAddress) {
                sendError(ws, 'You cannot cancel this game');
                break;
              }
              
              // Record refund transaction
              await storage.createTransaction({
                id: 0, // Will be assigned in storage
                walletAddress: clientWalletAddress,
                gameId: data.gameId,
                amount: game.wagerAmount,
                type: 'refund',
                status: 'completed',
                reason: 'cancelled',
                transactionHash: data.transactionId,
                timestamp: Date.now()
              });
              
              // Cancel the game
              gameManager.removeGame(data.gameId);
              console.log(`Game cancelled: ${data.gameId} by player ${clientWalletAddress}`);
            } catch (err) {
              console.error('Error cancelling game:', err);
              sendError(ws, 'Failed to cancel game');
            }
            break;
            
          case 'reconnect':
            if (!clientWalletAddress) {
              sendError(ws, 'Not authenticated');
              break;
            }
            
            try {
              const game = gameManager.getGame(data.gameId);
              
              if (!game) {
                sendError(ws, 'Game not found or expired');
                break;
              }
              
              // Check if this player belongs to the game
              if (game.player1 !== clientWalletAddress && game.player2 !== clientWalletAddress) {
                sendError(ws, 'You are not part of this game');
                break;
              }
              
              // Re-register client connection
              clients.set(clientWalletAddress, ws);
              
              // Send current game state
              ws.send(JSON.stringify({
                type: 'reconnect-success',
                gameState: game.getState()
              }));
              
              console.log(`Player ${clientWalletAddress} reconnected to game ${data.gameId}`);
            } catch (err) {
              console.error('Error reconnecting:', err);
              sendError(ws, 'Failed to reconnect to game');
            }
            break;
        }
      } catch (err) {
        console.error('Error processing message:', err);
        sendError(ws, 'Invalid message format');
      }
    });
    
    ws.on('close', () => {
      if (clientWalletAddress) {
        clients.delete(clientWalletAddress);
        console.log(`Client disconnected: ${clientWalletAddress}`);
        
        // Check if player is in any active games
        const playerGames = gameManager.getPlayerGames(clientWalletAddress);
        
        for (const game of playerGames) {
          if (game.status === 'waiting') {
            // If game is still in matchmaking, cancel it and refund
            handleDisconnectDuringMatchmaking(game.gameId, clientWalletAddress, game.wagerAmount);
          } else if (game.status === 'active') {
            // If game is active, mark this player as temporarily disconnected
            // The game will wait for a reconnection for a short time before ending
            game.playerDisconnected(clientWalletAddress);
          }
        }
      }
    });
  });
  
  // Add API routes for transactions
  app.get('/api/transactions', async (req, res) => {
    try {
      // Get wallet address from query parameter instead of session for development
      const walletAddress = req.query.wallet as string;
      
      if (!walletAddress) {
        return res.status(400).json({ message: 'Wallet address required' });
      }
      
      const transactions = await storage.getTransactionsByWallet(walletAddress);
      
      res.json(transactions);
    } catch (error) {
      console.error('Error fetching transactions:', error);
      res.status(500).json({ message: 'Error fetching transactions' });
    }
  });
  
  // Helper function to send error message
  function sendError(ws: WebSocket, message: string) {
    ws.send(JSON.stringify({
      type: 'error',
      message
    }));
  }
  
  // Helper function to send message to a specific client
  function sendToClient(walletAddress: string, message: any) {
    const client = clients.get(walletAddress);
    if (client && client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(message));
    }
  }
  
  // Handle disconnect during matchmaking
  async function handleDisconnectDuringMatchmaking(gameId: string, walletAddress: string, wagerAmount: number) {
    try {
      // Record refund transaction
      await storage.createTransaction({
        id: 0, // Will be assigned in storage
        walletAddress,
        gameId,
        amount: wagerAmount,
        type: 'refund',
        status: 'completed',
        reason: 'disconnected',
        timestamp: Date.now()
      });
      
      // Remove the game
      gameManager.removeGame(gameId);
      console.log(`Game ${gameId} cancelled due to player ${walletAddress} disconnection`);
    } catch (err) {
      console.error('Error handling disconnection:', err);
    }
  }
  
  // Game manager event handlers
  gameManager.on('gameReady', (gameId, player1, player2) => {
    sendToClient(player1, { type: 'game-ready' });
    sendToClient(player2, { type: 'game-ready' });
  });
  
  gameManager.on('gameStart', (gameId, player1, player2) => {
    sendToClient(player1, { type: 'game-start' });
    sendToClient(player2, { type: 'game-start' });
  });
  
  gameManager.on('gameUpdate', (gameId, player1, player2, updateData) => {
    sendToClient(player1, { type: 'game-update', ...updateData });
    sendToClient(player2, { type: 'game-update', ...updateData });
  });
  
  gameManager.on('gameEnd', async (gameId, winner, loser, wagerAmount) => {
    const payoutAmount = wagerAmount * 1.5;
    
    // Record payout transaction for winner
    await storage.createTransaction({
      id: 0, // Will be assigned in storage
      walletAddress: winner,
      gameId,
      amount: payoutAmount,
      type: 'payout',
      status: 'completed',
      timestamp: Date.now()
    });
    
    // Send game end notifications
    sendToClient(winner, { 
      type: 'game-end', 
      won: true,
      payout: payoutAmount
    });
    
    sendToClient(loser, { 
      type: 'game-end', 
      won: false 
    });
    
    console.log(`Game ${gameId} ended. Winner: ${winner}, Payout: ${payoutAmount}`);
  });
  
  return httpServer;
}
