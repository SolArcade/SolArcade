import { pgTable, text, serial, integer, boolean, timestamp, jsonb, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table - modified to include wallet address
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  walletAddress: text("wallet_address").unique(),
});

// Games table
export const games = pgTable("games", {
  id: serial("id").primaryKey(),
  gameId: text("game_id").notNull().unique(),
  player1: text("player1").notNull(),
  player2: text("player2"),
  wagerAmount: doublePrecision("wager_amount").notNull(),
  status: text("status").notNull().default("waiting"),
  player1Score: integer("player1_score").notNull().default(0),
  player2Score: integer("player2_score").notNull().default(0),
  winnerWalletAddress: text("winner_wallet_address"),
  startTime: timestamp("start_time").notNull().defaultNow(),
  endTime: timestamp("end_time"),
});

// Transactions table
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  walletAddress: text("wallet_address").notNull(),
  gameId: text("game_id"),
  amount: doublePrecision("amount").notNull(),
  type: text("type").notNull(), // game-start, payout, refund
  status: text("status").notNull().default("pending"),
  reason: text("reason"), // for refunds: cancelled, disconnected
  transactionHash: text("transaction_hash"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  walletAddress: true,
});

export const insertGameSchema = createInsertSchema(games).pick({
  gameId: true,
  player1: true,
  player2: true,
  wagerAmount: true,
  status: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).pick({
  walletAddress: true,
  gameId: true,
  amount: true,
  type: true,
  status: true,
  reason: true,
  transactionHash: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertGame = z.infer<typeof insertGameSchema>;
export type Game = typeof games.$inferSelect;

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;
