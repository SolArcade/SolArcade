// Game-related types
export interface PaddlePosition {
  player1: number;
  player2: number;
}

export interface BallPosition {
  x: number;
  y: number;
  hitPaddle?: boolean;
  hitWall?: boolean;
  scored?: boolean;
}

export interface Scores {
  player1: number;
  player2: number;
}

export interface GameState {
  gameId: string;
  status: 'waiting' | 'starting' | 'active' | 'ended';
  startTime: number;
  paddlePositions?: PaddlePosition;
  ballPosition?: BallPosition;
  scores?: Scores;
  wagerAmount: number;
}

export interface GameResult {
  won: boolean;
  payout?: number;
}

// WebSocket message types
export type GameSocketMessage = 
  | { type: 'auth'; publicKey: string }
  | { type: 'create-game'; publicKey: string; wagerAmount: number; transactionId: string }
  | { type: 'game-created'; gameId: string }
  | { type: 'game-ready' }
  | { type: 'game-start' }
  | { type: 'game-update'; paddlePositions?: PaddlePosition; ballPosition?: BallPosition; scores?: Scores }
  | { type: 'game-end'; won: boolean; payout?: number }
  | { type: 'update-paddle'; gameId: string; position: number; publicKey: string }
  | { type: 'cancel-game'; gameId: string; publicKey: string; transactionId: string }
  | { type: 'reconnect'; gameId: string; publicKey: string; wagerAmount: number }
  | { type: 'reconnect-success'; gameState: GameState }
  | { type: 'error'; message: string };

// Transaction types
export interface Transaction {
  id: number;
  walletAddress: string;
  gameId?: string;
  amount: number;
  type: 'game-start' | 'payout' | 'refund';
  status: 'pending' | 'completed' | 'failed';
  reason?: 'cancelled' | 'disconnected';
  transactionHash?: string;
  timestamp: number;
}
