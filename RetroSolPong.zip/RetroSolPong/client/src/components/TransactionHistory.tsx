import { useState } from "react";
import { Separator } from "@/components/ui/separator";
import { ChevronDown, ChevronUp } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Transaction } from "@shared/types";
import { playSound } from "@/lib/audio";
import { useWallet } from "@/hooks/useWallet";

type TransactionTab = 'all' | 'games' | 'payouts' | 'refunds';

export default function TransactionHistory() {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<TransactionTab>('all');

  const { publicKey } = useWallet();
  
  const { data: transactions = [] } = useQuery<Transaction[]>({
    queryKey: ['/api/transactions', publicKey],
    queryFn: async () => {
      if (!publicKey) return [];
      const response = await fetch(`/api/transactions?wallet=${publicKey}`);
      if (!response.ok) {
        throw new Error('Failed to fetch transactions');
      }
      return response.json();
    },
    enabled: !!publicKey, // Only run query if wallet is connected
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  const togglePanel = () => {
    playSound('click');
    setIsOpen(!isOpen);
  };

  const handleTabChange = (tab: TransactionTab) => {
    playSound('click');
    setActiveTab(tab);
  };

  // Filter transactions based on active tab
  const filteredTransactions = transactions.filter(tx => {
    if (activeTab === 'all') return true;
    if (activeTab === 'games') return tx.type === 'game-start';
    if (activeTab === 'payouts') return tx.type === 'payout';
    if (activeTab === 'refunds') return tx.type === 'refund';
    return true;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-neon-green';
      case 'pending': return 'text-neon-yellow';
      case 'failed': return 'text-neon-red';
      default: return 'text-white';
    }
  };

  const formatTimestamp = (timestamp: number) => {
    const now = Date.now();
    const diff = now - timestamp;
    
    if (diff < 60000) return 'just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)} mins ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)} hours ago`;
    return `${Math.floor(diff / 86400000)} days ago`;
  };

  const getTransactionTitle = (tx: Transaction) => {
    switch (tx.type) {
      case 'game-start': return 'Game Started';
      case 'payout': return 'Game Won';
      case 'refund': return tx.reason === 'cancelled' ? 'Game Cancelled' : 'Connection Lost';
      default: return 'Transaction';
    }
  };

  const getTransactionAmount = (tx: Transaction) => {
    switch (tx.type) {
      case 'game-start': return `${tx.amount} SOL`;
      case 'payout': return `+${tx.amount} SOL`;
      case 'refund': return `Refund: ${tx.amount} SOL`;
      default: return `${tx.amount} SOL`;
    }
  };

  return (
    <div className="bg-deeper-purple border-t-2 border-neon-purple p-4">
      <button 
        onClick={togglePanel}
        className="w-full flex justify-between items-center font-orbitron text-electric-blue"
      >
        <span className="font-bold">TRANSACTION HISTORY</span>
        {isOpen ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
      </button>
      
      {isOpen && (
        <div className="mt-4">
          <div className="tabs flex border-b border-neon-purple/50">
            <button 
              onClick={() => handleTabChange('all')}
              className={`px-4 py-2 font-vt323 ${activeTab === 'all' ? 'text-hot-pink border-b-2 border-hot-pink' : 'text-white opacity-70 hover:text-electric-blue'}`}
            >
              All
            </button>
            <button 
              onClick={() => handleTabChange('games')}
              className={`px-4 py-2 font-vt323 ${activeTab === 'games' ? 'text-hot-pink border-b-2 border-hot-pink' : 'text-white opacity-70 hover:text-electric-blue'}`}
            >
              Games
            </button>
            <button 
              onClick={() => handleTabChange('payouts')}
              className={`px-4 py-2 font-vt323 ${activeTab === 'payouts' ? 'text-hot-pink border-b-2 border-hot-pink' : 'text-white opacity-70 hover:text-electric-blue'}`}
            >
              Payouts
            </button>
            <button 
              onClick={() => handleTabChange('refunds')}
              className={`px-4 py-2 font-vt323 ${activeTab === 'refunds' ? 'text-hot-pink border-b-2 border-hot-pink' : 'text-white opacity-70 hover:text-electric-blue'}`}
            >
              Refunds
            </button>
          </div>
          
          <div className="transaction-list mt-2 max-h-60 overflow-y-auto">
            {filteredTransactions.length > 0 ? (
              filteredTransactions.map((tx) => (
                <div 
                  key={tx.id}
                  className="transaction-item retro-container pixel-corners bg-deeper-purple/70 p-3 mb-2 flex justify-between items-center"
                >
                  <div>
                    <div className="font-vt323 text-electric-blue">{getTransactionTitle(tx)}</div>
                    <div className="text-xs font-orbitron text-white opacity-70">{getTransactionAmount(tx)}</div>
                  </div>
                  <div className="text-right">
                    <div className={`font-vt323 ${getStatusColor(tx.status)}`}>
                      {tx.status.charAt(0).toUpperCase() + tx.status.slice(1)}
                    </div>
                    <div className="text-xs font-orbitron text-white opacity-70">
                      {formatTimestamp(tx.timestamp)}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center p-4 text-white/50 font-vt323">
                No transactions found
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
