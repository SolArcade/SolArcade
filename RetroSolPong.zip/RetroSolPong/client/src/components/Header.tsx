import WalletConnect from "./WalletConnect";

export default function Header() {
  return (
    <header className="px-4 py-3 bg-deeper-purple border-b-2 border-neon-purple">
      <div className="flex justify-between items-center">
        <div className="flex items-center">
          <h1 className="text-2xl sm:text-3xl font-press-start text-white">
            <span className="text-electric-blue">SOL</span> 
            <span className="text-hot-pink">ARCADE</span>
          </h1>
        </div>
        
        <WalletConnect />
      </div>
    </header>
  );
}
