import { Button } from "@/components/ui/button";
import { useWallet } from "@/hooks/useWallet";
import { GAME_WAGER_OPTIONS } from "@/lib/solana";

interface WagerSelectionProps {
  onSelectWager: (amount: number) => void;
}

export default function WagerSelection({ onSelectWager }: WagerSelectionProps) {
  const { isConnected } = useWallet();

  return (
    <div className="retro-container pixel-corners bg-deeper-purple p-6 max-w-md mx-auto">
      <h2 className="font-press-start text-xl text-center text-hot-pink mb-6">SELECT WAGER</h2>
      
      {GAME_WAGER_OPTIONS.map((option) => (
        <div key={option.value} className="mb-4">
          <Button
            onClick={() => onSelectWager(option.value)}
            disabled={!isConnected}
            variant="outline"
            className="neon-button w-full px-4 py-3 bg-deeper-purple border-2 border-electric-blue text-electric-blue font-orbitron rounded pixel-corners hover:bg-neon-purple/20 transition flex justify-between items-center"
          >
            <span className="text-lg">{option.value} SOL</span>
            <span className="text-sm text-white opacity-70">Win: {(option.value * 1.5).toFixed(2)} SOL</span>
          </Button>
        </div>
      ))}
      
      {!isConnected && (
        <div className="mt-6 text-center font-vt323 text-sm text-white opacity-80">
          Connect wallet to start playing
        </div>
      )}
    </div>
  );
}
