import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";

interface GameResultModalProps {
  result: 'win' | 'lose';
  score: [number, number];
  payout?: number;
  onPlayAgain: () => void;
}

export default function GameResultModal({ result, score, payout, onPlayAgain }: GameResultModalProps) {
  const [open, setOpen] = useState(true);

  // Force modal to always be open and prevent closing except through play again
  useEffect(() => {
    if (!open) setOpen(true);
  }, [open]);

  const titleColor = result === 'win' ? 'text-neon-green' : 'text-neon-red';
  const titleText = result === 'win' ? 'YOU WIN!' : 'YOU LOSE';

  const handlePlayAgain = () => {
    onPlayAgain();
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="retro-container pixel-corners bg-deeper-purple p-6 max-w-md w-full mx-4 text-center border-neon-purple">
        <h3 className={`font-press-start text-2xl ${titleColor} mb-6`}>{titleText}</h3>
        
        <div className="font-vt323 text-xl text-white mb-3">Final Score</div>
        <div className="game-score flex justify-center gap-8 text-4xl mb-6">
          <span>{score[0]}</span>
          <span className="text-hot-pink">:</span>
          <span>{score[1]}</span>
        </div>
        
        {result === 'win' && payout && (
          <div className="mb-6">
            <div className="font-orbitron text-electric-blue text-lg">+{payout} SOL</div>
            <div className="text-xs font-vt323 text-white opacity-70">
              Your winnings have been sent to your wallet
            </div>
          </div>
        )}
        
        <Button
          onClick={handlePlayAgain}
          variant="outline"
          className={`neon-button px-6 py-3 bg-deeper-purple border-2 ${
            result === 'win' ? 'border-neon-green text-neon-green hover:bg-neon-green/20' : 
                               'border-hot-pink text-hot-pink hover:bg-hot-pink/20'
          } font-orbitron rounded pixel-corners transition`}
        >
          PLAY AGAIN
        </Button>
      </DialogContent>
    </Dialog>
  );
}
