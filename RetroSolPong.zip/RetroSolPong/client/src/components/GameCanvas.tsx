import { useRef, useEffect } from "react";
import { useGame } from "@/hooks/useGame";
import { playSound } from "@/lib/audio";

export default function GameCanvas() {
  const canvasRef = useRef<HTMLDivElement>(null);
  const leftPaddleRef = useRef<HTMLDivElement>(null);
  const rightPaddleRef = useRef<HTMLDivElement>(null);
  const ballRef = useRef<HTMLDivElement>(null);
  
  const { 
    gameState, 
    player1Score, 
    player2Score,
    paddlePositions,
    ballPosition,
    updatePlayerPaddle 
  } = useGame();

  useEffect(() => {
    // Update DOM elements when game state changes
    if (ballRef.current && ballPosition) {
      ballRef.current.style.left = `${ballPosition.x}%`;
      ballRef.current.style.top = `${ballPosition.y}%`;
    }
    
    if (leftPaddleRef.current && paddlePositions?.player1) {
      leftPaddleRef.current.style.top = `${paddlePositions.player1}%`;
    }
    
    if (rightPaddleRef.current && paddlePositions?.player2) {
      rightPaddleRef.current.style.top = `${paddlePositions.player2}%`;
    }
  }, [ballPosition, paddlePositions]);

  // Add sound effects when ball hits paddles or walls
  useEffect(() => {
    if (ballPosition?.hitPaddle) {
      playSound('paddleHit');
    }
    if (ballPosition?.hitWall) {
      playSound('wallHit');
    }
    if (ballPosition?.scored) {
      playSound('score');
    }
  }, [ballPosition?.hitPaddle, ballPosition?.hitWall, ballPosition?.scored]);

  // Handle touch controls for mobile
  const handlePaddleMove = (e: React.TouchEvent) => {
    if (!canvasRef.current || !gameState.active) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const touch = e.touches[0];
    const relativeY = ((touch.clientY - rect.top) / rect.height) * 100;
    
    // Clamp paddle position between 0 and 80% (to account for paddle height)
    const clampedY = Math.max(0, Math.min(80, relativeY));
    
    // Update paddle position on server
    updatePlayerPaddle(clampedY);
  };

  return (
    <div 
      ref={canvasRef}
      className="w-full h-full relative overflow-hidden bg-black border-4 border-neon-purple shadow-[0_0_20px_#b026ff]"
    >
      {/* Left Paddle */}
      <div 
        ref={leftPaddleRef}
        className="game-paddle absolute left-2 top-1/4"
      ></div>
      
      {/* Right Paddle */}
      <div 
        ref={rightPaddleRef}
        className="game-paddle absolute right-2 top-1/2"
      ></div>
      
      {/* Ball */}
      <div 
        ref={ballRef}
        className="game-ball absolute left-1/2 top-1/2"
      ></div>
      
      {/* Score display */}
      <div className="absolute top-4 left-0 right-0 flex justify-center">
        <div className="game-score flex gap-8">
          <span>{player1Score}</span>
          <span className="text-hot-pink">:</span>
          <span>{player2Score}</span>
        </div>
      </div>
      
      {/* Touch controls for mobile */}
      <div 
        className="absolute bottom-0 left-0 w-1/2 h-full opacity-0"
        onTouchMove={handlePaddleMove}
      ></div>
      <div 
        className="absolute bottom-0 right-0 w-1/2 h-full opacity-0"
        onTouchMove={handlePaddleMove}
      ></div>
    </div>
  );
}
