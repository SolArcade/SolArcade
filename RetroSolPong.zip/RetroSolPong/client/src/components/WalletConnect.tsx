import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X, ExternalLink } from "lucide-react";
import { useWallet } from "@/hooks/useWallet";
import { truncateAddress } from "@/lib/utils";
import { playSound } from "@/lib/audio";

export default function WalletConnect() {
  const [open, setOpen] = useState(false);
  const { 
    isConnected, 
    publicKey, 
    connectPhantom, 
    connectSolflare, 
    balance, 
    disconnect, 
    isMobileWallet, 
    openMobileWalletApp 
  } = useWallet();

  const isMobile = isMobileWallet();

  const handleOpenDialog = () => {
    playSound('click');
    setOpen(true);
  };

  const handleCloseDialog = () => {
    playSound('click');
    setOpen(false);
  };

  // Function to handle connecting Phantom wallet
  const handleConnectPhantom = async () => {
    playSound('click');
    
    await connectPhantom();
    
    // Only close the dialog on desktop immediately
    // On mobile, the dialog stays open during the redirect
    if (!isMobile) {
      setOpen(false);
    }
  };

  // Function to handle connecting Solflare wallet
  const handleConnectSolflare = async () => {
    playSound('click');
    
    await connectSolflare();
    
    // Only close the dialog on desktop immediately
    // On mobile, the dialog stays open during the redirect
    if (!isMobile) {
      setOpen(false);
    }
  };

  const handleDisconnect = () => {
    playSound('click');
    disconnect();
  };

  return (
    <>
      <Button
        onClick={isConnected ? handleDisconnect : handleOpenDialog}
        variant="outline"
        className="neon-button px-3 py-2 bg-deeper-purple border-2 border-electric-blue text-electric-blue font-orbitron text-sm rounded pixel-corners flex items-center hover:bg-neon-purple/20 transition"
      >
        {isConnected && publicKey ? (
          <div className="flex flex-col items-end">
            <div>{truncateAddress(publicKey)}</div>
            {balance !== null && <div className="text-xs text-hot-pink">{balance.toFixed(2)} SOL</div>}
          </div>
        ) : (
          "Connect Wallet"
        )}
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="retro-container pixel-corners bg-deeper-purple p-6 max-w-md border-neon-purple">
          <DialogHeader className="flex justify-between items-center">
            <DialogTitle className="font-press-start text-lg text-electric-blue">CONNECT WALLET</DialogTitle>
            <Button onClick={handleCloseDialog} variant="ghost" className="text-white hover:text-hot-pink h-6 w-6 p-0">
              <X className="h-4 w-4" />
            </Button>
          </DialogHeader>

          <div className="space-y-4 my-4">
            {isMobile && (
              <div className="mb-4 text-center font-vt323 text-sm text-electric-blue bg-deeper-purple/60 p-2 rounded">
                <ExternalLink className="inline-block w-4 h-4 mr-1" />
                Mobile detected! Will open wallet app
              </div>
            )}
            
            <Button
              onClick={handleConnectPhantom}
              variant="outline"
              className="neon-button w-full px-4 py-3 bg-deeper-purple border-2 border-electric-blue text-electric-blue font-orbitron rounded pixel-corners hover:bg-neon-purple/20 transition flex items-center justify-between"
            >
              <span className="flex items-center">
                <span className="w-8 h-8 mr-3 flex-shrink-0 bg-white rounded-full flex items-center justify-center">
                  <svg viewBox="0 0 128 128" className="w-6 h-6">
                    <path d="M64 0C28.7 0 0 28.7 0 64s28.7 64 64 64 64-28.7 64-64S99.3 0 64 0zm0 120.7c-31.3 0-56.7-25.4-56.7-56.7S32.7 7.3 64 7.3s56.7 25.4 56.7 56.7-25.4 56.7-56.7 56.7z" fill="#ab9ff2" />
                    <path d="M83.6 45.6H44.4c-1.2 0-2.2 1-2.2 2.2v27.5c0 1.2 1 2.2 2.2 2.2h12.3v3.8c0 1.8 2.1 2.7 3.5 1.5l9.9-5.3h13.5c1.2 0 2.2-1 2.2-2.2V47.8c.1-1.2-.9-2.2-2.2-2.2z" fill="#ab9ff2" />
                  </svg>
                </span>
                <span>Phantom Wallet</span>
              </span>
              {isMobile && <ExternalLink className="w-5 h-5 ml-2 text-hot-pink" />}
            </Button>
            
            <Button
              onClick={handleConnectSolflare}
              variant="outline"
              className="neon-button w-full px-4 py-3 bg-deeper-purple border-2 border-electric-blue text-electric-blue font-orbitron rounded pixel-corners hover:bg-neon-purple/20 transition flex items-center justify-between"
            >
              <span className="flex items-center">
                <span className="w-8 h-8 mr-3 flex-shrink-0 bg-white rounded-full flex items-center justify-center">
                  <svg viewBox="0 0 128 128" className="w-6 h-6">
                    <path d="M64 104c-22.1 0-40-17.9-40-40s17.9-40 40-40 40 17.9 40 40-17.9 40-40 40z" fill="#FE9A33" />
                    <path d="M92.9 55.3L75.1 40.4c-6-5-14.6-5-20.6 0L36.7 55.3c-6 5-6 13.9 0 18.9l17.8 14.9c6 5 14.6 5 20.6 0l17.8-14.9c6-5 6-13.9 0-18.9zm-21.5 22.5c-4.4 0-7.9-3.5-7.9-7.9s3.5-7.9 7.9-7.9 7.9 3.5 7.9 7.9-3.6 7.9-7.9 7.9z" fill="#F5F5F5" />
                  </svg>
                </span>
                <span>Solflare Wallet</span>
              </span>
              {isMobile && <ExternalLink className="w-5 h-5 ml-2 text-hot-pink" />}
            </Button>
          </div>
          
          <div className="text-center font-vt323 text-sm text-white opacity-80">
            {isMobile 
              ? "The selected wallet app will open to connect"
              : "Connect your Solana wallet to play and earn SOL"}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
