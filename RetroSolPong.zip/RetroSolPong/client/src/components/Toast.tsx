import { Toast, ToastClose, ToastDescription, ToastProvider, ToastTitle, ToastViewport } from "@/components/ui/toast";
import { useToast } from "@/hooks/use-toast";

export function Toaster() {
  const { toasts } = useToast();

  return (
    <ToastProvider>
      {toasts.map(function ({ id, title, description, action, ...props }) {
        return (
          <Toast 
            key={id} 
            {...props}
            className="retro-container pixel-corners bg-deeper-purple p-3 border-neon-purple"
          >
            <div className="flex">
              {props.variant === "destructive" && (
                <div className="w-8 h-8 mr-2 text-neon-red flex-shrink-0 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </div>
              )}
              {props.variant === "success" && (
                <div className="w-8 h-8 mr-2 text-neon-green flex-shrink-0 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
              )}
              {props.variant === "default" && (
                <div className="w-8 h-8 mr-2 text-electric-blue flex-shrink-0 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              )}
              <div>
                <ToastTitle className="font-orbitron text-electric-blue text-sm">{title}</ToastTitle>
                {description && (
                  <ToastDescription className="text-xs font-vt323 text-white">
                    {description}
                  </ToastDescription>
                )}
              </div>
            </div>
            <ToastClose className="text-white hover:text-hot-pink" />
            {action}
          </Toast>
        );
      })}
      <ToastViewport className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 w-full max-w-xs" />
    </ToastProvider>
  );
}
