import { createRoot } from "react-dom/client";
import App from "./App";
import { WalletContextProvider } from "./contexts/WalletContext";
import { GameContextProvider } from "./contexts/GameContext";
import "./styles/fonts.css";
import "./styles/globals.css";
import "./index.css";

createRoot(document.getElementById("root")!).render(
  <WalletContextProvider>
    <GameContextProvider>
      <App />
    </GameContextProvider>
  </WalletContextProvider>
);
