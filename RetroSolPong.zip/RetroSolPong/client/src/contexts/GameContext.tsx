import { createContext, useState, useEffect, ReactNode } from "react";
import { useWallet } from "@/hooks/useWallet";
import { setupGameSocket } from "@/lib/socket";
import { GAME_WAGER_OPTIONS, sendWager, claimWinnings, requestRefund } from "@/lib/solana";
import { GameSocketMessage, PaddlePosition, BallPosition, GameState, GameResult } from "@shared/types";

interface GameContextType {
  gameState: {
    active: boolean;
    searching: boolean;
    starting: boolean;
    connected: boolean;
  };
  player1Score: number;
  player2Score: number;
  paddlePositions: { player1: number; player2: number } | null;
  ballPosition: BallPosition | null;
  cancelCountdown: number | null;
  gameResult: GameResult | null;
  gameStatusMessage: string;
  initGame: (wagerAmount: number) => Promise<boolean>;
  cancelGame: () => Promise<boolean>;
  updatePlayerPaddle: (position: number) => void;
  resetGame: () => void;
}

export const GameContext = createContext<GameContextType>({
  gameState: {
    active: false,
    searching: false,
    starting: false,
    connected: false,
  },
  player1Score: 0,
  player2Score: 0,
  paddlePositions: null,
  ballPosition: null,
  cancelCountdown: null,
  gameResult: null,
  gameStatusMessage: "",
  initGame: async () => false,
  cancelGame: async () => false,
  updatePlayerPaddle: () => {},
  resetGame: () => {},
});

interface GameContextProviderProps {
  children: ReactNode;
}

export function GameContextProvider({ children }: GameContextProviderProps) {
  const { isConnected, publicKey } = useWallet();
  
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [gameState, setGameState] = useState({
    active: false,
    searching: false,
    starting: false,
    connected: false,
  });
  
  const [player1Score, setPlayer1Score] = useState(0);
  const [player2Score, setPlayer2Score] = useState(0);
  const [paddlePositions, setPaddlePositions] = useState<{ player1: number; player2: number } | null>(null);
  const [ballPosition, setBallPosition] = useState<BallPosition | null>(null);
  
  const [gameId, setGameId] = useState<string | null>(null);
  const [cancelCountdown, setCancelCountdown] = useState<number | null>(null);
  const [cancelTimerId, setCancelTimerId] = useState<NodeJS.Timeout | null>(null);
  const [currentWager, setCurrentWager] = useState<number | null>(null);
  const [gameResult, setGameResult] = useState<GameResult | null>(null);
  const [gameStatusMessage, setGameStatusMessage] = useState("");

  // Initialize WebSocket connection when needed
  useEffect(() => {
    if (isConnected && publicKey && !socket) {
      const newSocket = setupGameSocket(publicKey);
      setSocket(newSocket);
      
      // Set up reconnection logic
      newSocket.onopen = () => {
        setGameState(prev => ({ ...prev, connected: true }));
        
        // Check session storage for active game
        const storedGameId = sessionStorage.getItem('activeGameId');
        const storedWager = sessionStorage.getItem('currentWager');
        
        if (storedGameId && storedWager) {
          // Send reconnect message to server
          newSocket.send(JSON.stringify({
            type: 'reconnect',
            gameId: storedGameId,
            publicKey,
            wagerAmount: parseFloat(storedWager)
          }));
        }
      };
      
      newSocket.onclose = () => {
        setGameState(prev => ({ ...prev, connected: false }));
        
        // Try to reconnect in 2 seconds
        setTimeout(() => {
          if (isConnected && publicKey) {
            const reconnectSocket = setupGameSocket(publicKey);
            setSocket(reconnectSocket);
          }
        }, 2000);
      };
      
      return () => {
        newSocket.close();
      };
    }
    
    // Cleanup socket when wallet disconnects
    if (!isConnected && socket) {
      socket.close();
      setSocket(null);
    }
  }, [isConnected, publicKey]);

  // Handle socket messages
  useEffect(() => {
    if (!socket) return;
    
    socket.onmessage = (event) => {
      const message = JSON.parse(event.data) as GameSocketMessage;
      
      switch (message.type) {
        case 'game-created':
          setGameId(message.gameId);
          setGameState(prev => ({ ...prev, searching: true }));
          setGameStatusMessage("Waiting for opponent...");
          
          // Save game info to session storage
          if (message.gameId && currentWager !== null) {
            sessionStorage.setItem('activeGameId', message.gameId);
            sessionStorage.setItem('currentWager', currentWager.toString());
          }
          
          // Start cancel countdown
          let countdownTime = 10;
          setCancelCountdown(countdownTime);
          
          const timer = setInterval(() => {
            countdownTime -= 1;
            setCancelCountdown(countdownTime);
            
            if (countdownTime <= 0) {
              clearInterval(timer);
              setCancelCountdown(null);
            }
          }, 1000);
          
          setCancelTimerId(timer);
          break;
          
        case 'game-ready':
          // Clear countdown timer
          if (cancelTimerId) clearInterval(cancelTimerId);
          setCancelTimerId(null);
          setCancelCountdown(null);
          
          setGameState(prev => ({ ...prev, searching: false, starting: true }));
          setGameStatusMessage("Opponent found! Game starting...");
          break;
          
        case 'game-start':
          setGameState(prev => ({ ...prev, starting: false, active: true }));
          setGameStatusMessage("Game in progress...");
          break;
          
        case 'game-update':
          if (message.paddlePositions) {
            setPaddlePositions(message.paddlePositions);
          }
          
          if (message.ballPosition) {
            setBallPosition(message.ballPosition);
          }
          
          if (message.scores) {
            setPlayer1Score(message.scores.player1);
            setPlayer2Score(message.scores.player2);
          }
          break;
          
        case 'game-end':
          setGameState({ active: false, searching: false, starting: false, connected: true });
          setGameStatusMessage("Game ended");
          setGameResult({
            won: message.won,
            payout: message.payout
          });
          
          // Clear game data in session storage
          sessionStorage.removeItem('activeGameId');
          sessionStorage.removeItem('currentWager');
          break;
          
        case 'reconnect-success':
          // Restore game state from server
          if (message.gameState) {
            restoreGameState(message.gameState);
          }
          break;
          
        case 'error':
          console.error("Game error:", message.message);
          setGameStatusMessage(`Error: ${message.message}`);
          break;
      }
    };
  }, [socket, currentWager, cancelTimerId]);

  // Reset all scores and game state when a new game starts
  useEffect(() => {
    if (gameState.starting) {
      setPlayer1Score(0);
      setPlayer2Score(0);
      setBallPosition(null);
      setPaddlePositions({ player1: 40, player2: 40 });
    }
  }, [gameState.starting]);

  // Restore game state after reconnection
  const restoreGameState = (state: GameState) => {
    setGameId(state.gameId);
    setGameState({
      active: state.status === 'active',
      searching: state.status === 'waiting',
      starting: state.status === 'starting',
      connected: true
    });
    
    if (state.scores) {
      setPlayer1Score(state.scores.player1);
      setPlayer2Score(state.scores.player2);
    }
    
    if (state.paddlePositions) {
      setPaddlePositions(state.paddlePositions);
    }
    
    if (state.ballPosition) {
      setBallPosition(state.ballPosition);
    }
    
    setCurrentWager(state.wagerAmount);
    
    if (state.status === 'waiting') {
      setGameStatusMessage("Waiting for opponent...");
      
      // Restore cancel countdown
      if (state.startTime) {
        const elapsedTime = Math.floor((Date.now() - state.startTime) / 1000);
        const remainingTime = Math.max(0, 10 - elapsedTime);
        
        if (remainingTime > 0) {
          let countdownTime = remainingTime;
          setCancelCountdown(countdownTime);
          
          const timer = setInterval(() => {
            countdownTime -= 1;
            setCancelCountdown(countdownTime);
            
            if (countdownTime <= 0) {
              clearInterval(timer);
              setCancelCountdown(null);
            }
          }, 1000);
          
          setCancelTimerId(timer);
        }
      }
    } else if (state.status === 'starting') {
      setGameStatusMessage("Opponent found! Game starting...");
    } else if (state.status === 'active') {
      setGameStatusMessage("Game in progress...");
    }
  };

  // Initialize a new game
  const initGame = async (wagerAmount: number): Promise<boolean> => {
    if (!isConnected || !publicKey || !socket) return false;
    
    try {
      // Find the wager option based on amount
      const wagerOption = GAME_WAGER_OPTIONS.find(opt => opt.amount === wagerAmount);
      if (!wagerOption) throw new Error("Invalid wager amount");
      
      // Send wager to house wallet
      const txResult = await sendWager(wagerAmount);
      if (!txResult.success) throw new Error(txResult.error || "Failed to send wager");
      
      // Set current wager for future reference
      setCurrentWager(wagerAmount);
      
      // Send game creation request to server
      socket.send(JSON.stringify({
        type: 'create-game',
        publicKey,
        wagerAmount,
        transactionId: txResult.signature
      }));
      
      return true;
    } catch (error: any) {
      console.error("Failed to initiate game:", error);
      setGameStatusMessage(`Error: ${error.message}`);
      return false;
    }
  };

  // Cancel game during search phase
  const cancelGame = async (): Promise<boolean> => {
    if (!gameId || !publicKey || !socket || !currentWager) return false;
    
    try {
      // Clear countdown timer
      if (cancelTimerId) clearInterval(cancelTimerId);
      setCancelTimerId(null);
      setCancelCountdown(null);
      
      // Only allow cancellation during search and if within cancel window
      if (!gameState.searching || cancelCountdown === null) {
        throw new Error("Cannot cancel game at this time");
      }
      
      // Request refund
      const refundResult = await requestRefund(currentWager);
      if (!refundResult.success) throw new Error(refundResult.error || "Failed to request refund");
      
      // Send cancellation to server
      socket.send(JSON.stringify({
        type: 'cancel-game',
        gameId,
        publicKey,
        transactionId: refundResult.signature
      }));
      
      // Reset game state
      setGameState({ active: false, searching: false, starting: false, connected: true });
      setGameId(null);
      setCurrentWager(null);
      
      // Clear game data in session storage
      sessionStorage.removeItem('activeGameId');
      sessionStorage.removeItem('currentWager');
      
      return true;
    } catch (error: any) {
      console.error("Failed to cancel game:", error);
      setGameStatusMessage(`Error: ${error.message}`);
      return false;
    }
  };

  // Update player paddle position
  const updatePlayerPaddle = (position: number) => {
    if (!socket || !gameId || !gameState.active) return;
    
    socket.send(JSON.stringify({
      type: 'update-paddle',
      gameId,
      position,
      publicKey
    }));
  };

  // Reset game state
  const resetGame = () => {
    setGameState({ active: false, searching: false, starting: false, connected: !!socket });
    setGameId(null);
    setPlayer1Score(0);
    setPlayer2Score(0);
    setPaddlePositions(null);
    setBallPosition(null);
    setCancelCountdown(null);
    setCurrentWager(null);
    setGameResult(null);
    setGameStatusMessage("");
    
    // Clear timers
    if (cancelTimerId) clearInterval(cancelTimerId);
    setCancelTimerId(null);
    
    // Clear game data in session storage
    sessionStorage.removeItem('activeGameId');
    sessionStorage.removeItem('currentWager');
  };

  return (
    <GameContext.Provider
      value={{
        gameState,
        player1Score,
        player2Score,
        paddlePositions,
        ballPosition,
        cancelCountdown,
        gameResult,
        gameStatusMessage,
        initGame,
        cancelGame,
        updatePlayerPaddle,
        resetGame,
      }}
    >
      {children}
    </GameContext.Provider>
  );
}
