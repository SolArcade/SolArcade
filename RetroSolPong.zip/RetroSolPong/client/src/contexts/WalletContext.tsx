import { createContext, useState, useEffect, useCallback, ReactNode } from "react";
import { Connection } from "@solana/web3.js";
import { RPC_ENDPOINT } from "@/lib/solana";
import {
  connectPhantom as connectPhantomWallet,
  connectSolflare as connectSolflareWallet,
  disconnectWallet,
  getWalletBalance,
  isMobileDevice,
  setupWalletEventListeners,
  cleanupWalletEventListeners,
  openMobileWalletDeepLink
} from "@/lib/walletManualConnect";

interface WalletMessage {
  title: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

interface WalletContextType {
  isConnected: boolean;
  publicKey: string | null;
  balance: number | null;
  walletMessage: WalletMessage | null;
  connection: Connection | null;
  connectPhantom: () => Promise<boolean>;
  connectSolflare: () => Promise<boolean>;
  disconnect: () => void;
  getBalance: () => Promise<number | null>;
  isMobileWallet: () => boolean;
  openMobileWalletApp: (type: 'phantom' | 'solflare') => void;
}

export const WalletContext = createContext<WalletContextType>({
  isConnected: false,
  publicKey: null,
  balance: null,
  walletMessage: null,
  connection: null,
  connectPhantom: async () => false,
  connectSolflare: async () => false,
  disconnect: () => {},
  getBalance: async () => null,
  isMobileWallet: () => false,
  openMobileWalletApp: () => {},
});

interface WalletContextProviderProps {
  children: ReactNode;
}

export function WalletContextProvider({ children }: WalletContextProviderProps) {
  const [isConnected, setIsConnected] = useState(false);
  const [publicKey, setPublicKey] = useState<string | null>(null);
  const [balance, setBalance] = useState<number | null>(null);
  const [walletMessage, setWalletMessage] = useState<WalletMessage | null>(null);
  const [connection, setConnection] = useState<Connection | null>(null);
  const [activeWallet, setActiveWallet] = useState<'phantom' | 'solflare' | null>(null);

  // Detect if user is on a mobile device
  const isMobileWallet = useCallback((): boolean => {
    const userAgent = navigator.userAgent || navigator.vendor || (window as any).opera;
    return /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(userAgent.toLowerCase());
  }, []);

  // Initialize Solana connection and set up wallet event listeners
  useEffect(() => {
    try {
      const conn = new Connection(RPC_ENDPOINT, {
        commitment: "confirmed",
        confirmTransactionInitialTimeout: 60000,
        disableRetryOnRateLimit: false,
      });
      setConnection(conn);
      console.log("Solana connection established");
      
      // Log if we're on mobile
      console.log("Device detection: ", isMobileWallet() ? "Mobile" : "Desktop");
      
      // Set up wallet event listeners
      setupWalletEventListeners();
      
      // Clean up event listeners when component unmounts
      return () => {
        cleanupWalletEventListeners();
      };
    } catch (error) {
      console.error("Failed to connect to Solana network:", error);
    }
  }, [isMobileWallet]);

  // Restore session from storage and handle mobile wallet returns
  useEffect(() => {
    // Detect if user is on a mobile device
    const mobileCheck = (): boolean => {
      const userAgent = navigator.userAgent || navigator.vendor || (window as any).opera;
      return /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(userAgent.toLowerCase());
    };

    const isMobile = mobileCheck();
    
    // Helper function to update wallet state
    const updateWalletState = (walletPubKey: string, walletType: 'phantom' | 'solflare') => {
      setPublicKey(walletPubKey);
      setIsConnected(true);
      setActiveWallet(walletType);
      
      sessionStorage.setItem('walletPublicKey', walletPubKey);
      sessionStorage.setItem('walletType', walletType);

      // Success message 
      setWalletMessage({
        title: "Connected",
        message: `${walletType === 'phantom' ? 'Phantom' : 'Solflare'} wallet connected successfully`,
        type: "success",
      });

      // Balance will be fetched in the effect that watches isConnected
    };
    
    const tryReconnectMobileWallet = async () => {
      const preferredWallet = sessionStorage.getItem('preferredWallet') as 'phantom' | 'solflare' | null;
      
      // If we have a preferred wallet but no connection yet, attempt to connect
      // This is likely a return from a mobile wallet app
      if (preferredWallet && !isConnected && isMobile) {
        console.log(`Detected return from mobile wallet app: ${preferredWallet}`);
        
        try {
          // Attempt to connect to the preferred wallet
          if (preferredWallet === 'phantom' && window.solana) {
            console.log('Attempting to auto-connect to Phantom mobile...');
            
            try {
              if (window.solana.isConnected && window.solana.publicKey) {
                // Wallet is already connected
                const walletPubKey = window.solana.publicKey.toString();
                console.log("Phantom mobile already connected, public key:", walletPubKey);
                updateWalletState(walletPubKey, 'phantom');
              } else {
                // Try to connect
                console.log("Trying auto-connect to Phantom mobile...");
                try {
                  const resp = await window.solana.connect();
                  const walletPubKey = resp.publicKey.toString();
                  console.log("Phantom mobile connected successfully! Public key:", walletPubKey);
                  updateWalletState(walletPubKey, 'phantom');
                } catch (connectError) {
                  console.error("Failed to connect to Phantom:", connectError);
                  // Remove preferred wallet since connection failed
                  sessionStorage.removeItem('preferredWallet');
                }
              }
            } catch (error) {
              console.error("Error auto-connecting to Phantom mobile:", error);
              sessionStorage.removeItem('preferredWallet');
            }
          } else if (preferredWallet === 'solflare' && window.solflare) {
            console.log('Attempting to auto-connect to Solflare mobile...');
            
            try {
              if (window.solflare.isConnected && window.solflare.publicKey) {
                // Wallet is already connected
                const walletPubKey = window.solflare.publicKey.toString();
                console.log("Solflare mobile already connected, public key:", walletPubKey);
                updateWalletState(walletPubKey, 'solflare');
              } else {
                // Try to connect
                console.log("Trying auto-connect to Solflare mobile...");
                try {
                  const resp = await window.solflare.connect();
                  const walletPubKey = resp.publicKey.toString();
                  console.log("Solflare mobile connected successfully! Public key:", walletPubKey);
                  updateWalletState(walletPubKey, 'solflare');
                } catch (connectError) {
                  console.error("Failed to connect to Solflare:", connectError);
                  // Remove preferred wallet since connection failed
                  sessionStorage.removeItem('preferredWallet');
                }
              }
            } catch (error) {
              console.error("Error auto-connecting to Solflare mobile:", error);
              sessionStorage.removeItem('preferredWallet');
            }
          }
        } catch (error) {
          console.error("Error during auto-reconnect:", error);
          sessionStorage.removeItem('preferredWallet');
        }
      } else {
        // Normal session restoration
        const storedPublicKey = sessionStorage.getItem('walletPublicKey');
        const storedWalletType = sessionStorage.getItem('walletType') as 'phantom' | 'solflare' | null;
        
        if (storedPublicKey && storedWalletType) {
          console.log(`Restoring wallet session: ${storedWalletType} - ${storedPublicKey}`);
          setPublicKey(storedPublicKey);
          setActiveWallet(storedWalletType);
          setIsConnected(true);
        }
      }
    };
    
    // Run the reconnection logic with a slight delay to allow for page setup
    setTimeout(() => {
      tryReconnectMobileWallet();
    }, 300);
  }, []);

  // Get balance when wallet is connected
  const getBalance = useCallback(async (): Promise<number | null> => {
    if (!publicKey || !connection) return null;
    
    try {
      console.log("Fetching balance for:", publicKey);
      
      // Use our utility function from walletManualConnect
      const balance = await getWalletBalance(publicKey);
      if (balance !== null) {
        setBalance(balance);
        console.log("Balance:", balance, "SOL");
      }
      return balance;
    } catch (error) {
      console.error("Error fetching balance:", error);
      return null;
    }
  }, [publicKey, connection]);

  // Update balance when connection state changes
  useEffect(() => {
    if (isConnected && publicKey && connection) {
      getBalance();
    }
  }, [isConnected, publicKey, connection, getBalance]);

  // Connect to Phantom wallet using improved approach
  const connectPhantom = async (): Promise<boolean> => {
    console.log("Attempting to connect to Phantom wallet...");
    
    try {
      // Check if on mobile
      if (isMobileDevice()) {
        console.log("Mobile device detected, storing preferred wallet and opening deep link");
        sessionStorage.setItem('preferredWallet', 'phantom');
        openMobileWalletDeepLink('phantom');
        setWalletMessage({
          title: "Opening Phantom",
          message: "Opening Phantom wallet. Please complete the connection in the wallet app.",
          type: "info",
        });
        return false; // Will reconnect on return
      }
      
      // Use our improved connection logic
      const result = await connectPhantomWallet();
      
      if (result.success && result.publicKey) {
        // Update state with connected wallet
        setPublicKey(result.publicKey);
        setIsConnected(true);
        setActiveWallet('phantom');
        
        // Store connection info
        sessionStorage.setItem('walletPublicKey', result.publicKey);
        sessionStorage.setItem('walletType', 'phantom');
        
        setWalletMessage({
          title: "Connected",
          message: "Phantom wallet connected successfully",
          type: "success",
        });
        
        // Get initial balance
        getBalance();
        
        return true;
      } else {
        console.error("Failed to connect to Phantom:", result.error);
        setWalletMessage({
          title: "Connection Failed",
          message: result.error || "Failed to connect to Phantom wallet. Please try again.",
          type: "error",
        });
        return false;
      }
    } catch (error: any) {
      console.error("Unexpected error with Phantom wallet:", error);
      setWalletMessage({
        title: "Connection Error",
        message: error?.message || "An unexpected error occurred with Phantom wallet",
        type: "error",
      });
      return false;
    }
  };
  
  // Connect to Solflare wallet using improved approach
  const connectSolflare = async (): Promise<boolean> => {
    console.log("Attempting to connect to Solflare wallet...");
    
    try {
      // Check if on mobile
      if (isMobileDevice()) {
        console.log("Mobile device detected, storing preferred wallet and opening deep link");
        sessionStorage.setItem('preferredWallet', 'solflare');
        openMobileWalletDeepLink('solflare');
        setWalletMessage({
          title: "Opening Solflare",
          message: "Opening Solflare wallet. Please complete the connection in the wallet app.",
          type: "info",
        });
        return false; // Will reconnect on return
      }
      
      // Use our improved connection logic
      const result = await connectSolflareWallet();
      
      if (result.success && result.publicKey) {
        // Update state with connected wallet
        setPublicKey(result.publicKey);
        setIsConnected(true);
        setActiveWallet('solflare');
        
        // Store connection info
        sessionStorage.setItem('walletPublicKey', result.publicKey);
        sessionStorage.setItem('walletType', 'solflare');
        
        setWalletMessage({
          title: "Connected",
          message: "Solflare wallet connected successfully",
          type: "success",
        });
        
        // Get initial balance
        getBalance();
        
        return true;
      } else {
        console.error("Failed to connect to Solflare:", result.error);
        setWalletMessage({
          title: "Connection Failed",
          message: result.error || "Failed to connect to Solflare wallet. Please try again.",
          type: "error",
        });
        return false;
      }
    } catch (error: any) {
      console.error("Unexpected error with Solflare wallet:", error);
      setWalletMessage({
        title: "Connection Error",
        message: error?.message || "An unexpected error occurred with Solflare wallet",
        type: "error",
      });
      return false;
    }
  };
  
  // Function to open mobile wallet app using deep links
  const openMobileWalletApp = (type: 'phantom' | 'solflare'): void => {
    if (isMobileDevice()) {
      console.log(`Opening ${type} mobile app...`);
      sessionStorage.setItem('preferredWallet', type);
      openMobileWalletDeepLink(type);
    } else {
      console.log(`Not a mobile device, cannot open ${type} app`);
    }
  };

  // Handle wallet disconnection
  const disconnect = () => {
    console.log("Disconnecting wallet...");
    
    try {
      if (activeWallet) {
        disconnectWallet(activeWallet);
      }
    } catch (error) {
      console.error("Error during wallet disconnect:", error);
    }
    
    // Reset state
    setPublicKey(null);
    setIsConnected(false);
    setBalance(null);
    setActiveWallet(null);
    
    // Clear storage
    sessionStorage.removeItem('walletPublicKey');
    sessionStorage.removeItem('walletType');
    sessionStorage.removeItem('preferredWallet');
    
    setWalletMessage({
      title: "Disconnected",
      message: "Wallet has been disconnected",
      type: "info",
    });
    
    console.log("Wallet disconnected");
  };

  return (
    <WalletContext.Provider
      value={{
        isConnected,
        publicKey,
        balance,
        walletMessage,
        connection,
        connectPhantom,
        connectSolflare,
        disconnect,
        getBalance,
        isMobileWallet,
        openMobileWalletApp,
      }}
    >
      {children}
    </WalletContext.Provider>
  );
}
