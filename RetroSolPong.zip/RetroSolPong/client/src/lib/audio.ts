import { Howl } from 'howler';

// Audio files
const AUDIO_FILES = {
  click: 'https://assets.codepen.io/123456/retro-click.mp3',
  select: 'https://assets.codepen.io/123456/retro-select.mp3',
  cancel: 'https://assets.codepen.io/123456/retro-cancel.mp3',
  paddleHit: 'https://assets.codepen.io/123456/pong-paddle.mp3',
  wallHit: 'https://assets.codepen.io/123456/pong-wall.mp3',
  score: 'https://assets.codepen.io/123456/pong-score.mp3',
  win: 'https://assets.codepen.io/123456/win.mp3',
  lose: 'https://assets.codepen.io/123456/lose.mp3',
  background: 'https://assets.codepen.io/123456/retro-background.mp3',
  gameBackground: 'https://assets.codepen.io/123456/game-background.mp3',
};

// Sound instances
const sounds: Record<string, Howl> = {};

// Load all audio files
export const loadAudio = () => {
  Object.entries(AUDIO_FILES).forEach(([key, url]) => {
    sounds[key] = new Howl({
      src: [url],
      preload: true,
      volume: 0.5,
    });
  });
};

interface PlayOptions {
  loop?: boolean;
  volume?: number;
  stop?: boolean;
}

// Play a sound
export const playSound = (name: string, options: PlayOptions = {}) => {
  const sound = sounds[name];
  
  if (!sound) return;
  
  if (options.stop) {
    sound.stop();
    return;
  }
  
  if (options.volume !== undefined) {
    sound.volume(options.volume);
  }
  
  if (options.loop !== undefined) {
    sound.loop(options.loop);
  }
  
  sound.play();
};

// Stop all sounds
export const stopAllSounds = () => {
  Object.values(sounds).forEach(sound => sound.stop());
};

// Check if sound is enabled in local storage
export const isSoundEnabled = (): boolean => {
  return localStorage.getItem('soundEnabled') !== 'false';
};

// Toggle sound
export const toggleSound = (enabled: boolean) => {
  localStorage.setItem('soundEnabled', enabled ? 'true' : 'false');
  
  if (!enabled) {
    stopAllSounds();
  }
};
