import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Truncate an address for display (e.g. "0x1234...5678")
export function truncateAddress(address: string, startLength = 4, endLength = 4): string {
  if (!address) return '';
  
  const start = address.substring(0, startLength);
  const end = address.substring(address.length - endLength);
  
  return `${start}...${end}`;
}
