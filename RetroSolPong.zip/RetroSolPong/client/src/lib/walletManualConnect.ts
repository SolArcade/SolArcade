// Alternative manual wallet connection without adapter libraries
import { Connection, LAMPORTS_PER_SOL, PublicKey } from '@solana/web3.js';
import { RPC_ENDPOINT } from './solana';

// Extended types for wallet providers
interface PhantomProvider {
  isPhantom?: boolean;
  connect: () => Promise<{ publicKey: PublicKey }>;
  disconnect: () => Promise<void>;
  isConnected: boolean;
  publicKey: PublicKey;
  on: (event: string, callback: Function) => void;
  removeAllListeners: () => void;
}

interface SolflareProvider {
  isSolflare?: boolean;
  connect: () => Promise<any>;
  disconnect: () => Promise<void>;
  isConnected: boolean;
  publicKey: PublicKey;
  on: (event: string, callback: Function) => void;
  removeAllListeners: () => void;
}

// Types for window.solana and window.solflare
declare global {
  interface Window {
    solana?: PhantomProvider;
    phantom?: {
      solana?: PhantomProvider;
    };
    solflare?: SolflareProvider;
  }
}

// Connection to Solana
const createConnection = (): Connection => {
  return new Connection(RPC_ENDPOINT, {
    commitment: "confirmed",
    confirmTransactionInitialTimeout: 60000
  });
};

// Function to check if Phantom is installed
export const isPhantomInstalled = (): boolean => {
  return !!window.phantom?.solana || !!window.solana?.isPhantom;
};

// Function to check if Solflare is installed
export const isSolflareInstalled = (): boolean => {
  return !!window.solflare?.isSolflare;
};

// Function to get balance
export const getWalletBalance = async (publicKey: string): Promise<number | null> => {
  if (!publicKey) return null;
  
  try {
    const connection = createConnection();
    const pubkey = new PublicKey(publicKey);
    const balance = await connection.getBalance(pubkey);
    return balance / LAMPORTS_PER_SOL;
  } catch (error) {
    console.error("Error fetching balance:", error);
    return null;
  }
};

// Connect to Phantom wallet
export const connectPhantom = async (): Promise<{ success: boolean; publicKey?: string; error?: string }> => {
  try {
    // Check if Phantom is available
    const provider = window.phantom?.solana || (window.solana?.isPhantom ? window.solana : null);
    
    if (!provider) {
      console.log("Phantom not installed, redirecting to install page");
      // If on mobile, try to open the app store
      if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        window.open('https://phantom.app/download', '_blank');
      } else {
        window.open('https://phantom.app/', '_blank');
      }
      return { success: false, error: "Phantom wallet not installed" };
    }
    
    console.log("Connecting to Phantom wallet...");
    
    try {
      // If already connected, use existing connection
      if (provider.isConnected && provider.publicKey) {
        const walletAddress = provider.publicKey.toString();
        console.log("Phantom already connected:", walletAddress);
        return { success: true, publicKey: walletAddress };
      }
      
      // Request connection
      const { publicKey } = await provider.connect();
      const walletAddress = publicKey.toString();
      console.log("Connected to Phantom:", walletAddress);
      
      return { success: true, publicKey: walletAddress };
      
    } catch (connectionError: any) {
      console.error("Error connecting to Phantom:", connectionError);
      return { success: false, error: connectionError?.message || "Failed to connect to Phantom" };
    }
  } catch (error: any) {
    console.error("Unexpected error with Phantom:", error);
    return { success: false, error: error?.message || "Unexpected error with Phantom" };
  }
};

// Connect to Solflare wallet
export const connectSolflare = async (): Promise<{ success: boolean; publicKey?: string; error?: string }> => {
  try {
    // Check if Solflare is available
    if (!window.solflare) {
      console.log("Solflare not installed, redirecting to install page");
      // If on mobile, try to open the app store
      if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        window.open('https://solflare.com/download', '_blank');
      } else {
        window.open('https://solflare.com/', '_blank');
      }
      return { success: false, error: "Solflare wallet not installed" };
    }
    
    console.log("Connecting to Solflare wallet...");
    
    try {
      // If already connected, use existing connection
      if (window.solflare.isConnected && window.solflare.publicKey) {
        const walletAddress = window.solflare.publicKey.toString();
        console.log("Solflare already connected:", walletAddress);
        return { success: true, publicKey: walletAddress };
      }
      
      // Request connection
      await window.solflare.connect();
      const walletAddress = window.solflare.publicKey.toString();
      console.log("Connected to Solflare:", walletAddress);
      
      return { success: true, publicKey: walletAddress };
      
    } catch (connectionError: any) {
      console.error("Error connecting to Solflare:", connectionError);
      return { success: false, error: connectionError?.message || "Failed to connect to Solflare" };
    }
  } catch (error: any) {
    console.error("Unexpected error with Solflare:", error);
    return { success: false, error: error?.message || "Unexpected error with Solflare" };
  }
};

// Disconnect wallet
export const disconnectWallet = async (walletType: 'phantom' | 'solflare'): Promise<boolean> => {
  try {
    if (walletType === 'phantom') {
      const provider = window.phantom?.solana || (window.solana?.isPhantom ? window.solana : null);
      if (provider) {
        await provider.disconnect();
        console.log("Disconnected from Phantom");
        return true;
      }
    } else if (walletType === 'solflare') {
      if (window.solflare) {
        await window.solflare.disconnect();
        console.log("Disconnected from Solflare");
        return true;
      }
    }
    return false;
  } catch (error) {
    console.error(`Error disconnecting from ${walletType}:`, error);
    return false;
  }
};

// Setup wallet event listeners
export const setupWalletEventListeners = (): void => {
  // Phantom event listeners
  if (window.phantom?.solana) {
    window.phantom.solana.on('connect', () => {
      console.log('Phantom connected!');
    });
    window.phantom.solana.on('disconnect', () => {
      console.log('Phantom disconnected!');
    });
    window.phantom.solana.on('accountChanged', (publicKey: PublicKey | null) => {
      if (publicKey) {
        console.log('Phantom account changed:', publicKey.toString());
      } else {
        console.log('Phantom account disconnected');
      }
    });
  } else if (window.solana?.isPhantom) {
    window.solana.on('connect', () => {
      console.log('Phantom connected!');
    });
    window.solana.on('disconnect', () => {
      console.log('Phantom disconnected!');
    });
    window.solana.on('accountChanged', (publicKey: PublicKey | null) => {
      if (publicKey) {
        console.log('Phantom account changed:', publicKey.toString());
      } else {
        console.log('Phantom account disconnected');
      }
    });
  }

  // Solflare event listeners
  if (window.solflare) {
    window.solflare.on('connect', () => {
      console.log('Solflare connected!');
    });
    window.solflare.on('disconnect', () => {
      console.log('Solflare disconnected!');
    });
    window.solflare.on('accountChanged', (publicKey: PublicKey | null) => {
      if (publicKey) {
        console.log('Solflare account changed:', publicKey.toString());
      } else {
        console.log('Solflare account disconnected');
      }
    });
  }
};

// Clean up event listeners
export const cleanupWalletEventListeners = (): void => {
  if (window.phantom?.solana) {
    window.phantom.solana.removeAllListeners();
  } else if (window.solana?.isPhantom) {
    window.solana.removeAllListeners();
  }
  
  if (window.solflare) {
    window.solflare.removeAllListeners();
  }
};

// For mobile wallet deep links
export const openMobileWalletDeepLink = (walletType: 'phantom' | 'solflare'): void => {
  // Get the current URL for the deep link
  const currentUrl = encodeURIComponent(window.location.href);
  let deepLink = '';
  
  if (walletType === 'phantom') {
    deepLink = `https://phantom.app/ul/browse/${currentUrl}`;
  } else if (walletType === 'solflare') {
    deepLink = `https://solflare.com/ul/browse/${currentUrl}`;
  }
  
  if (deepLink) {
    console.log(`Opening ${walletType} mobile deep link: ${deepLink}`);
    // Use location.href for better mobile support instead of window.open
    window.location.href = deepLink;
  }
};

// Check if device is mobile
export const isMobileDevice = (): boolean => {
  const userAgent = navigator.userAgent || navigator.vendor || (window as any).opera;
  return /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(userAgent.toLowerCase());
};