import { Connection, PublicKey, Transaction, SystemProgram, LAMPORTS_PER_SOL } from '@solana/web3.js';

// House wallet address
export const HOUSE_WALLET_ADDRESS = '45GGPAkoxwisBWj5YtHj1BH1tekmoFbRigSNJ4fT9UD2';

// QuickNode RPC endpoint with priority fees
export const RPC_ENDPOINT = 'https://solemn-orbital-energy.solana-mainnet.quiknode.pro/d2b2c179d598f4724ea95f9544944ecb266843fc/';

// Game wager options
export const GAME_WAGER_OPTIONS = [
  { value: 0.01, label: '0.01 SOL' },
  { value: 0.1, label: '0.1 SOL' },
  { value: 1, label: '1 SOL' },
  { value: 10, label: '10 SOL' },
];

// Create a connection to the Solana network
export const createConnection = (): Connection => {
  return new Connection(RPC_ENDPOINT, {
    commitment: 'confirmed',
    confirmTransactionInitialTimeout: 60000,
    disableRetryOnRateLimit: false,
    wsEndpoint: RPC_ENDPOINT.replace('https://', 'wss://'),
  });
};

// Get the active wallet instance
const getWallet = async () => {
  console.log("Getting wallet instance...");
  
  if (typeof window === 'undefined') {
    throw new Error('Window is not defined');
  }

  // Check wallet type from session storage
  const walletType = sessionStorage.getItem('walletType');
  const publicKey = sessionStorage.getItem('walletPublicKey');
  
  if (!walletType || !publicKey) {
    throw new Error('No wallet connected. Please connect your wallet first.');
  }

  console.log(`Using ${walletType} wallet with address ${publicKey}`);
  
  // Return the appropriate wallet based on type
  if (walletType === 'phantom') {
    if (!window.solana) {
      throw new Error('Phantom wallet not found. Please install the extension.');
    }
    return window.solana;
  } else if (walletType === 'solflare') {
    if (!window.solflare) {
      throw new Error('Solflare wallet not found. Please install the extension.');
    }
    return window.solflare;
  }
  
  throw new Error('Unknown wallet type. Please reconnect your wallet.');
};

interface TransactionResult {
  success: boolean;
  signature?: string;
  error?: string;
}

// Send wager to house wallet
export const sendWager = async (amount: number): Promise<TransactionResult> => {
  console.log(`Sending wager of ${amount} SOL to house wallet`);
  
  try {
    const connection = createConnection();
    console.log("Solana connection established");
    
    const wallet = await getWallet();
    console.log("Wallet obtained:", wallet.publicKey ? wallet.publicKey.toString() : "No public key");
    
    if (!wallet.publicKey) {
      throw new Error('Wallet not connected');
    }
    
    // Convert amount to lamports
    const lamports = Math.floor(amount * LAMPORTS_PER_SOL);
    console.log(`Amount in lamports: ${lamports}`);
    
    // Create transaction
    const transaction = new Transaction().add(
      SystemProgram.transfer({
        fromPubkey: wallet.publicKey,
        toPubkey: new PublicKey(HOUSE_WALLET_ADDRESS),
        lamports,
      })
    );
    
    console.log("Transaction created");
    
    // Set recent blockhash and fee payer
    console.log("Getting latest blockhash...");
    const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash();
    console.log(`Blockhash: ${blockhash}, lastValidBlockHeight: ${lastValidBlockHeight}`);
    
    transaction.recentBlockhash = blockhash;
    transaction.feePayer = wallet.publicKey;
    
    // Sign transaction with wallet
    console.log("Requesting wallet to sign transaction...");
    const signed = await wallet.signTransaction(transaction);
    console.log("Transaction signed successfully");
    
    // Send signed transaction
    console.log("Sending transaction to network...");
    const signature = await connection.sendRawTransaction(signed.serialize());
    console.log('Transaction sent with signature:', signature);
    
    // Wait for confirmation
    console.log("Waiting for confirmation...");
    const confirmation = await connection.confirmTransaction({
      signature,
      blockhash,
      lastValidBlockHeight,
    });
    
    if (confirmation.value.err) {
      console.error("Transaction failed with error:", confirmation.value.err);
      throw new Error(`Transaction failed: ${confirmation.value.err.toString()}`);
    }
    
    console.log('Transaction confirmed successfully');
    return { success: true, signature };
  } catch (error: any) {
    console.error('Error sending wager:', error);
    return { 
      success: false, 
      error: error.message || 'An unknown error occurred while sending your wager'
    };
  }
};

// Claim winnings from house wallet (will be handled by server in production)
export const claimWinnings = async (amount: number): Promise<TransactionResult> => {
  // This would be a server-side operation in production
  // The server would validate the win and send the tokens
  console.log(`Claiming winnings: ${amount} SOL`);
  
  // Server would handle this, but for now simulate success
  return { 
    success: true, 
    signature: 'simulated-payout-signature'
  };
};

// Request refund for cancelled game (will be handled by server in production)
export const requestRefund = async (amount: number): Promise<TransactionResult> => {
  // This would be a server-side operation in production
  // The server would validate the refund request and send the tokens
  console.log(`Requesting refund: ${amount} SOL`);
  
  // Server would handle this, but for now simulate success
  return { 
    success: true, 
    signature: 'simulated-refund-signature'
  };
};
