export function setupGameSocket(publicKey: string): WebSocket {
  console.log("Setting up WebSocket connection for wallet:", publicKey);
  
  // Determine the WebSocket URL based on the current protocol
  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
  const wsUrl = `${protocol}//${window.location.host}/ws`;
  console.log(`WebSocket URL: ${wsUrl}`);
  
  // Create the WebSocket connection
  const socket = new WebSocket(wsUrl);
  
  // Handle successful connection
  socket.onopen = () => {
    console.log('WebSocket connection established successfully');
    
    // Send authentication message on connection
    try {
      const authMessage = {
        type: 'auth',
        publicKey
      };
      
      console.log('Sending authentication message:', authMessage);
      socket.send(JSON.stringify(authMessage));
    } catch (sendError) {
      console.error('Error sending authentication message:', sendError);
    }
  };
  
  // Handle errors
  socket.onerror = (error) => {
    console.error('WebSocket error:', error);
  };
  
  // Handle connection closure
  socket.onclose = (event) => {
    if (event.wasClean) {
      console.log(`WebSocket connection closed cleanly, code=${event.code}, reason=${event.reason}`);
    } else {
      console.error(`WebSocket connection died, code=${event.code}`);
    }
  };
  
  // Override send method to add logging
  const originalSend = socket.send;
  socket.send = function(data: string | ArrayBufferLike | Blob | ArrayBufferView) {
    if (typeof data === 'string') {
      console.log('Sending WebSocket message:', data);
    } else {
      console.log('Sending binary WebSocket message');
    }
    return originalSend.call(this, data);
  };
  
  return socket;
}
