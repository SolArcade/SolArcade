import { useEffect } from "react";
import WagerSelection from "@/components/WagerSelection";
import TransactionHistory from "@/components/TransactionHistory";
import { useGame } from "@/hooks/useGame";
import { useLocation } from "wouter";
import { useWallet } from "@/hooks/useWallet";
import { loadAudio, playSound } from "@/lib/audio";

export default function Home() {
  const { isConnected } = useWallet();
  const { initGame, resetGame } = useGame();
  const [, setLocation] = useLocation();

  useEffect(() => {
    // Reset any active game state when returning to home
    resetGame();
    
    // Preload audio files
    loadAudio();
    
    // Play background music
    playSound('background', { loop: true, volume: 0.3 });
    
    return () => {
      // Stop background music when leaving home page
      playSound('background', { stop: true });
    };
  }, [resetGame]);

  const handleSelectWager = async (wagerAmount: number) => {
    if (!isConnected) return;
    
    playSound('select');
    const gameInitiated = await initGame(wagerAmount);
    
    if (gameInitiated) {
      setLocation('/game');
    }
  };

  return (
    <main className="flex-grow flex flex-col">
      <div className="flex-grow flex flex-col p-4 relative">
        <div className="flex-grow flex flex-col items-center justify-center">
          <div className="animate-float">
            <WagerSelection onSelectWager={handleSelectWager} />
          </div>
        </div>
      </div>
      
      <TransactionHistory />
    </main>
  );
}
