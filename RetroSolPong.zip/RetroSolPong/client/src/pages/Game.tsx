import { useEffect } from "react";
import { useLocation } from "wouter";
import GameCanvas from "@/components/GameCanvas";
import { Button } from "@/components/ui/button";
import { useGame } from "@/hooks/useGame";
import GameResultModal from "@/components/GameResultModal";
import { playSound } from "@/lib/audio";

export default function Game() {
  const [, setLocation] = useLocation();
  const { 
    gameState, 
    cancelGame, 
    cancelCountdown, 
    gameStatus, 
    player1Score, 
    player2Score,
    gameResult,
    resetGame
  } = useGame();

  useEffect(() => {
    // If no active game, redirect back to home
    if (!gameState.active && !gameState.searching && !gameResult) {
      setLocation('/');
    }
    
    // Play game background music
    playSound('gameBackground', { loop: true, volume: 0.3 });
    
    return () => {
      // Stop game background music when leaving
      playSound('gameBackground', { stop: true });
    };
  }, [gameState, gameResult, setLocation]);

  const handleCancelGame = async () => {
    playSound('cancel');
    await cancelGame();
    setLocation('/');
  };

  const handlePlayAgain = () => {
    playSound('select');
    resetGame();
    setLocation('/');
  };

  // Status message based on game state
  const statusText = () => {
    if (gameState.searching) return "Waiting for opponent...";
    if (gameState.starting) return "Opponent found! Game starting...";
    if (gameState.active) return "Game in progress...";
    return "Game ended";
  };

  return (
    <main className="flex-grow flex flex-col">
      <div className="flex-grow flex flex-col p-4 relative">
        <div className="flex-grow flex flex-col items-center justify-center">
          <div className="canvas-container w-full max-w-lg aspect-[4/3]">
            <GameCanvas />
          </div>
          
          <div className="mt-4 text-center">
            <p className="font-vt323 text-xl text-electric-blue animate-pulse-glow">
              {statusText()}
            </p>
            
            {(gameState.searching && cancelCountdown !== null) && (
              <Button 
                onClick={handleCancelGame} 
                variant="outline" 
                className="mt-3 neon-button border-neon-red text-neon-red font-orbitron"
              >
                Cancel Game ({cancelCountdown}s)
              </Button>
            )}
          </div>
        </div>
      </div>
      
      {gameResult && (
        <GameResultModal 
          result={gameResult.won ? 'win' : 'lose'} 
          score={[player1Score, player2Score]}
          payout={gameResult.payout}
          onPlayAgain={handlePlayAgain}
        />
      )}
    </main>
  );
}
