import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-deeper-purple">
      <Card className="w-full max-w-md mx-4 retro-container pixel-corners">
        <CardContent className="pt-6">
          <div className="flex mb-4 gap-2">
            <AlertCircle className="h-8 w-8 text-hot-pink" />
            <h1 className="text-2xl font-press-start text-electric-blue">404 NOT FOUND</h1>
          </div>

          <p className="mt-4 text-sm font-vt323 text-white mb-6">
            The arcade game you're looking for doesn't exist... yet!
          </p>

          <Link href="/">
            <Button variant="outline" className="neon-button border-electric-blue text-electric-blue font-orbitron">
              RETURN TO ARCADE
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
