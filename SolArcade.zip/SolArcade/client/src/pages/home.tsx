import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import WalletButtons from "@/components/WalletButtons";
import StatusDisplay from "@/components/StatusDisplay";
import { useWallet } from "@solana/wallet-adapter-react";
import { useConnection } from "@solana/wallet-adapter-react";
import { useState, useRef, useEffect, useCallback } from 'react';
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { sendTransaction } from "@/lib/wallet";
import TransactionHistory from "@/components/TransactionHistory";
import { useQuery } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";

export default function Home() {
  const { connected, publicKey, sendTransaction: walletSendTransaction } = useWallet();
  const { connection } = useConnection();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const [isInGame, setIsInGame] = useState(false);
  const [showGame, setShowGame] = useState(false);
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [playerNumber, setPlayerNumber] = useState<number>(0);
  const { toast } = useToast();
  const [countdown, setCountdown] = useState<number | null>(null);
  const [currentStake, setCurrentStake] = useState<number>(0); // Track current credit stake amount

  // Query for total pong credits
  const { data: transactions } = useQuery({
    queryKey: ['/api/transactions', publicKey?.toString()],
    queryFn: async () => {
      if (!publicKey) return [];
      const res = await fetch(`/api/transactions/${publicKey.toString()}`);
      if (!res.ok) throw new Error('Failed to fetch transactions');
      return res.json();
    },
    enabled: !!publicKey,
  });

  // Calculate available credits
  const availableCredits = transactions?.reduce((total: number, tx: any) => {
    return total + (tx.pongCredits || 0);
  }, 0) || 0;

  // Function to recover any pending transactions that might have been interrupted by page refresh
  const recoverPendingTransactions = useCallback(async () => {
    if (!connected || !publicKey) return;
    
    try {
      // Get pending transactions from localStorage
      const pendingTxs = JSON.parse(localStorage.getItem('pendingPongTransactions') || '[]');
      
      // Filter to only get transactions for the current wallet that have a Solana signature
      // (meaning the Solana transaction went through but server verification may not have)
      const pendingForCurrentWallet = pendingTxs.filter((tx: any) => 
        tx.walletAddress === publicKey.toString() && 
        tx.status === 'solana_confirmed' && 
        tx.signature
      );
      
      if (pendingForCurrentWallet.length > 0) {
        console.log(`Found ${pendingForCurrentWallet.length} pending transactions to recover for wallet ${publicKey.toString()}`);
        
        // Process each pending transaction
        for (const tx of pendingForCurrentWallet) {
          console.log(`Attempting to recover transaction ${tx.signature}`);
          
          try {
            // Verify with server
            const verifyResponse = await fetch('/api/verify-purchase', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                signature: tx.signature,
                walletAddress: tx.walletAddress,
                amount: tx.amount,
                credits: tx.credits
              })
            });

            if (verifyResponse.ok) {
              console.log(`Successfully recovered transaction ${tx.signature}`);
              
              // Show success toast
              toast({
                title: "Transaction Recovered",
                description: `Recovered ${tx.credits} Pong Credit${tx.credits > 1 ? 's' : ''} from interrupted transaction!`,
              });
              
              // Move from pending to completed
              const completedTxs = JSON.parse(localStorage.getItem('completedPongTransactions') || '[]');
              completedTxs.push({
                ...tx,
                status: 'completed',
                recovered: true
              });
              
              localStorage.setItem('completedPongTransactions', JSON.stringify(completedTxs));
              
              // Update pendingTxs variable to remove the processed transaction
              const index = pendingTxs.findIndex((pendingTx: any) => 
                pendingTx.signature === tx.signature && pendingTx.walletAddress === tx.walletAddress
              );
              
              if (index !== -1) {
                pendingTxs.splice(index, 1);
              }
            } else {
              console.error(`Failed to recover transaction ${tx.signature}`);
              // Keep in pending state to try again next time
            }
          } catch (error) {
            console.error(`Error recovering transaction ${tx.signature}:`, error);
            // Keep in pending state to try again next time
          }
        }
        
        // Save the updated pending transactions list
        localStorage.setItem('pendingPongTransactions', JSON.stringify(pendingTxs));
      }
    } catch (error) {
      console.error('Error recovering pending transactions:', error);
    }
  }, [connected, publicKey, toast]);

  useEffect(() => {
    if (!connected || !publicKey) return;
    
    // Run transaction recovery on wallet connection
    recoverPendingTransactions();

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      handleGameMessage(data);
    };

    ws.onclose = () => {
      toast({
        title: "Connection Lost",
        description: "Lost connection to the game server",
        variant: "destructive",
      });
      setIsInGame(false);
      setShowGame(false);
    };

    return () => {
      ws.close();
    };
  }, [connected, publicKey, recoverPendingTransactions]);

  const handleGameMessage = (data: any) => {
    switch (data.type) {
      case 'countdown':
        setCountdown(data.count);
        break;
      case 'round_start':
        setCountdown(null);
        break;
      case 'waiting':
        toast({
          title: "Waiting for Opponent",
          description: "Please wait while we find another player",
        });
        break;
      case 'game_start':
        setPlayerNumber(data.playerNumber);
        setIsInGame(true);
        // Reset current stake to prevent refund after game starts
        setCurrentStake(0);
        toast({
          title: "Game Started",
          description: `You are Player ${data.playerNumber}`,
        });
        break;
      case 'game_state':
        drawGame(data.state);
        break;
      case 'game_over':
        handleGameOver(data);
        break;
      case 'opponent_disconnected':
        toast({
          title: "Opponent Disconnected",
          description: "Your opponent has left the game",
          variant: "destructive",
        });
        setIsInGame(false);
        setShowGame(false);
        setCurrentStake(0); // Reset stake amount when opponent disconnects
        break;
      case 'error':
        toast({
          title: "Error",
          description: data.message,
          variant: "destructive",
        });
        break;
    }
  };

  const drawGame = (gameState: GameState) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas with deep blue color (synthwave style)
    const gradient = ctx.createLinearGradient(0, 0, 0, 600);
    gradient.addColorStop(0, '#000033');
    gradient.addColorStop(1, '#330033');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 800, 600);

    // Draw grid/background (synthwave grid effect)
    ctx.lineWidth = 1;
    
    // Horizontal lines (perspective)
    for (let y = 50; y < 600; y += 40) {
      const alpha = 0.3 - (y / 1500);
      ctx.strokeStyle = `rgba(255, 0, 255, ${alpha})`;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(800, y);
      ctx.stroke();
    }
    
    // Vertical lines
    for (let x = 100; x < 800; x += 100) {
      if (x === 400) continue; // Skip center line as we'll draw that separately
      
      const alpha = x === 200 || x === 600 ? 0.4 : 0.2;
      ctx.strokeStyle = `rgba(0, 255, 255, ${alpha})`;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, 600);
      ctx.stroke();
    }

    // Draw center line (neon glow)
    ctx.strokeStyle = '#00ffff';
    ctx.lineWidth = 4;
    ctx.setLineDash([10, 15]);
    ctx.shadowColor = '#00ffff';
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.moveTo(400, 0);
    ctx.lineTo(400, 600);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.shadowBlur = 0;

    // Draw paddles with neon glow
    // Left paddle (pink)
    ctx.shadowColor = '#ff00ff';
    ctx.shadowBlur = 15;
    ctx.fillStyle = '#ff00ff';
    ctx.fillRect(10, gameState.paddles.p1, 20, 100);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(13, gameState.paddles.p1 + 3, 14, 94);
    
    // Right paddle (cyan)
    ctx.shadowColor = '#00ffff';
    ctx.shadowBlur = 15;
    ctx.fillStyle = '#00ffff';
    ctx.fillRect(770, gameState.paddles.p2, 20, 100);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(773, gameState.paddles.p2 + 3, 14, 94);
    
    ctx.shadowBlur = 0;

    // Draw ball with neon glow
    ctx.shadowColor = '#ffffff';
    ctx.shadowBlur = 20;
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(gameState.ball.x, gameState.ball.y, 10, 0, Math.PI * 2);
    ctx.fill();
    
    // Inner gradient for ball
    const ballGradient = ctx.createRadialGradient(
      gameState.ball.x, gameState.ball.y, 0,
      gameState.ball.x, gameState.ball.y, 10
    );
    ballGradient.addColorStop(0, '#ffffff');
    ballGradient.addColorStop(0.8, '#ff00ff');
    ballGradient.addColorStop(1, '#00ffff');
    
    ctx.fillStyle = ballGradient;
    ctx.beginPath();
    ctx.arc(gameState.ball.x, gameState.ball.y, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    // Draw score with neon effect
    ctx.shadowColor = '#00ffff';
    ctx.shadowBlur = 10;
    ctx.font = '48px "Press Start 2P", monospace';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#00ffff';
    ctx.fillText(gameState.score.p1.toString(), 200, 80);
    ctx.fillText(gameState.score.p2.toString(), 600, 80);
    ctx.shadowBlur = 0;

    // Draw countdown if active
    if (countdown !== null) {
      ctx.save();
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(0, 0, 800, 600);
      ctx.shadowColor = '#ff00ff';
      ctx.shadowBlur = 20;
      ctx.fillStyle = '#ff00ff';
      ctx.font = '120px "Press Start 2P", monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(countdown.toString(), 400, 300);
      ctx.restore();
    }
  };

  const handleGameOver = (data: { winner: boolean; winnings?: number; signature?: string }) => {
    let description = data.winner ? "Congratulations! You won the game!" : "Better luck next time!";

    if (data.winner && data.winnings) {
      description += ` You won ${data.winnings} SOL!`;
      if (data.signature) {
        description += ` Transaction: ${data.signature.slice(0, 8)}...`;
      }
    }

    toast({
      title: data.winner ? "Victory!" : "Defeat",
      description,
      variant: data.winner ? "default" : "destructive",
    });

    // Reset game state
    setIsInGame(false);
    setShowGame(false);
    setCurrentStake(0); // Reset stake amount when game ends
  };

  const handlePaddleMove = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isInGame || !wsRef.current) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    
    // Get position whether mouse or touch event
    const clientY = 'touches' in e 
      ? e.touches[0].clientY 
      : (e as React.MouseEvent).clientY;
    
    const y = clientY - rect.top;
    
    // Calculate normalized position relative to the canvas
    const canvasRatio = canvas.height / rect.height;
    const scaledY = y * canvasRatio;
    
    wsRef.current.send(JSON.stringify({
      type: 'paddle_move',
      position: Math.max(0, Math.min(500, scaledY))
    }));
  };
  
  // Separate touch start handler to improve mobile responsiveness
  const handleTouchStart = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (!isInGame) return;
    
    // Prevent default behavior to avoid scrolling
    e.preventDefault();
    
    // Immediately move the paddle to the touch position
    handlePaddleMove(e);
  };

  const purchaseCredits = async (amount: number, credits: number) => {
    if (!connected || !publicKey || isProcessingPayment) return;

    setIsProcessingPayment(true);
    try {
      // Record transaction intent in localStorage BEFORE sending the transaction
      // This creates a record of transactions we've attempted but may not have verified yet
      try {
        const pendingTxs = JSON.parse(localStorage.getItem('pendingPongTransactions') || '[]');
        const pendingTxId = Date.now().toString(); // Unique ID for this transaction attempt
        
        pendingTxs.push({
          id: pendingTxId,
          walletAddress: publicKey.toString(),
          amount,
          credits,
          timestamp: new Date().toISOString(),
          status: 'pending'
        });
        
        localStorage.setItem('pendingPongTransactions', JSON.stringify(pendingTxs));
        console.log(`Stored pending transaction ${pendingTxId} in localStorage`);
      } catch (storageError) {
        console.error('Failed to store pending transaction intent:', storageError);
        // Continue anyway
      }
      
      // Send SOL to the house wallet
      const signature = await sendTransaction(
        connection,
        walletSendTransaction,
        publicKey,
        amount
      );
      
      console.log(`Solana transaction completed: ${signature}`);
      
      // Update the pending transaction with the signature
      try {
        const pendingTxs = JSON.parse(localStorage.getItem('pendingPongTransactions') || '[]');
        const updatedPendingTxs = pendingTxs.map((tx: any) => {
          if (tx.walletAddress === publicKey.toString() && tx.status === 'pending' && 
              tx.amount === amount && tx.credits === credits) {
            return { ...tx, signature, status: 'solana_confirmed' };
          }
          return tx;
        });
        
        localStorage.setItem('pendingPongTransactions', JSON.stringify(updatedPendingTxs));
        console.log(`Updated pending transaction with signature ${signature}`);
      } catch (storageError) {
        console.error('Failed to update pending transaction with signature:', storageError);
        // Continue anyway
      }
      
      // Verify the transaction on the server and add credits to the user's account
      const verifyResponse = await fetch('/api/verify-purchase', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          signature,
          walletAddress: publicKey.toString(),
          amount,
          credits
        })
      });

      if (!verifyResponse.ok) {
        const errorData = await verifyResponse.json();
        throw new Error(`Failed to verify transaction: ${errorData.error || 'Unknown error'}`);
      }
      
      const verifyResult = await verifyResponse.json();
      
      // If the transaction is being tracked but not yet fully processed,
      // we should start polling for status updates
      if (verifyResult.status === 'tracking' || verifyResult.status === 'pending') {
        console.log(`Transaction ${signature} is being tracked by the server. Starting status polling.`);
        
        // Start polling for status updates
        let pollCount = 0;
        const maxPolls = 20; // Maximum number of times to poll (20 * 3s = 60s)
        const pollInterval = setInterval(async () => {
          try {
            pollCount++;
            console.log(`Polling for transaction ${signature} status (${pollCount}/${maxPolls})...`);
            
            const statusResponse = await fetch(`/api/transaction-status/${signature}`);
            if (!statusResponse.ok) {
              console.error(`Failed to get status for transaction ${signature}`);
              if (pollCount >= maxPolls) {
                clearInterval(pollInterval);
                console.log(`Stopped polling for transaction ${signature} after ${maxPolls} attempts`);
              }
              return;
            }
            
            const statusResult = await statusResponse.json();
            console.log(`Transaction ${signature} status: ${statusResult.status}`);
            
            if (statusResult.status === 'confirmed') {
              clearInterval(pollInterval);
              console.log(`Transaction ${signature} is confirmed!`);
              
              // Refresh transactions to update the available credits
              // This will query the API again and update the UI
              queryClient.invalidateQueries({
                queryKey: ['/api/transactions', publicKey?.toString()]
              });
              
              toast({
                title: "Transaction Confirmed",
                description: `${credits} Pong Credit${credits > 1 ? 's' : ''} added to your account!`
              });
            } else if (statusResult.status === 'failed') {
              clearInterval(pollInterval);
              console.error(`Transaction ${signature} failed!`);
              
              toast({
                title: "Transaction Failed",
                description: "Your SOL payment could not be verified. Please contact support.",
                variant: "destructive"
              });
            } else if (pollCount >= maxPolls) {
              // If we've reached the maximum number of polls and the transaction
              // is still not confirmed, stop polling but don't mark as failed
              clearInterval(pollInterval);
              console.log(`Stopped polling for transaction ${signature} after ${maxPolls} attempts`);
              
              toast({
                title: "Transaction Pending",
                description: "Your transaction is still being processed. Credits will be added when confirmed.",
              });
            }
          } catch (error) {
            console.error(`Error polling transaction ${signature} status:`, error);
            if (pollCount >= maxPolls) {
              clearInterval(pollInterval);
            }
          }
        }, 3000); // Poll every 3 seconds
      }
      
      // Mark the transaction as fully completed in localStorage
      try {
        const pendingTxs = JSON.parse(localStorage.getItem('pendingPongTransactions') || '[]');
        const remainingPendingTxs = pendingTxs.filter((tx: any) => 
          !(tx.signature === signature && tx.walletAddress === publicKey.toString())
        );
        
        // Move from pending to completed
        const completedTxs = JSON.parse(localStorage.getItem('completedPongTransactions') || '[]');
        completedTxs.push({
          signature,
          walletAddress: publicKey.toString(),
          amount,
          credits,
          timestamp: new Date().toISOString(),
          status: 'completed'
        });
        
        localStorage.setItem('pendingPongTransactions', JSON.stringify(remainingPendingTxs));
        localStorage.setItem('completedPongTransactions', JSON.stringify(completedTxs));
        console.log(`Moved transaction ${signature} from pending to completed`);
      } catch (storageError) {
        console.error('Failed to update transaction status in localStorage:', storageError);
        // Not critical, so we continue without throwing an error
      }

      toast({
        title: "Payment Successful",
        description: `Received ${credits} Pong Credit${credits > 1 ? 's' : ''}! Transaction: ${signature.slice(0, 8)}...`,
      });

    } catch (error) {
      // If there was an error after the Solana transaction was sent but before verification
      // was complete, we still need to keep the pending transaction in localStorage
      // for recovery during next page load
      
      toast({
        title: "Payment Failed",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setIsProcessingPayment(false);
    }
  };

  const buyPongCredit = () => purchaseCredits(0.01, 1);
  const buy10PongCredits = () => purchaseCredits(0.1, 10);
  const buy100PongCredits = () => purchaseCredits(1, 100);

  // Unified game start function for all stake levels
  const startGameWithStake = async (credits: number, solStake: number, message: string) => {
    if (!connected || !publicKey || availableCredits < credits) return;

    // Show the game canvas
    setShowGame(true);
    // Set current stake amount
    setCurrentStake(credits);

    try {
      // Deduct credits by creating a negative credit transaction
      const response = await fetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          walletAddress: publicKey.toString(),
          amount: 0, // Zero amount for credit deduction
          status: 'completed',
          timestamp: new Date().toISOString(),
          pongCredits: -credits // Deduct credits
        })
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(`Failed to deduct credits: ${error}`);
      }

      if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
        const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
        const wsUrl = `${protocol}//${window.location.host}/ws`;
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        // Set up WebSocket event handlers
        ws.onopen = () => {
          console.log("WebSocket connected, joining game...");
          // Delay just slightly to ensure stable connection
          setTimeout(() => {
            ws.send(JSON.stringify({
              type: 'join',
              stake: solStake,
              wallet: publicKey.toString()
            }));
          }, 100);
        };

        ws.onerror = (error) => {
          console.error("WebSocket error:", error);
          toast({
            title: "Connection Error",
            description: "Failed to connect to game server",
            variant: "destructive",
          });
          setShowGame(false);
          setCurrentStake(0);
        };

        ws.onmessage = (event) => {
          handleGameMessage(JSON.parse(event.data));
        };
      } else {
        // WebSocket is already open, send join message
        console.log("Using existing WebSocket connection to join game...");
        wsRef.current.send(JSON.stringify({
          type: 'join',
          stake: solStake,
          wallet: publicKey.toString()
        }));
      }

      toast({
        title: "Starting Game",
        description: message,
      });

    } catch (error) {
      console.error("Game start error:", error);
      toast({
        title: "Error Starting Game",
        description: error instanceof Error ? error.message : "Failed to start game",
        variant: "destructive",
      });
      setShowGame(false);
      setCurrentStake(0);
    }
  };
  
  // Start game with 1 credit
  const startGame = () => startGameWithStake(1, 0.01, "Looking for an opponent...");

  // Draw initial empty game board with synthwave style
  useEffect(() => {
    if (canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d');
      if (ctx) {
        // Background gradient
        const gradient = ctx.createLinearGradient(0, 0, 0, 600);
        gradient.addColorStop(0, '#000033');
        gradient.addColorStop(1, '#330033');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, 800, 600);
        
        // Draw grid/background (synthwave grid effect)
        ctx.lineWidth = 1;
        
        // Horizontal lines (perspective)
        for (let y = 50; y < 600; y += 40) {
          const alpha = 0.3 - (y / 1500);
          ctx.strokeStyle = `rgba(255, 0, 255, ${alpha})`;
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(800, y);
          ctx.stroke();
        }
        
        // Vertical lines
        for (let x = 100; x < 800; x += 100) {
          if (x === 400) continue; // Skip center line as we'll draw that separately
          
          const alpha = x === 200 || x === 600 ? 0.4 : 0.2;
          ctx.strokeStyle = `rgba(0, 255, 255, ${alpha})`;
          ctx.beginPath();
          ctx.moveTo(x, 0);
          ctx.lineTo(x, 600);
          ctx.stroke();
        }
        
        // Center line
        ctx.strokeStyle = '#00ffff';
        ctx.lineWidth = 4;
        ctx.setLineDash([10, 15]);
        ctx.shadowColor = '#00ffff';
        ctx.shadowBlur = 10;
        ctx.beginPath();
        ctx.moveTo(400, 0);
        ctx.lineTo(400, 600);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.shadowBlur = 0;

        // Draw empty paddles with neon glow
        // Left paddle (pink)
        ctx.shadowColor = '#ff00ff';
        ctx.shadowBlur = 15;
        ctx.fillStyle = '#ff00ff';
        ctx.fillRect(10, 250, 20, 100);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(13, 253, 14, 94);
        
        // Right paddle (cyan)
        ctx.shadowColor = '#00ffff';
        ctx.shadowBlur = 15;
        ctx.fillStyle = '#00ffff';
        ctx.fillRect(770, 250, 20, 100);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(773, 253, 14, 94);
        
        ctx.shadowBlur = 0;
      }
    }
  }, [showGame]);

  return (
    <div className="pong-container">
      <div className="max-w-4xl mx-auto space-y-6 p-4">
        <div className="pong-card">
          <h1 className="pong-title">RETRO PONG</h1>
          <p className="pong-subtitle">Solana-Powered Arcade Classic</p>
        </div>
        
        {!connected ? (
          <div className="pong-card">
            <h2 className="text-[#00ffff] text-2xl mb-4 text-center font-bold">
              Connect Wallet to Play
            </h2>
            <WalletButtons />
          </div>
        ) : (
          <>
            <div className="pong-card">
              <h2 className="text-[#00ffff] text-xl mb-3 text-center">Wallet Status</h2>
              <WalletButtons />
              <div className="mt-4 border-t border-[#ff00ff] pt-4">
                <StatusDisplay />
              </div>
            </div>

            <div className="pong-card">
              <h2 className="text-[#00ffff] text-xl mb-3 text-center">Pong Credits</h2>
              <div className="flex flex-col items-center justify-between gap-4 mb-2">
                <div className="text-lg text-white">
                  Available Credits: 
                  <span className="ml-2 text-[#ff00ff] font-bold text-2xl">
                    {availableCredits}
                  </span>
                </div>
                <div className="flex flex-col md:flex-row gap-2 w-full">
                  <Button
                    onClick={buyPongCredit}
                    disabled={isProcessingPayment}
                    className="pong-button flex-1"
                  >
                    {isProcessingPayment ? "Processing..." : "Buy 1 Credit (0.01 SOL)"}
                  </Button>
                  <Button
                    onClick={buy10PongCredits}
                    disabled={isProcessingPayment}
                    className="pong-button flex-1"
                  >
                    {isProcessingPayment ? "Processing..." : "Buy 10 Credits (0.1 SOL)"}
                  </Button>
                  <Button
                    onClick={buy100PongCredits}
                    disabled={isProcessingPayment}
                    className="pong-button flex-1"
                  >
                    {isProcessingPayment ? "Processing..." : "Buy 100 Credits (1 SOL)"}
                  </Button>
                </div>
              </div>
            </div>

            <TransactionHistory />

            <div className="pong-card">
              <h2 className="text-[#00ffff] text-xl mb-3 text-center">Play Now</h2>
              {!showGame ? (
                <div className="text-center p-6">
                  <p className="mb-6 text-white">
                    {availableCredits > 0
                      ? "Ready to play! Select your preferred wager below."
                      : "Purchase Pong Credits above to play the game"}
                  </p>
                  
                  <div className="flex flex-col gap-4 items-center">
                    <Button
                      onClick={startGame}
                      disabled={availableCredits < 1}
                      className="pong-button text-lg py-6 px-8 w-72"
                    >
                      {availableCredits < 1 ? "Need Credits" : "PLAY GAME (1 Credit)"}
                    </Button>
                    
                    <Button
                      onClick={() => startGameWithStake(10, 0.1, "Looking for an opponent for 10-credit game...")}
                      disabled={availableCredits < 10}
                      className="pong-button-high text-lg py-6 px-8 w-72 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600"
                    >
                      {availableCredits < 10 ? "Need 10 Credits" : "PLAY GAME (10 Credits)"}
                    </Button>
                    
                    <Button
                      onClick={() => startGameWithStake(100, 1.0, "Looking for an opponent for 100-credit game...")}
                      disabled={availableCredits < 100}
                      className="pong-button-premium text-lg py-6 px-8 w-72 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                    >
                      {availableCredits < 100 ? "Need 100 Credits" : "PLAY GAME (100 Credits)"}
                    </Button>
                  </div>
                  
                  <p className="mt-6 text-sm text-white">
                    <span className="text-[#00ffff]">Play with higher wagers</span> to win bigger prizes!
                  </p>
                </div>
              ) : (
                <div className="relative">
                  <canvas
                    ref={canvasRef}
                    width={800}
                    height={600}
                    onMouseMove={handlePaddleMove}
                    onTouchStart={handleTouchStart}
                    onTouchMove={(e) => {
                      e.preventDefault(); // Prevent scrolling when touching the canvas
                      handlePaddleMove(e);
                    }}
                    className="pong-canvas"
                    style={{ touchAction: 'none' }} // Explicitly disable browser touch actions
                  />
                  {!isInGame && showGame && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-black bg-opacity-80">
                      <div className="text-lg font-semibold text-[#ff00ff] animate-pulse mb-6">
                        Waiting for opponent...
                      </div>
                      
                      <Button
                        onClick={async () => {
                          // Store the current stake before resetting UI (needed for refund)
                          const stakeToRefund = currentStake;
                          
                          // Reset game state immediately for better UX
                          setShowGame(false);
                          setCurrentStake(0);
                          
                          // Close the WebSocket connection if open
                          if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
                            // Send cancellation message before closing
                            try {
                              wsRef.current.send(JSON.stringify({
                                type: 'cancel_search'
                              }));
                              // Small delay to allow message to send before closing
                              await new Promise(resolve => setTimeout(resolve, 100));
                            } catch (err) {
                              console.error("Error sending cancel message:", err);
                            }
                            
                            // Now close the connection
                            wsRef.current.close();
                            wsRef.current = null;
                          }
                          
                          // Refund the credits
                          if (stakeToRefund > 0 && publicKey) {
                            try {
                              const response = await fetch('/api/transactions', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({
                                  walletAddress: publicKey.toString(),
                                  amount: 0,
                                  status: 'completed',
                                  timestamp: new Date().toISOString(),
                                  pongCredits: stakeToRefund // Refund the credits
                                })
                              });
                              
                              if (response.ok) {
                                toast({
                                  title: "Search Cancelled",
                                  description: `${stakeToRefund} credits have been refunded to your account.`,
                                });
                              } else {
                                toast({
                                  title: "Error",
                                  description: "Failed to refund credits. Please contact support.",
                                  variant: "destructive",
                                });
                              }
                            } catch (error) {
                              toast({
                                title: "Error",
                                description: "Failed to refund credits. Please contact support.",
                                variant: "destructive",
                              });
                            }
                          }
                        }}
                        variant="destructive"
                        className="px-6 py-2 bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600 text-white font-bold"
                      >
                        Cancel Search
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </div>
            
            <div className="pong-card">
              <h2 className="text-[#00ffff] text-xl mb-3 text-center">How to Play</h2>
              <p className="text-white text-sm">
                • Use your mouse or touch to move your paddle up and down<br />
                • First player to score 12 points wins<br />
                • The game automatically alternates serve direction<br />
                • Choose your wager: 1 credit (0.015 SOL prize), 10 credits (0.15 SOL prize), or 100 credits (1.5 SOL prize)
              </p>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

interface GameState {
  ball: { x: number; y: number; dx: number; dy: number; };
  paddles: { p1: number; p2: number; };
  score: { p1: number; p2: number; };
  countdownActive?: boolean;
  lastScorer?: number;
}