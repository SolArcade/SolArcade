import { useEffect, useRef, useState } from 'react';
import { useWallet } from "@solana/wallet-adapter-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Volume2, VolumeX, ArrowLeft } from "lucide-react";
import { soundManager } from "@/lib/sounds";
import { useLocation } from "wouter";

interface GameState {
  ball: { x: number; y: number; dx: number; dy: number; };
  paddles: { p1: number; p2: number; };
  score: { p1: number; p2: number; };
  countdownActive?: boolean;
  lastScorer?: number;
}

export default function Game() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const gameLoopRef = useRef<number | null>(null);
  const canvasContainerRef = useRef<HTMLDivElement>(null);
  const lastGameStateRef = useRef<GameState | null>(null);
  
  const { connected, publicKey } = useWallet();
  const [isInGame, setIsInGame] = useState(false);
  const [playerNumber, setPlayerNumber] = useState<number>(0);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [isMuted, setIsMuted] = useState(true);
  const [showControls, setShowControls] = useState(true);
  const [stake, setStake] = useState<number>(0.1);
  const [gameRoomId, setGameRoomId] = useState<string | null>(null);
  const [waitingForOpponent, setWaitingForOpponent] = useState(false);
  const [showGameOver, setShowGameOver] = useState(false);
  const [isWinner, setIsWinner] = useState(false);
  
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  // Initialize sound manager
  useEffect(() => {
    soundManager.init();
    setIsMuted(soundManager.isMutedState());
    
    return () => {
      // Clean up any ongoing game state if the component unmounts
      if (gameLoopRef.current) {
        cancelAnimationFrame(gameLoopRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (!connected || !publicKey) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      handleGameMessage(data);
    };

    ws.onopen = () => {
      console.log('Connected to game server');
    };

    ws.onclose = () => {
      toast({
        title: "Connection Lost",
        description: "Lost connection to the game server",
        variant: "destructive",
      });
      setIsInGame(false);
      setWaitingForOpponent(false);
      setShowGameOver(false);
      
      // Cancel any ongoing game loop
      if (gameLoopRef.current) {
        cancelAnimationFrame(gameLoopRef.current);
        gameLoopRef.current = null;
      }
    };

    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    // Clean up WebSocket connection when component unmounts
    return () => {
      if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) {
        ws.close();
      }
    };
  }, [connected, publicKey]);

  // Handle drawing the game state and updating
  const handleGameMessage = (data: any) => {
    switch (data.type) {
      case 'waiting':
        setWaitingForOpponent(true);
        setGameRoomId(data.roomId);
        toast({
          title: "Waiting for Opponent",
          description: "Please wait while we find another player",
        });
        break;
        
      case 'game_start':
        setPlayerNumber(data.playerNumber);
        setIsInGame(true);
        setWaitingForOpponent(false);
        setShowGameOver(false);
        
        // Play game start sound
        if (!isMuted) soundManager.play('gameStart');
        
        toast({
          title: "Game Started",
          description: `You are Player ${data.playerNumber}`,
        });
        break;
        
      case 'game_state':
        lastGameStateRef.current = data.state;
        
        // Check if ball hit a paddle (compare with previous state if available)
        if (previousGameState && data.state) {
          // Detect paddle hit (when ball direction changes horizontally)
          if (previousGameState.ball.dx !== data.state.ball.dx && 
             (data.state.ball.x < 50 || data.state.ball.x > 750)) {
            if (!isMuted) soundManager.play('paddle');
          }
          // Detect wall hit (when ball direction changes vertically)
          else if (previousGameState.ball.dy !== data.state.ball.dy) {
            if (!isMuted) soundManager.play('wall');
          }
          
          // Detect score change
          if (previousGameState.score.p1 !== data.state.score.p1 || 
              previousGameState.score.p2 !== data.state.score.p2) {
            if (!isMuted) soundManager.play('score');
          }
        }
        
        // Store this state for next comparison
        previousGameState = data.state;
        
        // Render the game state
        requestAnimationFrame(() => drawGame(data.state));
        break;
        
      case 'countdown':
        setCountdown(data.count);
        // Play countdown sound
        if (!isMuted) soundManager.play('countdown');
        break;
        
      case 'round_start':
        setCountdown(null);
        break;
        
      case 'game_over':
        setIsWinner(data.winner);
        setShowGameOver(true);
        setIsInGame(false);
        
        // Play game over sound
        if (!isMuted) soundManager.play('gameOver');
        
        handleGameOver(data.winner);
        break;
        
      case 'payout_notification':
        // Backup notification for payout (in case the main one wasn't received)
        const payoutTxUrl = data.signature.startsWith('simulated') 
          ? null 
          : `https://explorer.solana.com/tx/${data.signature}?cluster=devnet`;
          
        toast({
          title: "Winnings Received!",
          description: (
            <div>
              <p className="mb-1">You received {data.winnings} SOL in winnings!</p>
              {payoutTxUrl && (
                <a 
                  href={payoutTxUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-xs underline text-blue-400 hover:text-blue-300"
                >
                  View transaction on Solana Explorer
                </a>
              )}
            </div>
          ),
          variant: "default",
          duration: 8000,
        });
        break;
        
      case 'opponent_disconnected':
        // If the game_over message isn't sent separately, handle it as a win
        toast({
          title: "Victory by Forfeit!",
          description: "Your opponent has disconnected. You win by default!",
          variant: "default",
        });
        setIsWinner(true);
        setShowGameOver(true);
        setIsInGame(false);
        setWaitingForOpponent(false);
        
        // Play game over sound
        if (!isMuted) soundManager.play('gameOver');
        break;
        
      case 'payout_complete':
        // When payout is processed successfully
        const txUrl = data.signature.startsWith('simulated') 
          ? null 
          : `https://explorer.solana.com/tx/${data.signature}?cluster=devnet`;
          
        toast({
          title: "Payout Complete!",
          description: (
            <div>
              <p className="mb-1">You received {data.winnings} SOL in winnings!</p>
              {txUrl && (
                <a 
                  href={txUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-xs underline text-blue-400 hover:text-blue-300"
                >
                  View transaction on Solana Explorer
                </a>
              )}
            </div>
          ),
          variant: "default",
          duration: 8000, // Show for longer so user can click the link
        });
        break;
        
      case 'error':
        // Handle any server errors
        toast({
          title: "Error",
          description: data.message || "An unknown error occurred",
          variant: "destructive", 
        });
        break;
    }
  };

  // Storing previous game state for sound effect triggers
  let previousGameState: GameState | null = null;

  const drawGame = (gameState: GameState) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas with deep blue color (synthwave style)
    const gradient = ctx.createLinearGradient(0, 0, 0, 600);
    gradient.addColorStop(0, '#000033');
    gradient.addColorStop(1, '#330033');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 800, 600);

    // Draw grid/background (synthwave grid effect)
    drawSynthwaveGrid(ctx);

    // Draw center line (neon glow)
    ctx.strokeStyle = '#00ffff';
    ctx.lineWidth = 4;
    ctx.setLineDash([10, 15]);
    ctx.shadowColor = '#00ffff';
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.moveTo(400, 0);
    ctx.lineTo(400, 600);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.shadowBlur = 0;

    // Draw paddles with neon glow - highlight player's paddle 
    const leftPaddleIsPlayer = playerNumber === 1;
    const rightPaddleIsPlayer = playerNumber === 2;
    
    // Draw left paddle (Player 1)
    drawPaddle(ctx, 10, gameState.paddles.p1, 20, 100, '#ff00ff', leftPaddleIsPlayer);
    
    // Draw right paddle (Player 2)
    drawPaddle(ctx, 770, gameState.paddles.p2, 20, 100, '#00ffff', rightPaddleIsPlayer);

    // Draw ball with neon glow
    drawBall(ctx, gameState.ball.x, gameState.ball.y, 10);

    // Draw scores
    drawScores(ctx, gameState.score, playerNumber);
    
    // Draw countdown if active
    if (countdown !== null) {
      drawCountdown(ctx, countdown);
    }
  };

  // Draw a retrowave grid for background
  const drawSynthwaveGrid = (ctx: CanvasRenderingContext2D) => {
    ctx.lineWidth = 1;
    
    // Horizontal lines (perspective)
    for (let y = 50; y < 600; y += 40) {
      const alpha = 0.3 - (y / 1500);
      ctx.strokeStyle = `rgba(255, 0, 255, ${alpha})`;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(800, y);
      ctx.stroke();
    }
    
    // Vertical lines
    for (let x = 100; x < 800; x += 100) {
      if (x === 400) continue; // Skip center line as we'll draw that separately
      
      const alpha = x === 200 || x === 600 ? 0.4 : 0.2;
      ctx.strokeStyle = `rgba(0, 255, 255, ${alpha})`;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, 600);
      ctx.stroke();
    }
  };

  // Draw a paddle with neon glow effect
  const drawPaddle = (
    ctx: CanvasRenderingContext2D, 
    x: number, 
    y: number, 
    width: number, 
    height: number, 
    color: string,
    isPlayer: boolean = false // Indicate if this is the player's paddle
  ) => {
    // Increase glow effect for player's paddle
    ctx.shadowColor = color;
    ctx.shadowBlur = isPlayer ? 25 : 15; // Stronger glow for player's paddle
    ctx.fillStyle = color;
    
    // Main paddle
    ctx.fillRect(x, y, width, height);
    
    // Inner highlight - white for opponent, bright yellow/white gradient for player
    if (isPlayer) {
      // Create gradient for player's paddle
      const gradient = ctx.createLinearGradient(
        x + width/2, y, 
        x + width/2, y + height
      );
      gradient.addColorStop(0, '#ffffff');
      gradient.addColorStop(0.5, '#ffff77');
      gradient.addColorStop(1, '#ffffff');
      
      ctx.fillStyle = gradient;
      ctx.fillRect(x + 3, y + 3, width - 6, height - 6);
      
      // Add a special marker to show this is the player's paddle
      ctx.shadowBlur = 0;
      ctx.fillStyle = color;
      
      // Draw small triangular markers on both sides of the paddle
      const markerSize = 10;
      const markerDistance = 10;
      
      // Left side marker for left paddle, right side marker for right paddle
      if (x < 400) { // Left paddle
        ctx.beginPath();
        ctx.moveTo(x - markerDistance, y + height/2);
        ctx.lineTo(x - markerDistance - markerSize, y + height/2 - markerSize);
        ctx.lineTo(x - markerDistance - markerSize, y + height/2 + markerSize);
        ctx.closePath();
        ctx.fill();
      } else { // Right paddle
        ctx.beginPath();
        ctx.moveTo(x + width + markerDistance, y + height/2);
        ctx.lineTo(x + width + markerDistance + markerSize, y + height/2 - markerSize);
        ctx.lineTo(x + width + markerDistance + markerSize, y + height/2 + markerSize);
        ctx.closePath();
        ctx.fill();
      }
    } else {
      // Regular white inner highlight for opponent's paddle
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(x + 3, y + 3, width - 6, height - 6);
    }
    
    // Reset shadow
    ctx.shadowBlur = 0;
  };

  // Draw ball with neon glow effect
  const drawBall = (ctx: CanvasRenderingContext2D, x: number, y: number, radius: number) => {
    ctx.shadowColor = '#ffffff';
    ctx.shadowBlur = 20;
    
    // Outer glow
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fill();
    
    // Inner gradient
    const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius);
    gradient.addColorStop(0, '#ffffff');
    gradient.addColorStop(0.8, '#ff00ff');
    gradient.addColorStop(1, '#00ffff');
    
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.arc(x, y, radius * 0.8, 0, Math.PI * 2);
    ctx.fill();
    
    // Reset shadow
    ctx.shadowBlur = 0;
  };

  // Draw scores with neon effect
  const drawScores = (
    ctx: CanvasRenderingContext2D, 
    score: { p1: number; p2: number }, 
    playerNum: number
  ) => {
    // Determine player's color and position
    const leftColor = playerNum === 1 ? '#ff00ff' : '#00ffff'; // Player 1 is pink, Player 2 is cyan
    const rightColor = playerNum === 1 ? '#00ffff' : '#ff00ff';
    
    // First get player and opponent scores correctly based on player number
    const playerScore = playerNum === 1 ? score.p1 : score.p2;
    const opponentScore = playerNum === 1 ? score.p2 : score.p1;
    
    // Left score (Player 1's side)
    ctx.shadowColor = leftColor;
    ctx.shadowBlur = 10;
    ctx.font = '60px "Press Start 2P", monospace';
    ctx.textAlign = 'center';
    ctx.fillStyle = leftColor;
    ctx.fillText(score.p1.toString(), 200, 80);
    
    // Right score (Player 2's side)
    ctx.shadowColor = rightColor;
    ctx.shadowBlur = 10;
    ctx.fillStyle = rightColor;
    ctx.fillText(score.p2.toString(), 600, 80);
    
    // Add visual indication of which side is the player's
    ctx.font = '20px "Press Start 2P", monospace';
    
    // Display "YOU" under the player's side
    if (playerNum === 1) {
      ctx.fillStyle = '#ff00ff'; // Pink for player 1
      ctx.fillText('YOU', 200, 120);
      ctx.fillStyle = '#00ffff'; // Cyan for opponent
      ctx.fillText('OPP', 600, 120);
    } else {
      ctx.fillStyle = '#00ffff'; // Cyan for player 2
      ctx.fillText('OPP', 200, 120);
      ctx.fillStyle = '#ff00ff'; // Pink for opponent
      ctx.fillText('YOU', 600, 120);
    }
    
    // Reset shadow
    ctx.shadowBlur = 0;
  };

  // Draw countdown with neon effect
  const drawCountdown = (ctx: CanvasRenderingContext2D, count: number) => {
    ctx.shadowColor = '#ff00ff';
    ctx.shadowBlur = 20;
    ctx.font = '120px "Press Start 2P", monospace';
    ctx.fillStyle = '#ff00ff';
    ctx.textAlign = 'center';
    ctx.fillText(count.toString(), 400, 320);
    ctx.shadowBlur = 0;
  };

  // Initialize empty game board
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas dimensions to maintain proper aspect ratio
    resizeCanvas();

    // Draw initial empty board
    const gradient = ctx.createLinearGradient(0, 0, 0, 600);
    gradient.addColorStop(0, '#000033');
    gradient.addColorStop(1, '#330033');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 800, 600);
    
    // Draw initial synthwave grid
    drawSynthwaveGrid(ctx);

    // Add resize event listener
    window.addEventListener('resize', resizeCanvas);
    
    return () => window.removeEventListener('resize', resizeCanvas);
  }, []);

  const resizeCanvas = () => {
    const canvas = canvasRef.current;
    const container = canvasContainerRef.current;
    if (!canvas || !container) return;
    
    // Make canvas responsive while maintaining aspect ratio
    const containerWidth = container.clientWidth;
    const aspectRatio = 800 / 600; // 4:3 aspect ratio
    const containerHeight = containerWidth / aspectRatio;
    
    // Set canvas style dimensions (displayed size)
    canvas.style.width = `${containerWidth}px`;
    canvas.style.height = `${containerHeight}px`;
    
    // If we have a cached game state, redraw it with the new dimensions
    if (lastGameStateRef.current) {
      requestAnimationFrame(() => drawGame(lastGameStateRef.current!));
    } else {
      // Draw empty state
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const gradient = ctx.createLinearGradient(0, 0, 0, 600);
        gradient.addColorStop(0, '#000033');
        gradient.addColorStop(1, '#330033');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, 800, 600);
        drawSynthwaveGrid(ctx);
      }
    }
  };

  const handleGameOver = (isWinner: boolean) => {
    setIsWinner(isWinner);
    setShowGameOver(true);
    
    toast({
      title: isWinner ? "Victory!" : "Defeat",
      description: isWinner 
        ? "Congratulations! You won the game!" 
        : "Better luck next time!",
      variant: isWinner ? "default" : "destructive",
    });
    
    // Reset game state
    setIsInGame(false);
    setWaitingForOpponent(false);
  };

  const handlePaddleMove = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isInGame || !wsRef.current) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    
    // Get position whether mouse or touch event
    const clientY = 'touches' in e 
      ? e.touches[0].clientY 
      : (e as React.MouseEvent).clientY;
    
    const y = clientY - rect.top;
    
    // Calculate normalized position relative to the canvas
    const canvasRatio = canvas.height / rect.height;
    const scaledY = y * canvasRatio;
    
    wsRef.current.send(JSON.stringify({
      type: 'paddle_move',
      position: Math.max(0, Math.min(500, scaledY))
    }));
  };
  
  // Separate touch start handler to improve mobile responsiveness
  const handleTouchStart = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (!isInGame) return;
    
    // Prevent default behavior to avoid scrolling
    e.preventDefault();
    
    // Immediately move the paddle to the touch position
    handlePaddleMove(e);
  };

  const startGame = () => {
    if (!wsRef.current || !connected || !publicKey) return;
    
    setShowControls(false);
    setWaitingForOpponent(true);
    
    wsRef.current.send(JSON.stringify({
      type: 'join',
      stake: stake,
      wallet: publicKey.toBase58()
    }));
  };
  
  const toggleMute = () => {
    const newMuteState = soundManager.toggleMute();
    setIsMuted(newMuteState);
  };
  
  const handleStakeChange = (value: number) => {
    setStake(value);
  };
  
  const leaveGame = () => {
    if (isInGame && wsRef.current) {
      wsRef.current.send(JSON.stringify({
        type: 'leave',
        roomId: gameRoomId
      }));
    }
    
    // Reset all game state
    setIsInGame(false);
    setWaitingForOpponent(false);
    setShowGameOver(false);
    setGameRoomId(null);
    setCountdown(null);
    
    setLocation('/');
  };
  
  const playAgain = () => {
    setShowGameOver(false);
    startGame();
  };

  return (
    <div className="pong-container flex flex-col items-center p-4">
      <div className="w-full max-w-4xl">
        {/* Header with game title */}
        <div className="pong-card mb-4">
          <h1 className="pong-title">RETRO PONG</h1>
          <p className="pong-subtitle">Solana-Powered Arcade Classic</p>
          
          <div className="flex justify-between items-center">
            <Button 
              className="pong-button flex items-center gap-1"
              onClick={leaveGame}
            >
              <ArrowLeft size={16} />
              Back
            </Button>
            
            <Button 
              className="pong-button flex items-center gap-1"
              onClick={toggleMute}
            >
              {isMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
              {isMuted ? 'Unmute' : 'Mute'}
            </Button>
          </div>
        </div>
        
        {/* Game area */}
        <div className="pong-card relative" ref={canvasContainerRef}>
          {!connected ? (
            <div className="pong-message">
              <p className="mb-4">Please connect your wallet to play</p>
            </div>
          ) : showGameOver ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black bg-opacity-80 z-20">
              <h2 className="text-4xl font-bold mb-4" style={{
                color: isWinner ? '#00ffff' : '#ff00ff',
                textShadow: isWinner ? '0 0 10px #00ffff' : '0 0 10px #ff00ff',
                fontFamily: '"Press Start 2P", monospace'
              }}>
                {isWinner ? 'YOU WIN!' : 'GAME OVER'}
              </h2>
              <p className="text-white text-xl mb-6">
                {isWinner ? 'You earned rewards!' : 'Better luck next time!'}
              </p>
              <div className="flex gap-4">
                <Button className="pong-button" onClick={playAgain}>
                  Play Again
                </Button>
                <Button className="pong-button" onClick={leaveGame}>
                  Main Menu
                </Button>
              </div>
            </div>
          ) : waitingForOpponent ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black bg-opacity-80 z-20">
              <h2 className="text-2xl font-bold mb-4 text-white">
                Waiting for opponent...
              </h2>
              <div className="animate-pulse text-[#ff00ff] text-lg">
                Finding a match for you
              </div>
            </div>
          ) : showControls ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black bg-opacity-80 z-20">
              <h2 className="text-2xl font-bold mb-4 text-[#00ffff]">
                Game Settings
              </h2>
              
              <div className="mb-6">
                <label className="block text-white mb-2">Stake Amount (SOL):</label>
                <div className="flex gap-2">
                  {[0.1, 0.5, 1.0].map((amount) => (
                    <button 
                      key={amount}
                      className={`px-4 py-2 rounded ${stake === amount ? 'bg-[#ff00ff] text-white' : 'bg-black text-[#ff00ff] border border-[#ff00ff]'}`}
                      onClick={() => handleStakeChange(amount)}
                    >
                      {amount} SOL
                    </button>
                  ))}
                </div>
              </div>
              
              <Button className="pong-button" onClick={startGame}>
                Start Game
              </Button>
            </div>
          ) : null}
          
          <canvas
            ref={canvasRef}
            width={800}
            height={600}
            onMouseMove={handlePaddleMove}
            onTouchStart={handleTouchStart}
            onTouchMove={(e) => {
              e.preventDefault(); // Prevent scrolling when touching the canvas
              handlePaddleMove(e);
            }}
            className="pong-canvas"
            style={{ touchAction: 'none' }} // Explicitly disable browser touch actions
          />
          
          {/* Game context message */}
          {isInGame && (
            <div className="mt-2 text-center text-sm text-[#00ffff]">
              {playerNumber === 1 ? 'You are on the LEFT' : 'You are on the RIGHT'}
            </div>
          )}
        </div>
        
        {/* Controls explanation */}
        <div className="pong-card mt-4">
          <h3 className="text-[#00ffff] text-xl mb-2 text-center">How to Play</h3>
          <p className="text-white text-sm">
            • Use your mouse or touch to move your paddle up and down<br />
            • First player to score 12 points wins<br />
            • The game automatically alternates serve direction<br />
            • Winner gets the stake amount from the opponent
          </p>
        </div>
      </div>
    </div>
  );
}