import { useWallet } from "@solana/wallet-adapter-react";
import { WalletMultiButton } from "@solana/wallet-adapter-react-ui";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useEffect } from "react";

export default function WalletButtons() {
  const { connected, wallet, publicKey } = useWallet();
  const { toast } = useToast();

  useEffect(() => {
    if (connected) {
      toast({
        title: "Wallet Connected",
        description: `Connected to ${wallet?.adapter.name}`,
      });
    }
  }, [connected, wallet]);

  const shortenAddress = (address: string) => {
    return `${address.slice(0, 4)}...${address.slice(-4)}`;
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <WalletMultiButton 
          className="!bg-[#ff00ff] hover:!bg-[#cc00cc] !text-white !font-bold !px-4 !py-2 !rounded 
                     !border-2 !border-[#ffffff33] !shadow-lg" 
          style={{
            textShadow: '0 0 5px #ffffff',
            boxShadow: '0 0 10px #ff00ff, 0 0 20px #ff00ff33'
          }}
        />
        {connected && publicKey && (
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-full bg-[#00ffaa] animate-pulse" 
              style={{boxShadow: '0 0 10px #00ffaa'}} />
            <span className="text-sm text-[#ffffff]">
              {shortenAddress(publicKey.toString())}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}