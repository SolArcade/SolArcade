import { useWallet } from "@solana/wallet-adapter-react";
import { useConnection } from "@solana/wallet-adapter-react";
import { useQuery } from "@tanstack/react-query";
import { LAMPORTS_PER_SOL } from "@solana/web3.js";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

export default function StatusDisplay() {
  const { publicKey } = useWallet();
  const { connection } = useConnection();

  const { data: balance, isLoading, error } = useQuery({
    queryKey: ["balance", publicKey?.toBase58()],
    queryFn: async () => {
      if (!publicKey) return null;
      const balance = await connection.getBalance(publicKey);
      return balance / LAMPORTS_PER_SOL;
    },
    enabled: !!publicKey,
    // Refresh every 10 seconds
    refetchInterval: 10000,
  });

  if (!publicKey) return null;

  return (
    <div className="space-y-4">
      <div className="grid gap-4">
        <div className="flex justify-between items-center">
          <span className="text-sm text-[#bbbbff]">WALLET BALANCE</span>
          <span className="text-lg font-bold text-[#00ffaa]" style={{textShadow: '0 0 8px currentColor'}}>
            {isLoading ? (
              <Loader2 className="h-6 w-6 animate-spin text-[#ff00ff]" />
            ) : error ? (
              <span className="text-[#ff5577]">Error loading balance</span>
            ) : (
              `${balance?.toFixed(4) || '0.0000'} SOL`
            )}
          </span>
        </div>
        <div className="flex justify-between items-center mt-2">
          <span className="text-sm text-[#bbbbff]">WALLET ADDRESS</span>
          <span className="text-sm font-mono text-[#ffffff]">
            {publicKey.toString().slice(0, 4)}...{publicKey.toString().slice(-4)}
          </span>
        </div>
      </div>
    </div>
  );
}