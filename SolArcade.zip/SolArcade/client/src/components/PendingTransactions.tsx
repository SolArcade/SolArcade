import { useEffect, useState } from 'react';
import { useConnection, useWallet } from '@solana/wallet-adapter-react';
import { useTransactionContext } from '../context/TransactionContext';
import { Card } from '@/components/ui/card';
import { Loader2, CheckCircle, AlertCircle, Clock } from 'lucide-react';
import { Transaction, TransactionContext } from '../lib/transactionStore';

interface PendingTx {
  signature: string;
  amount: number;
  pongCredits: number;
  timestamp: number;
  status?: string;
  confirmations?: number;
  error?: string;
}

export default function PendingTransactions() {
  const { connection } = useConnection();
  const wallet = useWallet();
  const { pendingTransactions } = useTransactionContext();
  const [apiPendingTransactions, setApiPendingTransactions] = useState<PendingTx[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Fetch pending transactions from API
  useEffect(() => {
    const fetchPendingTransactions = async () => {
      if (!wallet.publicKey) {
        setApiPendingTransactions([]);
        setIsLoading(false);
        return;
      }
      
      try {
        const response = await fetch(`/api/pending-transactions/${wallet.publicKey.toString()}`);
        if (response.ok) {
          const data = await response.json();
          setApiPendingTransactions(data);
        } else {
          console.error('Failed to fetch pending transactions:', response.status);
        }
      } catch (error) {
        console.error('Error fetching pending transactions:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchPendingTransactions();
    
    // Set up an interval to periodically refresh pending transactions
    const interval = setInterval(fetchPendingTransactions, 10000);
    
    return () => clearInterval(interval);
  }, [wallet.publicKey]);
  
  // Filter out duplicates between context and API
  const mergedTransactions = () => {
    // Extract signatures from context transactions
    const contextSignatures = new Set(
      pendingTransactions
        .filter(tx => tx.signature)
        .map(tx => tx.signature as string)
    );
    
    // Filter API transactions to exclude those already in context
    const filteredApiTxs = apiPendingTransactions.filter(
      tx => !contextSignatures.has(tx.signature)
    );
    
    // Convert API transactions to match the context transaction format
    const formattedApiTxs = filteredApiTxs.map((apiTx: PendingTx) => ({
      id: apiTx.signature,
      signature: apiTx.signature,
      amount: apiTx.amount,
      pongCredits: apiTx.pongCredits,
      status: mapApiStatusToContextStatus(apiTx.status || 'pending'),
      timestamp: apiTx.timestamp,
      lastUpdated: Date.now(),
      confirmations: apiTx.confirmations || 0,
      error: apiTx.error
    }));
    
    // Combine and sort by timestamp (newest first)
    return [...pendingTransactions, ...formattedApiTxs].sort(
      (a, b) => b.timestamp - a.timestamp
    );
  };
  
  // Map API status strings to context status values
  const mapApiStatusToContextStatus = (apiStatus: string): Transaction['status'] => {
    switch (apiStatus.toLowerCase()) {
      case 'pending':
        return 'pending';
      case 'confirming':
        return 'confirming';
      case 'confirmed':
      case 'completed':
        return 'completed';
      case 'failed':
        return 'failed';
      default:
        return 'unknown';
    }
  };
  
  // Get the appropriate icon based on status
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="h-5 w-5 text-yellow-500" />;
      case 'confirming':
        return <Loader2 className="h-5 w-5 text-blue-500 animate-spin" />;
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'failed':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      default:
        return <Clock className="h-5 w-5 text-gray-500" />;
    }
  };
  
  // Get the progress bar color based on status
  const getProgressColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-500';
      case 'confirming':
        return 'bg-blue-500';
      case 'completed':
        return 'bg-green-500';
      case 'failed':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };
  
  // Get progress percentage based on status
  const getProgressPercentage = (status: string, confirmations: number = 0) => {
    switch (status) {
      case 'pending':
        return 25;
      case 'confirming':
        return 50 + Math.min(confirmations * 10, 40);
      case 'completed':
        return 100;
      case 'failed':
        return 100;
      default:
        return 0;
    }
  };
  
  // No pending transactions and not loading
  if (!isLoading && mergedTransactions().length === 0) {
    return null;
  }
  
  return (
    <div className="mb-6 space-y-2">
      <h3 className="text-lg font-semibold mb-2">Pending Transactions</h3>
      
      {isLoading ? (
        <Card className="p-4 flex items-center justify-center">
          <Loader2 className="h-5 w-5 animate-spin mr-2" />
          <span>Loading transactions...</span>
        </Card>
      ) : (
        <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
          {mergedTransactions().map((tx: Transaction) => (
            <Card key={tx.id} className="p-3 shadow-sm border border-neutral-800 bg-zinc-900/50">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    {getStatusIcon(tx.status)}
                    <span className="font-medium capitalize">{tx.status}</span>
                    {tx.status === 'confirming' && (
                      <span className="text-xs text-neutral-400">
                        {tx.confirmations || 0} confirmation{(tx.confirmations || 0) !== 1 ? 's' : ''}
                      </span>
                    )}
                  </div>
                  
                  <div className="flex flex-col mt-1 text-sm text-neutral-300">
                    <div className="flex justify-between">
                      <span>Amount:</span>
                      <span className="font-medium">{TransactionContext.formatSolAmount(tx.amount)} SOL</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Credits:</span>
                      <span className="font-medium">{tx.pongCredits} credits</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Time:</span>
                      <span className="text-neutral-400">
                        {TransactionContext.formatRelativeTime(tx.timestamp)}
                      </span>
                    </div>
                  </div>
                  
                  {tx.signature && (
                    <div className="mt-1 truncate text-xs text-neutral-500">
                      {tx.signature.slice(0, 12)}...{tx.signature.slice(-4)}
                    </div>
                  )}
                  
                  {tx.error && (
                    <div className="mt-1 text-xs text-red-400">
                      Error: {typeof tx.error === 'string' ? tx.error : 'Transaction failed'}
                    </div>
                  )}
                </div>
              </div>
              
              {/* Progress bar */}
              <div className="mt-2 h-1 w-full bg-zinc-800 rounded-full overflow-hidden">
                <div 
                  className={`h-full ${getProgressColor(tx.status)} transition-all duration-500`}
                  style={{ width: `${getProgressPercentage(tx.status, tx.confirmations || 0)}%` }}
                />
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}