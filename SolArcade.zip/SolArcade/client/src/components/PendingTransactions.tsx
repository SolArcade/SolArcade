import { useEffect, useState } from 'react';
import { useConnection, useWallet } from '@solana/wallet-adapter-react';
import { useTransactionContext, Transaction } from '../context/TransactionContext';
import { Card } from '@/components/ui/card';
import { Loader2, CheckCircle, AlertCircle, Clock, ExternalLink } from 'lucide-react';

// Utility function to map API status strings to internal transaction status
function mapApiStatusToContextStatus(apiStatus: string): Transaction['status'] {
  switch (apiStatus.toLowerCase()) {
    case 'completed':
    case 'finalized':
      return 'finalized';
    case 'confirmed':
      return 'confirmed';
    case 'processed':
    case 'confirming':
      return 'confirming';
    case 'failed':
      return 'failed';
    case 'pending':
    default:
      return 'pending';
  }
}

interface PendingTx {
  signature: string;
  amount: number;
  stakeAmount: number;
  timestamp: number;
  status?: string;
  confirmations?: number;
  error?: string;
}

export default function PendingTransactions() {
  const { connection } = useConnection();
  const wallet = useWallet();
  const { pendingTransactions } = useTransactionContext();
  const [apiPendingTransactions, setApiPendingTransactions] = useState<PendingTx[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Enhanced fetching system with real-time updates
  useEffect(() => {
    // Main fetch function
    const fetchPendingTransactions = async () => {
      if (!wallet.publicKey) {
        setApiPendingTransactions([]);
        setIsLoading(false);
        return;
      }
      
      try {
        const response = await fetch(`/api/pending-transactions/${wallet.publicKey.toString()}`);
        if (response.ok) {
          const data = await response.json();
          
          // Log info about pending transactions
          if (data.length > 0) {
            console.log(`Fetched ${data.length} pending transactions from server`);
          }
          
          setApiPendingTransactions(data);
        } else {
          console.error('Failed to fetch pending transactions:', response.status);
        }
      } catch (error) {
        console.error('Error fetching pending transactions:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    // Initial fetch when component mounts
    fetchPendingTransactions();
    
    // Set up real-time event listeners for transaction updates
    const handleBalanceUpdated = (event: Event) => {
      // When SOL balance is updated, refresh to show completed transactions
      console.log('SOL balance updated event detected, refreshing transactions');
      fetchPendingTransactions();
    };
    
    const handleTransactionUpdate = (event: Event) => {
      // When a transaction status changes, refresh
      console.log('Transaction update event detected, refreshing transactions');
      fetchPendingTransactions();
    };
    
    const handleSocketConnect = () => {
      console.log('Socket reconnected, refreshing transactions');
      fetchPendingTransactions();
    };
    
    // Register for custom events
    window.addEventListener('solBalanceUpdated', handleBalanceUpdated);
    window.addEventListener('transactionUpdated', handleTransactionUpdate);
    window.addEventListener('socketConnected', handleSocketConnect);
    
    // Set up an interval to periodically refresh (as backup to events)
    // Use a slightly longer interval since we have event-based updates now
    const interval = setInterval(fetchPendingTransactions, 15000); // 15 seconds
    
    // Cleanup function
    return () => {
      clearInterval(interval);
      
      // Remove event listeners
      window.removeEventListener('solBalanceUpdated', handleBalanceUpdated);
      window.removeEventListener('transactionUpdated', handleTransactionUpdate);
      window.removeEventListener('socketConnected', handleSocketConnect);
    };
  }, [wallet.publicKey]);
  
  /**
   * Enhanced storage system with better error handling and recovery
   */
  
  // Helper function to store pending transactions in localStorage with versioning
  const saveToLocalStorage = (transactions: Transaction[]) => {
    try {
      // Add version and timestamp for recovery
      const storageData = {
        version: 2, // Increment version when storage format changes
        timestamp: Date.now(),
        transactions: transactions,
        walletAddress: wallet.publicKey?.toString() || null
      };
      
      localStorage.setItem('pendingTransactions', JSON.stringify(storageData));
      console.log('Saved pending transactions to localStorage:', transactions.length);
    } catch (e) {
      console.error('Error saving pending transactions to localStorage:', e);
    }
  };
  
  // Helper function to load pending transactions from localStorage with fallback
  const loadFromLocalStorage = (): Transaction[] => {
    try {
      const stored = localStorage.getItem('pendingTransactions');
      if (stored) {
        const parsed = JSON.parse(stored);
        
        // Check if new format (with version)
        if (parsed.version && parsed.transactions) {
          // Verify wallet address matches current wallet if available
          if (wallet.publicKey && parsed.walletAddress && 
              parsed.walletAddress !== wallet.publicKey.toString()) {
            console.log('Wallet address changed, ignoring stored transactions');
            return [];
          }
          
          console.log(`Loaded pending transactions from localStorage (v${parsed.version}):`, 
            parsed.transactions.length);
          return parsed.transactions;
        }
        
        // Legacy format (direct array)
        if (Array.isArray(parsed)) {
          console.log('Loaded pending transactions from localStorage (legacy format):', parsed.length);
          return parsed;
        }
      }
    } catch (e) {
      console.error('Error loading pending transactions from localStorage:', e);
    }
    return [];
  };
  
  // Handle local pending transactions to display immediately
  const [localPendingTransactions, setLocalPendingTransactions] = useState<Transaction[]>(() => {
    // Initialize with stored transactions
    return loadFromLocalStorage();
  });
  
  // Save local pending transactions to localStorage whenever they change
  useEffect(() => {
    saveToLocalStorage(localPendingTransactions);
  }, [localPendingTransactions]);
  
  // Add new pending transaction immediately - called through global window method
  useEffect(() => {
    // Define the function that will be assigned to window
    const showPendingTx = (signature: string, amount: number, stakeAmount: number) => {
      console.log(`Adding pending transaction to local state: ${signature || 'no-signature-yet'} - ${amount} SOL for game stake`);
      
      // Create a transaction object
      const newTx: Transaction = {
        id: signature || `pending-${Date.now()}`,
        signature: signature || undefined,
        type: 'gameStake',
        amount: amount,
        stakeAmount: stakeAmount,
        status: 'pending',
        timestamp: Date.now(),
        lastUpdated: Date.now(),
        confirmations: 0
      };
      
      // Save immediately to localStorage first for maximum persistence
      const storedTxs = loadFromLocalStorage();
      
      // Check if this transaction already exists in stored transactions
      const existsInStorage = storedTxs.some(tx => 
        (signature && tx.signature === signature) || 
        tx.id === newTx.id
      );
      
      let updatedStoredTxs: Transaction[];
      
      if (existsInStorage) {
        // Update existing transaction in localStorage
        updatedStoredTxs = storedTxs.map(tx => {
          if ((signature && tx.signature === signature) || tx.id === newTx.id) {
            return { ...tx, ...newTx };
          }
          return tx;
        });
      } else {
        // Add new transaction to localStorage
        updatedStoredTxs = [...storedTxs, newTx];
      }
      
      // Save the updated transactions to localStorage immediately
      saveToLocalStorage(updatedStoredTxs);
      
      // Now update the component state - this ensures we get persistence first
      setLocalPendingTransactions(prev => {
        // Check if this transaction already exists in component state
        const exists = prev.some(tx => 
          (signature && tx.signature === signature) || 
          tx.id === newTx.id
        );
        
        if (exists) {
          // Update existing transaction
          return prev.map(tx => {
            if ((signature && tx.signature === signature) || tx.id === newTx.id) {
              return { ...tx, ...newTx };
            }
            return tx;
          });
        } else {
          // Add new transaction
          return [...prev, newTx];
        }
      });
      
      // Dispatch a custom event to notify other components
      const event = new CustomEvent('pendingTransactionAdded', { 
        detail: { transaction: newTx }
      });
      window.dispatchEvent(event);
    };
    
    // Add to global window object
    window.showPendingTransaction = showPendingTx;
    
    // Cleanup
    return () => {
      // TypeScript-safe way to clear the handler
      window.showPendingTransaction = undefined;
    };
  }, []);
  
  // CRITICAL FIX: Enhanced transaction merging with multi-source deduplication and refund grouping
  const mergedTransactions = () => {
    console.log(`Merging transactions from multiple sources - Context: ${pendingTransactions.length}, Local: ${localPendingTransactions.length}, API: ${apiPendingTransactions.length}`);
    
    // Create a Map to store all transactions for better deduplication
    // Using a combination of id and signature as the key when available
    const mergedMap = new Map<string, Transaction>();
    
    // Special map for refund transactions to prevent duplicates showing
    const refundGroups = new Map<string, Transaction[]>();
    
    // First add context transactions (typically most current)
    for (const tx of pendingTransactions) {
      try {
        // Special handling for refund transactions
        if (tx.type === 'refund' || (tx.description && tx.description.includes('refund'))) {
          // Group refunds by approximate time and amount to prevent duplicates
          const time = Math.floor(tx.timestamp / 60000); // Round to nearest minute
          const amount = Math.round(tx.amount * 100) / 100; // Round to 2 decimal places
          const groupKey = `refund-${time}-${amount}`;
          
          if (!refundGroups.has(groupKey)) {
            refundGroups.set(groupKey, [tx]);
          } else {
            // Add to the group for later processing
            refundGroups.get(groupKey)?.push(tx);
          }
        } else {
          // Regular transactions: use signature as primary key when available, fall back to id
          const key = tx.signature || tx.id;
          mergedMap.set(key, tx);
        }
      } catch (e) {
        console.error("Error processing context transaction:", e);
      }
    }
    
    // Next add localStorage transactions (reliable for state persistence)
    for (const tx of localPendingTransactions) {
      try {
        // Special handling for refund transactions
        if (tx.type === 'refund' || (tx.description && tx.description.includes('refund'))) {
          // Group refunds by approximate time and amount
          const time = Math.floor(tx.timestamp / 60000);
          const amount = Math.round(tx.amount * 100) / 100;
          const groupKey = `refund-${time}-${amount}`;
          
          if (!refundGroups.has(groupKey)) {
            refundGroups.set(groupKey, [tx]);
          } else {
            // Add to the group for later processing
            refundGroups.get(groupKey)?.push(tx);
          }
        } else {
          // Regular transaction handling
          const key = tx.signature || tx.id;
          // Only add if not already present, or update if this one is newer
          const existing = mergedMap.get(key);
          if (!existing || tx.lastUpdated > existing.lastUpdated) {
            mergedMap.set(key, tx);
          }
        }
      } catch (e) {
        console.error("Error processing localStorage transaction:", e);
      }
    }
    
    // Finally add API transactions (source of truth from server)
    try {
      // Create well-formatted transaction objects from API data
      const formattedApiTxs = apiPendingTransactions.map((apiTx: PendingTx) => {
        try {
          return {
            id: apiTx.signature || `api-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
            signature: apiTx.signature,
            type: 'gameStake' as const,
            amount: apiTx.amount,
            stakeAmount: apiTx.stakeAmount || apiTx.amount, // Fallback to amount if stakeAmount is not provided
            status: mapApiStatusToContextStatus(apiTx.status || 'pending'),
            timestamp: apiTx.timestamp,
            lastUpdated: Date.now(),
            confirmations: apiTx.confirmations || 0,
            error: apiTx.error
          } as Transaction;
        } catch (e) {
          console.error("Error formatting API transaction:", e);
          return null;
        }
      }).filter(Boolean) as Transaction[];
      
      // Add formatted API transactions to the merged map
      for (const tx of formattedApiTxs) {
        const key = tx.signature || tx.id;
        
        // API transactions take precedence for completed transactions
        const existing = mergedMap.get(key);
        if (!existing || ['confirmed', 'finalized', 'completed'].includes(tx.status)) {
          mergedMap.set(key, tx);
        }
      }
    } catch (e) {
      console.error("Error processing API transactions:", e);
    }
    
    // Special case: Also check for non-signature matches in pre-submission state
    // This handles cases where a transaction was pre-created without a signature
    try {
      const preSubmissionTxs = [...localPendingTransactions, ...pendingTransactions]
        .filter(tx => !tx.signature && tx.status === 'pending');
        
      for (const preTx of preSubmissionTxs) {
        // Find matching transactions by amount and approximate time
        for (const apiTx of apiPendingTransactions) {
          if (apiTx.signature && apiTx.amount === preTx.amount && 
              Math.abs(apiTx.timestamp - preTx.timestamp) < 60000) { // Within a minute
            // Found a likely match - update with API data
            const updatedTx = {
              ...preTx,
              signature: apiTx.signature,
              status: mapApiStatusToContextStatus(apiTx.status || 'pending'),
              confirmations: apiTx.confirmations || 0,
              lastUpdated: Date.now()
            };
            // Add to map with signature as key
            mergedMap.set(apiTx.signature, updatedTx);
            
            // Also update localStorage for persistence
            setLocalPendingTransactions(prev => 
              prev.map(tx => tx.id === preTx.id ? updatedTx : tx)
            );
          }
        }
      }
    } catch (e) {
      console.error("Error processing pre-submission transactions:", e);
    }
    
    // Process refund groups and add the most relevant transaction from each group
    refundGroups.forEach((txGroup: Transaction[], groupKey: string) => {
      try {
        if (txGroup.length > 0) {
          // Sort by status precedence (finalized > confirmed > confirming > pending)
          // and then by timestamp (newest first)
          const sortedGroup = txGroup.sort((a: Transaction, b: Transaction) => {
            // First sort by status importance
            const statusPriority: Record<string, number> = {
              'finalized': 4,
              'confirmed': 3,
              'confirming': 2,
              'pending': 1,
              'failed': 0
            };
            
            const aPriority = statusPriority[a.status as keyof typeof statusPriority] || 0;
            const bPriority = statusPriority[b.status as keyof typeof statusPriority] || 0;
            
            if (bPriority !== aPriority) {
              return bPriority - aPriority;
            }
            
            // If same status, use newest first
            return b.timestamp - a.timestamp;
          });
          
          // Add the most relevant transaction from the group to the merged map
          if (sortedGroup.length > 0) {
            const bestTx = sortedGroup[0];
            const key = bestTx.signature || bestTx.id;
            mergedMap.set(key, bestTx);
          }
        }
      } catch (e) {
        console.error("Error processing refund group:", e);
      }
    });
    
    // Convert map to array
    const mergedArray: Transaction[] = Array.from(mergedMap.values());
    
    // Filter out completed/failed transactions older than 30 minutes
    const filteredArray = mergedArray.filter(tx => {
      try {
        const isCompletedOrFailed = ['finalized', 'failed'].includes(tx.status);
        const isTooOld = Date.now() - tx.timestamp > 30 * 60 * 1000; // 30 minutes
        return !(isCompletedOrFailed && isTooOld);
      } catch (e) {
        console.error("Error filtering transaction:", e);
        return false; // Exclude problematic transactions
      }
    });
    
    // Sort by timestamp (newest first)
    return filteredArray.sort((a, b) => b.timestamp - a.timestamp);
  };
  
  // Get the appropriate icon based on status
  const getStatusIcon = (status: Transaction['status']) => {
    switch (status) {
      case 'pending':
        return <Clock className="h-5 w-5 text-yellow-500" />;
      case 'confirming':
        return <Loader2 className="h-5 w-5 text-blue-500 animate-spin" />;
      case 'confirmed':
        return <Loader2 className="h-5 w-5 text-blue-500 animate-spin" />;
      case 'finalized':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'failed':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      default:
        return <Clock className="h-5 w-5 text-gray-500" />;
    }
  };
  
  // Get the progress bar color based on status
  const getProgressColor = (status: Transaction['status']) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-500';
      case 'confirming':
        return 'bg-blue-500';
      case 'confirmed':
        return 'bg-blue-500';
      case 'finalized':
        return 'bg-green-500';
      case 'failed':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };
  
  // Get progress percentage based on status
  const getProgressPercentage = (status: Transaction['status'], confirmations: number = 0) => {
    switch (status) {
      case 'pending':
        return 25;
      case 'confirming':
        return 50 + Math.min(confirmations * 10, 40);
      case 'confirmed':
        return 75;
      case 'finalized':
        return 100;
      case 'failed':
        return 100;
      default:
        return 0;
    }
  };
  
  // No pending transactions and not loading
  if (!isLoading && mergedTransactions().length === 0) {
    return null;
  }
  
  return (
    <div className="mb-6 space-y-2">
      <h3 className="text-lg font-semibold mb-2">Pending Transactions</h3>
      
      {isLoading ? (
        <Card className="p-4 flex items-center justify-center">
          <Loader2 className="h-5 w-5 animate-spin mr-2" />
          <span>Loading transactions...</span>
        </Card>
      ) : (
        <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
          {mergedTransactions().map((tx: Transaction) => {
            // Get appropriate card styling based on transaction type
            const isRefund = (tx.type && tx.type.includes('refund')) || tx.description?.includes('refund');
            const isWinnings = (tx.type && (tx.type.includes('win') || tx.type.includes('payout')));
            
            const cardBorder = isRefund 
              ? 'border-l-[#00ffff]' 
              : isWinnings
                ? 'border-l-[#ffff00]'
                : 'border-l-[#ff00ff]';
                
            const cardBg = isRefund 
              ? 'bg-gradient-to-r from-[#00ffff08] to-[#00ffff14]' 
              : isWinnings
                ? 'bg-gradient-to-r from-[#ffff0008] to-[#ffff0014]'
                : 'bg-gradient-to-r from-[#ff00ff08] to-transparent';
            
            return (
              <Card key={tx.id} className={`p-3 shadow-sm border border-zinc-800 ${cardBg} border-l-4 ${cardBorder}`}>
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(tx.status)}
                      <span className={`font-medium capitalize ${
                        tx.status === 'failed' 
                          ? 'text-red-400' 
                          : tx.status === 'finalized' 
                            ? 'text-green-400' 
                            : 'text-yellow-400'
                      }`}>{tx.status}</span>
                      {tx.status === 'confirming' && (
                        <span className="text-xs text-neutral-400">
                          {tx.confirmations || 0} confirmation{(tx.confirmations || 0) !== 1 ? 's' : ''}
                        </span>
                      )}
                    </div>
                    
                    <div className="flex flex-col mt-1 text-sm text-neutral-300">
                      <div className="flex justify-between">
                        <span>Amount:</span>
                        <span className={`font-medium ${
                          (tx.type && tx.type.includes('refund')) || tx.description?.includes('refund')
                            ? 'text-cyan-400' 
                            : (tx.type && (tx.type.includes('win') || tx.type.includes('payout')))
                              ? 'text-yellow-400'
                              : 'text-green-400'
                        }`}>
                          {tx.amount.toFixed(3)} SOL
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Transaction Type:</span>
                        <span className="font-medium flex items-center">
                          {/* Show appropriate emoji for transaction type */}
                          <span className="mr-1">
                            {(tx.type && tx.type.includes('refund')) || tx.description?.includes('refund')
                              ? '↩️' 
                              : (tx.type && (tx.type.includes('win') || tx.type.includes('payout')))
                                ? '🏆'
                                : (tx.type && tx.type.includes('stake'))
                                  ? '🎮'
                                  : '💰'}
                          </span>
                          {(tx.type && tx.type.includes('refund')) || tx.description?.includes('refund')
                            ? 'Game Refund' 
                            : (tx.type && (tx.type.includes('win') || tx.type.includes('payout')))
                              ? 'Game Winnings'
                              : 'Game Stake'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Time:</span>
                        <span className="text-neutral-400">
                          {new Date(tx.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                    </div>
                    
                    {tx.signature && (
                      <div className="mt-1 truncate text-xs text-neutral-500">
                        {tx.signature.slice(0, 12)}...{tx.signature.slice(-4)}
                      </div>
                    )}
                    
                    {tx.error && (
                      <div className="mt-1 text-xs text-red-400">
                        Error: {typeof tx.error === 'string' ? tx.error : 'Transaction failed'}
                      </div>
                    )}
                  </div>
                </div>
                
                {/* Progress bar */}
                <div className="mt-2 h-1 w-full bg-zinc-800 rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${getProgressColor(tx.status)} transition-all duration-500`}
                    style={{ width: `${getProgressPercentage(tx.status, tx.confirmations || 0)}%` }}
                  />
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}