import { useWallet } from "@solana/wallet-adapter-react";
import { useConnection } from "@solana/wallet-adapter-react";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { sendTransaction } from "@/lib/wallet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";
import { useTransactionPersistence } from "../App";

interface PendingTransaction {
  id: string;
  signature?: string;
  amount: number;
  timestamp: number;
  status: string;
  preSubmissionId?: string;
}

interface PreSubmissionResponse {
  id: string;
  status: string;
  message: string;
}

interface VerifyPurchaseResponse {
  success: boolean;
  status: string;
  message: string;
  signature?: string;
  preSubmissionId?: string;
}

/**
 * CRITICAL FIX: Enhanced function to load transactions from all localStorage sources
 * This ensures we capture transactions from all possible storage methods
 */
const loadTransactionsFromLocalStorage = (walletPublicKey?: any): PendingTransaction[] => {
  try {
    const pendingTxs: PendingTransaction[] = [];
    
    // Try different storage formats for maximum compatibility
    // Format 1: Direct array format
    try {
      const stored = localStorage.getItem('pendingTransactions');
      if (stored) {
        const parsed = JSON.parse(stored);
        // Handle both array format and versioned format
        if (Array.isArray(parsed)) {
          console.log("Found direct array format transactions:", parsed.length);
          parsed.forEach((tx: any) => {
            if (tx && tx.amount !== undefined) {
              pendingTxs.push({
                id: tx.id || `local-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
                signature: tx.signature,
                amount: tx.amount,
                credits: tx.pongCredits || tx.credits || 0,
                timestamp: tx.timestamp || Date.now(),
                status: tx.status || 'pending'
              });
            }
          });
        } else if (parsed.transactions && Array.isArray(parsed.transactions)) {
          console.log("Found versioned format transactions:", parsed.transactions.length);
          parsed.transactions.forEach((tx: any) => {
            if (tx && tx.amount !== undefined) {
              pendingTxs.push({
                id: tx.id || `local-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
                signature: tx.signature,
                amount: tx.amount,
                credits: tx.pongCredits || tx.credits || 0,
                timestamp: tx.timestamp || Date.now(),
                status: tx.status || 'pending'
              });
            }
          });
        }
      }
    } catch (e) {
      console.error("Error loading from pendingTransactions storage:", e);
    }
    
    // Format 2: Wallet-specific format
    try {
      if (walletPublicKey) {
        const txsKey = `transactions_${walletPublicKey.toString()}`;
        const stored = localStorage.getItem(txsKey);
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed)) {
            console.log("Found wallet-specific transactions:", parsed.length);
            
            // Add only those that aren't already in the list
            for (const tx of parsed) {
              if (tx && tx.amount !== undefined) {
                const exists = pendingTxs.some(existingTx => 
                  (tx.signature && existingTx.signature === tx.signature) || 
                  (tx.id && existingTx.id === tx.id)
                );
                
                if (!exists) {
                  pendingTxs.push({
                    id: tx.id || `wallet-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
                    signature: tx.signature,
                    amount: tx.amount || 0,
                    credits: tx.pongCredits || tx.credits || 0,
                    timestamp: tx.timestamp || Date.now(),
                    status: tx.status || 'pending'
                  });
                }
              }
            }
          }
        }
      }
    } catch (e) {
      console.error("Error loading from wallet-specific storage:", e);
    }
    
    // Format 3: Legacy format
    try {
      const legacyStored = localStorage.getItem('sol_arcade_pending_transactions');
      if (legacyStored) {
        const parsed = JSON.parse(legacyStored);
        if (Array.isArray(parsed)) {
          console.log("Found legacy format transactions:", parsed.length);
          
          // Add only those that aren't already in the list
          for (const tx of parsed) {
            if (tx && (tx.amount !== undefined || tx.solAmount !== undefined)) {
              const exists = pendingTxs.some(existingTx => 
                (tx.signature && existingTx.signature === tx.signature) || 
                (tx.id && existingTx.id === tx.id)
              );
              
              if (!exists) {
                pendingTxs.push({
                  id: tx.signature || tx.id || `legacy-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
                  signature: tx.signature,
                  amount: tx.amount || tx.solAmount || 0,
                  credits: tx.pongCredits || tx.credits || 0,
                  timestamp: tx.timestamp || Date.now(),
                  status: tx.status || 'pending'
                });
              }
            }
          }
        }
      }
    } catch (e) {
      console.error("Error loading from legacy storage:", e);
    }
    
    return pendingTxs;
  } catch (error) {
    console.error('Error loading transactions from localStorage:', error);
    return [];
  }
}

// Helper components and functions for transaction UI

/**
 * Status badge component for transaction status
 */
const StatusBadge = ({ status }: { status: string }) => {
  let bgColor = "";
  let textColor = "";
  let label = "";
  
  switch (status) {
    case 'pre_submission':
      bgColor = "bg-yellow-900";
      textColor = "text-yellow-300";
      label = "INITIALIZING";
      break;
    case 'pending':
      bgColor = "bg-blue-900";
      textColor = "text-blue-300";
      label = "PENDING";
      break;
    case 'submitted':
      bgColor = "bg-purple-900";
      textColor = "text-purple-300";
      label = "SUBMITTED";
      break;
    case 'confirmed':
      bgColor = "bg-green-900";
      textColor = "text-green-300";
      label = "CONFIRMED";
      break;
    case 'completed':
      bgColor = "bg-green-900";
      textColor = "text-green-300";
      label = "COMPLETED";
      break;
    case 'failed':
      bgColor = "bg-red-900";
      textColor = "text-red-300";
      label = "FAILED";
      break;
    default:
      bgColor = "bg-gray-900";
      textColor = "text-gray-300";
      label = status.toUpperCase();
  }
  
  return (
    <span className={`px-2 py-1 text-xs rounded ${bgColor} ${textColor} font-bold`}>
      {label}
    </span>
  );
};

/**
 * Get the progress bar color based on status
 */
const getProgressBarColor = (status: string): string => {
  switch (status) {
    case 'pre_submission':
      return 'bg-gradient-to-r from-yellow-600 to-yellow-400 animate-pulse';
    case 'pending':
      return 'bg-gradient-to-r from-blue-600 to-blue-400 animate-pulse';
    case 'submitted':
      return 'bg-gradient-to-r from-purple-600 to-purple-400 animate-pulse';
    case 'confirmed':
      return 'bg-gradient-to-r from-green-600 to-green-400';
    case 'completed':
      return 'bg-gradient-to-r from-green-700 to-green-500';
    case 'failed':
      return 'bg-gradient-to-r from-red-700 to-red-500';
    default:
      return 'bg-gray-600';
  }
};

/**
 * Get progress percentage based on status
 */
const getProgressPercentage = (status: string): string => {
  switch (status) {
    case 'pre_submission':
      return '15%';
    case 'pending':
      return '30%';
    case 'submitted':
      return '60%';
    case 'confirmed':
      return '85%';
    case 'completed':
      return '100%';
    case 'failed':
      return '100%';
    default:
      return '0%';
  }
};

/**
 * Format timestamp to relative time
 */
const formatTimestamp = (timestamp: number): string => {
  const now = Date.now();
  const diff = now - timestamp;
  
  if (diff < 60000) { // Less than 1 minute
    return 'Just now';
  } else if (diff < 3600000) { // Less than 1 hour
    const minutes = Math.floor(diff / 60000);
    return `${minutes} min${minutes > 1 ? 's' : ''} ago`;
  } else if (diff < 86400000) { // Less than 1 day
    const hours = Math.floor(diff / 3600000);
    return `${hours} hour${hours > 1 ? 's' : ''} ago`;
  } else {
    const days = Math.floor(diff / 86400000);
    return `${days} day${days > 1 ? 's' : ''} ago`;
  }
};

/**
 * Load transactions stored in localStorage
 */
interface StorageTransaction {
  signature: string;
  preSubmissionId: string;
  amount: number;
  timestamp: number;
  pongCredits?: number;
  status?: string;
  lastUpdate?: number;
}

const getLocalStorageTransactions = (): StorageTransaction[] => {
  try {
    const storedTx = localStorage.getItem('pendingPongTransactions');
    return storedTx ? JSON.parse(storedTx) : [];
  } catch (error) {
    console.error('Error loading transactions from localStorage:', error);
    return [];
  }
};

/**
 * Save a transaction to localStorage for persistence across page refreshes
 * Enhanced version with additional parameters and better error handling
 */
const saveTransactionToLocalStorage = (
  signature: string, 
  preSubmissionId: string, 
  amount: number, 
  expectedCredits?: number
) => {
  try {
    const storedTx = getLocalStorageTransactions();
    
    // Calculate credits if not provided
    if (expectedCredits === undefined) {
      expectedCredits = 0;
      if (amount === 0.01) expectedCredits = 1;
      else if (amount === 0.1) expectedCredits = 10;
      else if (amount === 1.0) expectedCredits = 100;
    }
    
    console.log(`Saving transaction to localStorage: ${signature || 'no-sig'}, preSubmissionId: ${preSubmissionId || 'no-id'}, amount: ${amount}, credits: ${expectedCredits}`);
    
    // Check if transaction already exists (by signature or preSubmissionId)
    const existingIndex = storedTx.findIndex(tx => 
      (signature && tx.signature === signature) || 
      (preSubmissionId && tx.preSubmissionId === preSubmissionId)
    );
    
    const transactionData = {
      signature: signature || '',
      preSubmissionId: preSubmissionId || '',
      amount,
      pongCredits: expectedCredits,
      status: 'pending',
      timestamp: Date.now(),
      lastUpdate: Date.now()
    };
    
    if (existingIndex >= 0) {
      // Update existing transaction
      storedTx[existingIndex] = {
        ...storedTx[existingIndex],
        ...transactionData,
        // Preserve original timestamp if it exists
        timestamp: storedTx[existingIndex].timestamp || Date.now()
      };
      console.log(`Updated existing transaction in localStorage: ${signature || preSubmissionId}`);
    } else {
      // Add new transaction
      storedTx.push(transactionData);
      console.log(`Added new transaction to localStorage: ${signature || preSubmissionId}`);
    }
    
    localStorage.setItem('pendingPongTransactions', JSON.stringify(storedTx));
    
    // Update UI immediately by calling showPendingTransaction
    if (window.showPendingTransaction) {
      window.showPendingTransaction(signature || preSubmissionId, amount, expectedCredits);
    }
    
    // Dispatch a custom event to notify other components
    try {
      const event = new CustomEvent('pendingTransactionUpdated', {
        detail: transactionData
      });
      window.dispatchEvent(event);
    } catch (eventError) {
      console.error('Error dispatching transaction event:', eventError);
    }
  } catch (error) {
    console.error('Error saving transaction to localStorage:', error);
  }
};

/**
 * Remove a transaction from localStorage once it's completed
 * Enhanced to handle signature or preSubmissionId
 */
const removeTransactionFromLocalStorage = (identifier: string, isPreSubmissionId: boolean = false) => {
  try {
    const storedTx = getLocalStorageTransactions();
    let filtered;
    
    if (isPreSubmissionId) {
      // Filter by preSubmissionId
      filtered = storedTx.filter(tx => tx.preSubmissionId !== identifier);
      console.log(`Removing transaction with preSubmissionId ${identifier} from localStorage`);
    } else {
      // Filter by signature (default behavior)
      filtered = storedTx.filter(tx => tx.signature !== identifier);
      console.log(`Removing transaction with signature ${identifier} from localStorage`);
    }
    
    localStorage.setItem('pendingPongTransactions', JSON.stringify(filtered));
  } catch (error) {
    console.error('Error removing transaction from localStorage:', error);
  }
};

export default function TransactionForm() {
  const { publicKey, sendTransaction: walletSendTransaction } = useWallet();
  const { connection } = useConnection();
  const [selectedAmount, setSelectedAmount] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [pendingTransactions, setPendingTransactions] = useState<PendingTransaction[]>([]);
  const [refreshInterval, setRefreshInterval] = useState<NodeJS.Timeout | null>(null);
  const { toast } = useToast();
  const { txPersistence, transactionManager, credits } = useTransactionPersistence();

  // Pre-defined SOL stake amount options with stake levels
  const amountOptions = [
    { value: "0.01", label: "0.01 SOL - Low Stake", stakeLevel: "low" },
    { value: "0.1", label: "0.1 SOL - Medium Stake", stakeLevel: "medium" },
    { value: "1.0", label: "1.0 SOL - High Stake", stakeLevel: "high" }
  ];

  // Initialize local transaction recovery
  const recoverStoredTransactions = async () => {
    if (!publicKey || !connection) return;
    
    try {
      // Get transactions from localStorage
      const storedTx = getLocalStorageTransactions();
      
      if (storedTx.length === 0) return;
      
      console.log(`Found ${storedTx.length} stored transactions to recover`);
      
      // Check each transaction to see if it needs to be processed
      for (const tx of storedTx) {
        try {
          // Skip if transaction is too old (more than 2 days)
          const twoMsDays = 2 * 24 * 60 * 60 * 1000;
          if (Date.now() - tx.timestamp > twoMsDays) {
            console.log(`Removing old transaction ${tx.signature}`);
            removeTransactionFromLocalStorage(tx.signature);
            continue;
          }
          
          // Check if this transaction is already in the pending list
          // If so, we don't need to recover it
          const pendingTx = await fetch(`/api/pending-transactions/${publicKey.toString()}`);
          const pendingData = await pendingTx.json();
          
          const isAlreadyPending = pendingData.some((p: PendingTransaction) => 
            p.id === tx.signature || p.id === tx.preSubmissionId
          );
          
          if (isAlreadyPending) {
            console.log(`Transaction ${tx.signature} is already being tracked`);
            continue;
          }
          
          // Check transaction status on the blockchain
          console.log(`Recovering transaction ${tx.signature}...`);
          
          let credits = 0;
          if (tx.amount === 0.01) credits = 1;
          else if (tx.amount === 0.1) credits = 10;
          else if (tx.amount === 1.0) credits = 100;
          
          // Verify transaction with backend
          const response = await fetch("/api/verify-purchase", {
            method: "POST",
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              signature: tx.signature,
              walletAddress: publicKey.toString(),
              amount: tx.amount,
              credits,
              preSubmissionId: tx.preSubmissionId
            })
          });
          
          const data = await response.json();
          
          if (data.success) {
            // Transaction processed successfully
            toast({
              title: "Recovered Transaction",
              description: `Successfully recovered ${tx.amount} SOL stake transaction.`
            });
            removeTransactionFromLocalStorage(tx.signature);
          }
        } catch (error) {
          console.error(`Error recovering transaction ${tx.signature}:`, error);
        }
      }
    } catch (error) {
      console.error('Error in transaction recovery:', error);
    }
  };

  // Load pending transactions on mount and when wallet changes
  useEffect(() => {
    if (publicKey) {
      // First fetch pending transactions
      fetchPendingTransactions();
      
      // Then check for any transactions in localStorage to recover
      recoverStoredTransactions();
      
      // Set up polling for pending transactions
      const interval = setInterval(() => {
        fetchPendingTransactions();
      }, 5000); // Check every 5 seconds
      
      setRefreshInterval(interval);
      
      return () => {
        if (refreshInterval) {
          clearInterval(refreshInterval);
        }
      };
    }
  }, [publicKey, connection]);

  // CRITICAL FIX: Enhanced pending transaction fetching with local caching
  const fetchPendingTransactions = async () => {
    if (!publicKey) return;
    
    try {
      // CRITICAL: First load from localStorage for immediate display
      const localTxs = getLocalStorageTransactions();
      if (localTxs && localTxs.length > 0) {
        console.log("Loaded transactions from localStorage:", localTxs.length);
        // Map to proper format
        const mappedLocalTxs = localTxs.map(tx => ({
          id: tx.signature || tx.preSubmissionId || `local-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
          signature: tx.signature,
          amount: tx.amount,
          credits: tx.pongCredits || 0,
          timestamp: tx.timestamp,
          status: tx.status || 'pending'
        } as PendingTransaction));
        
        setPendingTransactions(prev => {
          // Merge with existing transactions, avoiding duplicates
          const merged = [...prev];
          for (const tx of mappedLocalTxs) {
            if (!merged.some(existing => 
              (tx.signature && existing.signature === tx.signature) || 
              (tx.id === existing.id)
            )) {
              merged.push(tx);
            }
          }
          return merged;
        });
      }
      
      // Also try the comprehensive storage method
      try {
        const extendedLocalTxs = loadTransactionsFromLocalStorage(publicKey);
        if (extendedLocalTxs && extendedLocalTxs.length > 0) {
          console.log("Found additional transactions from comprehensive storage:", extendedLocalTxs.length);
          
          setPendingTransactions(prev => {
            // Merge with existing transactions, avoiding duplicates
            const merged = [...prev];
            for (const tx of extendedLocalTxs) {
              if (!merged.some(existing => 
                (tx.signature && existing.signature === tx.signature) || 
                (tx.id === existing.id)
              )) {
                merged.push(tx);
              }
            }
            return merged;
          });
        }
      } catch (storageError) {
        console.error("Error loading from comprehensive storage:", storageError);
      }
      
      // Then fetch from server API for latest data
      const response = await fetch(`/api/pending-transactions/${publicKey.toString()}`);
      if (response.ok) {
        const data = await response.json();
        
        // Merge server data with local data, prioritizing server data
        setPendingTransactions(prev => {
          // Get existing local transactions that aren't in the server response
          const localOnly = prev.filter(localTx => 
            !data.some((serverTx: any) => 
              (localTx.signature && serverTx.signature === localTx.signature) || 
              (serverTx.id === localTx.id)
            )
          );
          
          // Map server data to ensure it has all required properties
          const mappedServerData = data.map((tx: any) => ({
            id: tx.id || tx.signature || tx.preSubmissionId,
            signature: tx.signature || tx.transactionSignature,
            amount: parseFloat(tx.amount) || 0,
            credits: tx.pongCredits || tx.credits || 0,
            timestamp: tx.timestamp ? new Date(tx.timestamp).getTime() : Date.now(),
            status: tx.status || 'pending'
          } as PendingTransaction));
          
          // Add local-only transactions to server data
          return [...mappedServerData, ...localOnly];
        });
      }
    } catch (error) {
      console.error("Error fetching pending transactions:", error);
    }
  };

  const createPreSubmissionRecord = async () => {
    if (!publicKey || !selectedAmount) return null;
    
    try {
      const response = await fetch("/api/pre-submit-transaction", {
        method: "POST",
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          walletAddress: publicKey.toString(),
          amount: parseFloat(selectedAmount)
        })
      });
      
      if (response.ok) {
        const data = await response.json() as PreSubmissionResponse;
        return data.id;
      }
      return null;
    } catch (error) {
      console.error("Error creating pre-submission record:", error);
      return null;
    }
  };

  // CRITICAL FIX: Enhanced transaction verification with better error handling
  const verifyTransaction = async (signature: string, preSubmissionId: string | null = null) => {
    if (!publicKey) return null;
    
    try {
      const amount = parseFloat(selectedAmount);
      let credits = 0;
      
      if (amount === 0.01) credits = 1;
      else if (amount === 0.1) credits = 10;
      else if (amount === 1.0) credits = 100;
      
      console.log(`Verifying transaction ${signature} for ${credits} credits (amount: ${amount})...`);
      
      const response = await fetch("/api/verify-purchase", {
        method: "POST",
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          signature,
          walletAddress: publicKey.toString(),
          preSubmissionId: preSubmissionId || undefined,
          amount,
          credits
        })
      });
      
      const data = await response.json() as VerifyPurchaseResponse;
      console.log("Transaction verification response:", data);
      
      // If transaction was marked as completed, dispatch the credits updated event
      if (data.success && data.status === "completed") {
        try {
          // Fetch the current user to get updated credit balance
          const userResponse = await fetch(`/api/user/${publicKey.toString()}`);
          if (userResponse.ok) {
            const userData = await userResponse.json();
            if (userData && typeof userData.pongCredits === 'number') {
              console.log("Dispatching credits updated event with new balance:", userData.pongCredits);
              
              // Dispatch custom event for credit update
              const event = new CustomEvent('pongCreditsUpdated', {
                detail: { 
                  credits: userData.pongCredits,
                  added: credits,
                  signature
                }
              });
              window.dispatchEvent(event);
            }
          }
        } catch (userError) {
          console.error("Error fetching updated user credits:", userError);
          // Still return the verification data
        }
      }
      
      return data;
    } catch (error) {
      console.error("Error verifying transaction:", error);
      throw error;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!publicKey || !selectedAmount) return;

    setLoading(true);
    let preSubmissionId: string | null = null;
    
    try {
      // Get stake level based on selected amount
      let stakeLevel = "low";
      const amount = parseFloat(selectedAmount);
      if (amount === 0.01) stakeLevel = "low";
      else if (amount === 0.1) stakeLevel = "medium";
      else if (amount === 1.0) stakeLevel = "high";
      
      // CRITICAL FIX: Generate a unique ID for this transaction for tracking before we have a signature
      // This allows for tracking throughout the entire process
      const tempId = `pending-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
      
      // CRITICAL FIX: Show in UI IMMEDIATELY before any server calls
      console.log("CRITICAL: Adding transaction to UI immediately with temp ID:", tempId);
      if (window.showPendingTransaction) {
        // First call with tempId for maximum immediacy
        window.showPendingTransaction(tempId, amount, expectedCredits);
        
        // Also create records in both local storage formats for maximum robustness
        try {
          // Version 1: Direct array format
          const oldFormat = JSON.parse(localStorage.getItem('pendingTransactions') || '[]');
          if (Array.isArray(oldFormat)) {
            oldFormat.push({
              id: tempId,
              signature: undefined,
              type: 'pongCredit',
              amount: amount,
              pongCredits: expectedCredits,
              status: 'pending',
              timestamp: Date.now(),
              lastUpdated: Date.now(),
              confirmations: 0
            });
            localStorage.setItem('pendingTransactions', JSON.stringify(oldFormat));
          }
          
          // Version 2: Versioned format with wallet address
          const txsKey = `transactions_${publicKey.toString()}`;
          const userTxs = JSON.parse(localStorage.getItem(txsKey) || '[]');
          if (Array.isArray(userTxs)) {
            userTxs.push({
              id: tempId,
              signature: undefined,
              type: 'pongCredit',
              amount: amount,
              pongCredits: expectedCredits,
              status: 'pending',
              timestamp: Date.now(),
              lastUpdated: Date.now()
            });
            localStorage.setItem(txsKey, JSON.stringify(userTxs));
          }
        } catch (storageError) {
          console.error("Error adding to localStorage:", storageError);
        }
      }
      
      // Force UI to update
      try {
        const event = new CustomEvent('pendingTransactionAdded', {
          detail: {
            transaction: {
              id: tempId,
              amount,
              pongCredits: expectedCredits,
              status: 'pending',
              timestamp: Date.now()
            }
          }
        });
        window.dispatchEvent(event);
      } catch (eventError) {
        console.error("Error dispatching event:", eventError);
      }
      
      // Force refresh pending transactions list
      fetchPendingTransactions().catch(e => console.error("Error fetching pending transactions:", e));
      
      // Notify user that transaction is being initialized
      toast({
        title: "Initializing Transaction",
        description: `Preparing your ${selectedAmount} SOL stake for game play...`,
      });
      
      // Step 1: Create pre-submission record for server tracking
      console.log("Creating pre-submission record on server...");
      try {
        preSubmissionId = await createPreSubmissionRecord();
        console.log(`Pre-submission record created with ID: ${preSubmissionId}`);
      } catch (preSubmissionError) {
        console.error("Error creating pre-submission record:", preSubmissionError);
        // Continue with tempId instead
        preSubmissionId = tempId;
      }
      
      // Update UI with the preSubmissionId if available
      if (window.showPendingTransaction && preSubmissionId) {
        console.log("Updating pending transaction with preSubmissionId");
        window.showPendingTransaction(preSubmissionId, amount, expectedCredits);
      }
      
      // Create a server record to ensure transactions are tracked even during disconnections
      try {
        console.log("Creating server-side transaction record for persistence...");
        const pendingResponse = await fetch(`/api/transactions/create`, {
          method: "POST",
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            walletAddress: publicKey.toString(),
            solAmount: parseFloat(selectedAmount),
            credits: expectedCredits,
            preSubmissionId: preSubmissionId || tempId,
            status: 'pre_submission'
          })
        });
        
        if (pendingResponse.ok) {
          console.log("Successfully created persistent transaction record on server");
          const data = await pendingResponse.json();
          
          // Show in UI with server-generated ID
          if (data.id && window.showPendingTransaction) {
            console.log("Updating UI with server record ID:", data.id);
            window.showPendingTransaction(data.id.toString(), amount, expectedCredits);
          }
        }
      } catch (serverError) {
        console.error("Error creating server transaction record:", serverError);
        // Continue with the transaction anyway - we have local persistence
      }
      
      // Step 2: Send the actual Solana transaction
      console.log("Sending Solana transaction...");
      const signature = await sendTransaction(
        connection,
        walletSendTransaction as any, // Type casting to avoid TypeScript errors
        publicKey,
        parseFloat(selectedAmount)
      );
      
      console.log(`Transaction sent with signature: ${signature}`);
      
      // Update the pending transaction record with the signature
      try {
        console.log("Updating pending transaction with signature");
        
        // IMPORTANT - Use the new Transaction Manager system for tracking
        if (transactionManager) {
          console.log("Using new TransactionManager to track transaction");
          const expectedCredits = await transactionManager.trackTransaction(signature, amount);
          console.log(`Transaction ${signature} is being tracked for ${expectedCredits} credits`);
        } 
        // Use legacy system as fallback
        else if (txPersistence) {
          console.log("Falling back to legacy TransactionPersistence system");
          await txPersistence.trackTransaction(signature, amount);
        }
        
        // Save to localStorage with expected credits for maximum persistence
        saveTransactionToLocalStorage(signature, preSubmissionId || "", parseFloat(selectedAmount), expectedCredits);
        
        // Force refresh the UI to show the updated pending transactions
        await fetchPendingTransactions();
      } catch (updateError) {
        console.error("Error updating pending transaction:", updateError);
      }
      
      // Notify user that transaction has been submitted
      toast({
        title: "Transaction Submitted",
        description: `Your transaction has been submitted to the Solana network. Processing your ${selectedAmount} SOL stake...`,
      });
      
      // Still verify with API for backward compatibility
      console.log("Also verifying with API for backward compatibility...");
      try {
        const verificationResult = await verifyTransaction(signature, preSubmissionId);
        
        // CRITICAL FIX: Update window display after verification
        // This ensures transactions stay visible even if the user refreshes during verification
        if (window.showPendingTransaction) {
          const status = verificationResult?.success ? 'confirming' : 'pending';
          console.log(`Updating transaction display after verification with status: ${status}`);
          window.showPendingTransaction(signature, parseFloat(selectedAmount), expectedCredits);
        }
        
        // If verification was successful, remove from localStorage
        if (verificationResult && verificationResult.success) {
          removeTransactionFromLocalStorage(signature);
        }
      } catch (verifyError) {
        console.error("Error in API verification, but transaction is still being processed via Transaction Manager:", verifyError);
        // Transaction Manager system will handle it
        
        // Still update UI display even if verification failed
        if (window.showPendingTransaction) {
          console.log("Ensuring transaction remains in display despite verification error");
          window.showPendingTransaction(signature, parseFloat(selectedAmount), expectedCredits);
        }
      }
      
      // Display success toast
      toast({
        title: "Stake Confirmed",
        description: `Your ${selectedAmount} SOL stake is being processed. You'll be able to play once confirmed.`,
      });
      
      // Update pending transactions immediately
      await fetchPendingTransactions();
      
    } catch (error) {
      console.error("Transaction error:", error);
      toast({
        title: "Transaction Failed",
        description: error instanceof Error ? error.message : "Unknown error occurred during transaction",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Transaction form */}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="amount" className="text-[#00ffff]">SELECT AMOUNT</Label>
          <Select
            value={selectedAmount}
            onValueChange={(value) => setSelectedAmount(value)}
          >
            <SelectTrigger className="bg-[#000033] border-[#ff00ff] text-[#ffffff] focus:border-[#00ffff] focus:ring-[#00ffff]"
                           style={{boxShadow: '0 0 5px #ff00ff'}}>
              <SelectValue placeholder="Select SOL amount" />
            </SelectTrigger>
            <SelectContent className="bg-[#000033] border-[#ff00ff] text-[#ffffff]">
              {amountOptions.map(option => (
                <SelectItem key={option.value} value={option.value} className="hover:bg-[#2a0066]">
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <Button 
          type="submit" 
          disabled={loading || !selectedAmount || !publicKey} 
          className="w-full pong-button py-2"
        >
          {loading ? "PROCESSING..." : "CONFIRM STAKE AMOUNT"}
        </Button>
      </form>
      
      {/* Pending transactions display */}
      {pendingTransactions.length > 0 && (
        <div className="mt-6 border border-[#ff00ff] p-4 rounded-lg bg-black/30">
          <h3 className="text-[#00ffff] text-lg mb-2 flex items-center">
            <span className="mr-2">Pending Transactions</span>
            <span className="animate-pulse inline-block w-2 h-2 bg-[#ff00ff] rounded-full"></span>
          </h3>
          <div className="space-y-3">
            {pendingTransactions.map((tx) => (
              <div key={tx.id} className="flex flex-col text-white p-3 border border-[#ff00ff]/30 rounded-md bg-black/50">
                <div className="flex justify-between items-center mb-2">
                  <div>
                    <span className="text-[#ff00ff] font-bold">{tx.amount} SOL</span> 
                    <span className="text-sm text-gray-400 ml-2">(Game Stake)</span>
                  </div>
                  <StatusBadge status={tx.status} />
                </div>
                <div className="w-full h-2 bg-[#2a0066]/30 rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${getProgressBarColor(tx.status)}`}
                    style={{ width: getProgressPercentage(tx.status) }}
                  ></div>
                </div>
                <div className="mt-1 text-xs text-gray-400 flex justify-between">
                  <span>ID: {tx.id.substring(0, 8)}...</span>
                  <span>{formatTimestamp(tx.timestamp)}</span>
                </div>
              </div>
            ))}
          </div>
          <p className="text-xs text-gray-400 mt-3 italic">
            Transactions are processed automatically. Game stakes are confirmed after blockchain verification.
          </p>
        </div>
      )}
    </div>
  );
}
