import { useWallet } from "@solana/wallet-adapter-react";
import { useConnection } from "@solana/wallet-adapter-react";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { sendTransaction } from "@/lib/wallet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";
import { useTransactionPersistence } from "../App";

interface PendingTransaction {
  id: string;
  amount: number;
  credits: number;
  timestamp: number;
  status: string;
}

interface PreSubmissionResponse {
  id: string;
  status: string;
  credits: number;
  message: string;
}

interface VerifyPurchaseResponse {
  success: boolean;
  status: string;
  message: string;
  signature?: string;
  preSubmissionId?: string;
}

// Helper components and functions for transaction UI

/**
 * Status badge component for transaction status
 */
const StatusBadge = ({ status }: { status: string }) => {
  let bgColor = "";
  let textColor = "";
  let label = "";
  
  switch (status) {
    case 'pre_submission':
      bgColor = "bg-yellow-900";
      textColor = "text-yellow-300";
      label = "INITIALIZING";
      break;
    case 'pending':
      bgColor = "bg-blue-900";
      textColor = "text-blue-300";
      label = "PENDING";
      break;
    case 'submitted':
      bgColor = "bg-purple-900";
      textColor = "text-purple-300";
      label = "SUBMITTED";
      break;
    case 'confirmed':
      bgColor = "bg-green-900";
      textColor = "text-green-300";
      label = "CONFIRMED";
      break;
    case 'completed':
      bgColor = "bg-green-900";
      textColor = "text-green-300";
      label = "COMPLETED";
      break;
    case 'failed':
      bgColor = "bg-red-900";
      textColor = "text-red-300";
      label = "FAILED";
      break;
    default:
      bgColor = "bg-gray-900";
      textColor = "text-gray-300";
      label = status.toUpperCase();
  }
  
  return (
    <span className={`px-2 py-1 text-xs rounded ${bgColor} ${textColor} font-bold`}>
      {label}
    </span>
  );
};

/**
 * Get the progress bar color based on status
 */
const getProgressBarColor = (status: string): string => {
  switch (status) {
    case 'pre_submission':
      return 'bg-gradient-to-r from-yellow-600 to-yellow-400 animate-pulse';
    case 'pending':
      return 'bg-gradient-to-r from-blue-600 to-blue-400 animate-pulse';
    case 'submitted':
      return 'bg-gradient-to-r from-purple-600 to-purple-400 animate-pulse';
    case 'confirmed':
      return 'bg-gradient-to-r from-green-600 to-green-400';
    case 'completed':
      return 'bg-gradient-to-r from-green-700 to-green-500';
    case 'failed':
      return 'bg-gradient-to-r from-red-700 to-red-500';
    default:
      return 'bg-gray-600';
  }
};

/**
 * Get progress percentage based on status
 */
const getProgressPercentage = (status: string): string => {
  switch (status) {
    case 'pre_submission':
      return '15%';
    case 'pending':
      return '30%';
    case 'submitted':
      return '60%';
    case 'confirmed':
      return '85%';
    case 'completed':
      return '100%';
    case 'failed':
      return '100%';
    default:
      return '0%';
  }
};

/**
 * Format timestamp to relative time
 */
const formatTimestamp = (timestamp: number): string => {
  const now = Date.now();
  const diff = now - timestamp;
  
  if (diff < 60000) { // Less than 1 minute
    return 'Just now';
  } else if (diff < 3600000) { // Less than 1 hour
    const minutes = Math.floor(diff / 60000);
    return `${minutes} min${minutes > 1 ? 's' : ''} ago`;
  } else if (diff < 86400000) { // Less than 1 day
    const hours = Math.floor(diff / 3600000);
    return `${hours} hour${hours > 1 ? 's' : ''} ago`;
  } else {
    const days = Math.floor(diff / 86400000);
    return `${days} day${days > 1 ? 's' : ''} ago`;
  }
};

/**
 * Load transactions stored in localStorage
 */
const getLocalStorageTransactions = (): {signature: string, preSubmissionId: string, amount: number, timestamp: number}[] => {
  try {
    const storedTx = localStorage.getItem('pendingPongTransactions');
    return storedTx ? JSON.parse(storedTx) : [];
  } catch (error) {
    console.error('Error loading transactions from localStorage:', error);
    return [];
  }
};

/**
 * Save a transaction to localStorage for persistence across page refreshes
 */
const saveTransactionToLocalStorage = (signature: string, preSubmissionId: string, amount: number) => {
  try {
    const storedTx = getLocalStorageTransactions();
    storedTx.push({
      signature,
      preSubmissionId,
      amount,
      timestamp: Date.now()
    });
    localStorage.setItem('pendingPongTransactions', JSON.stringify(storedTx));
  } catch (error) {
    console.error('Error saving transaction to localStorage:', error);
  }
};

/**
 * Remove a transaction from localStorage once it's completed
 */
const removeTransactionFromLocalStorage = (signature: string) => {
  try {
    const storedTx = getLocalStorageTransactions();
    const filtered = storedTx.filter(tx => tx.signature !== signature);
    localStorage.setItem('pendingPongTransactions', JSON.stringify(filtered));
  } catch (error) {
    console.error('Error removing transaction from localStorage:', error);
  }
};

export default function TransactionForm() {
  const { publicKey, sendTransaction: walletSendTransaction } = useWallet();
  const { connection } = useConnection();
  const [selectedAmount, setSelectedAmount] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [pendingTransactions, setPendingTransactions] = useState<PendingTransaction[]>([]);
  const [refreshInterval, setRefreshInterval] = useState<NodeJS.Timeout | null>(null);
  const { toast } = useToast();
  const { txPersistence, credits } = useTransactionPersistence();

  // Pre-defined SOL amount options and their corresponding credit values
  const amountOptions = [
    { value: "0.01", label: "0.01 SOL (1 Credit)" },
    { value: "0.1", label: "0.1 SOL (10 Credits)" },
    { value: "1.0", label: "1.0 SOL (100 Credits)" }
  ];

  // Initialize local transaction recovery
  const recoverStoredTransactions = async () => {
    if (!publicKey || !connection) return;
    
    try {
      // Get transactions from localStorage
      const storedTx = getLocalStorageTransactions();
      
      if (storedTx.length === 0) return;
      
      console.log(`Found ${storedTx.length} stored transactions to recover`);
      
      // Check each transaction to see if it needs to be processed
      for (const tx of storedTx) {
        try {
          // Skip if transaction is too old (more than 2 days)
          const twoMsDays = 2 * 24 * 60 * 60 * 1000;
          if (Date.now() - tx.timestamp > twoMsDays) {
            console.log(`Removing old transaction ${tx.signature}`);
            removeTransactionFromLocalStorage(tx.signature);
            continue;
          }
          
          // Check if this transaction is already in the pending list
          // If so, we don't need to recover it
          const pendingTx = await fetch(`/api/pending-transactions/${publicKey.toString()}`);
          const pendingData = await pendingTx.json();
          
          const isAlreadyPending = pendingData.some((p: PendingTransaction) => 
            p.id === tx.signature || p.id === tx.preSubmissionId
          );
          
          if (isAlreadyPending) {
            console.log(`Transaction ${tx.signature} is already being tracked`);
            continue;
          }
          
          // Check transaction status on the blockchain
          console.log(`Recovering transaction ${tx.signature}...`);
          
          let credits = 0;
          if (tx.amount === 0.01) credits = 1;
          else if (tx.amount === 0.1) credits = 10;
          else if (tx.amount === 1.0) credits = 100;
          
          // Verify transaction with backend
          const response = await fetch("/api/verify-purchase", {
            method: "POST",
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              signature: tx.signature,
              walletAddress: publicKey.toString(),
              amount: tx.amount,
              credits,
              preSubmissionId: tx.preSubmissionId
            })
          });
          
          const data = await response.json();
          
          if (data.success) {
            // Transaction processed successfully
            toast({
              title: "Recovered Transaction",
              description: `Successfully recovered transaction for ${credits} credits.`
            });
            removeTransactionFromLocalStorage(tx.signature);
          }
        } catch (error) {
          console.error(`Error recovering transaction ${tx.signature}:`, error);
        }
      }
    } catch (error) {
      console.error('Error in transaction recovery:', error);
    }
  };

  // Load pending transactions on mount and when wallet changes
  useEffect(() => {
    if (publicKey) {
      // First fetch pending transactions
      fetchPendingTransactions();
      
      // Then check for any transactions in localStorage to recover
      recoverStoredTransactions();
      
      // Set up polling for pending transactions
      const interval = setInterval(() => {
        fetchPendingTransactions();
      }, 5000); // Check every 5 seconds
      
      setRefreshInterval(interval);
      
      return () => {
        if (refreshInterval) {
          clearInterval(refreshInterval);
        }
      };
    }
  }, [publicKey, connection]);

  const fetchPendingTransactions = async () => {
    if (!publicKey) return;
    
    try {
      const response = await fetch(`/api/pending-transactions/${publicKey.toString()}`);
      if (response.ok) {
        const data = await response.json();
        setPendingTransactions(data);
      }
    } catch (error) {
      console.error("Error fetching pending transactions:", error);
    }
  };

  const createPreSubmissionRecord = async () => {
    if (!publicKey || !selectedAmount) return null;
    
    try {
      const response = await fetch("/api/pre-submit-transaction", {
        method: "POST",
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          walletAddress: publicKey.toString(),
          amount: parseFloat(selectedAmount)
        })
      });
      
      if (response.ok) {
        const data = await response.json() as PreSubmissionResponse;
        return data.id;
      }
      return null;
    } catch (error) {
      console.error("Error creating pre-submission record:", error);
      return null;
    }
  };

  const verifyTransaction = async (signature: string, preSubmissionId: string) => {
    if (!publicKey) return;
    
    try {
      const amount = parseFloat(selectedAmount);
      let credits = 0;
      
      if (amount === 0.01) credits = 1;
      else if (amount === 0.1) credits = 10;
      else if (amount === 1.0) credits = 100;
      
      const response = await fetch("/api/verify-purchase", {
        method: "POST",
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          signature,
          walletAddress: publicKey.toString(),
          amount,
          credits,
          preSubmissionId
        })
      });
      
      const data = await response.json() as VerifyPurchaseResponse;
      console.log("Transaction verification response:", data);
      return data;
    } catch (error) {
      console.error("Error verifying transaction:", error);
      throw error;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!publicKey || !selectedAmount || !txPersistence) return;

    setLoading(true);
    let preSubmissionId: string | null = null;
    
    try {
      // Calculate credits based on selected amount
      let expectedCredits = 0;
      const amount = parseFloat(selectedAmount);
      if (amount === 0.01) expectedCredits = 1;
      else if (amount === 0.1) expectedCredits = 10;
      else if (amount === 1.0) expectedCredits = 100;
      
      // Step 1: Create pre-submission record (still use API to maintain backward compatibility)
      console.log("Creating pre-submission record...");
      preSubmissionId = await createPreSubmissionRecord();
      
      if (!preSubmissionId) {
        throw new Error("Failed to create pre-submission record");
      }
      
      // Notify user that transaction is being initialized
      toast({
        title: "Initializing Transaction",
        description: `Preparing to purchase ${expectedCredits} credits with ${selectedAmount} SOL...`,
      });
      
      console.log(`Pre-submission record created with ID: ${preSubmissionId}`);
      
      // Update pending transactions to show the pre-submission state
      await fetchPendingTransactions();
      
      // Step 2: Send the Solana transaction
      console.log("Sending Solana transaction...");
      const signature = await sendTransaction(
        connection,
        walletSendTransaction as any, // Type casting to avoid TypeScript errors
        publicKey,
        parseFloat(selectedAmount)
      );
      
      console.log(`Transaction sent with signature: ${signature}`);
      
      // Use the new TransactionPersistence system to track the transaction
      console.log("Using TransactionPersistence system to track transaction");
      const pongCredits = await txPersistence.trackTransaction(signature, amount);
      
      // Still save to localStorage as a backup
      saveTransactionToLocalStorage(signature, preSubmissionId, parseFloat(selectedAmount));
      
      // Notify user that transaction has been submitted
      toast({
        title: "Transaction Submitted",
        description: `Your transaction has been submitted to the Solana network. Processing your ${expectedCredits} credits purchase...`,
      });
      
      // Still verify with API for backward compatibility
      console.log("Also verifying with API for backward compatibility...");
      try {
        const verificationResult = await verifyTransaction(signature, preSubmissionId);
        
        // If verification was successful, remove from localStorage
        if (verificationResult && verificationResult.success) {
          removeTransactionFromLocalStorage(signature);
        }
      } catch (verifyError) {
        console.error("Error in API verification, but transaction is still being processed via TransactionPersistence:", verifyError);
        // TransactionPersistence system will handle it
      }
      
      // Display success toast
      toast({
        title: "Purchase Confirmed",
        description: `Your purchase of ${expectedCredits} credits is being processed. Credits will be added to your account shortly.`,
      });
      
      // Update pending transactions immediately
      await fetchPendingTransactions();
      
    } catch (error) {
      console.error("Transaction error:", error);
      toast({
        title: "Transaction Failed",
        description: error instanceof Error ? error.message : "Unknown error occurred during transaction",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Transaction form */}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="amount" className="text-[#00ffff]">SELECT AMOUNT</Label>
          <Select
            value={selectedAmount}
            onValueChange={(value) => setSelectedAmount(value)}
          >
            <SelectTrigger className="bg-[#000033] border-[#ff00ff] text-[#ffffff] focus:border-[#00ffff] focus:ring-[#00ffff]"
                           style={{boxShadow: '0 0 5px #ff00ff'}}>
              <SelectValue placeholder="Select SOL amount" />
            </SelectTrigger>
            <SelectContent className="bg-[#000033] border-[#ff00ff] text-[#ffffff]">
              {amountOptions.map(option => (
                <SelectItem key={option.value} value={option.value} className="hover:bg-[#2a0066]">
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <Button 
          type="submit" 
          disabled={loading || !selectedAmount || !publicKey} 
          className="w-full pong-button py-2"
        >
          {loading ? "PROCESSING..." : "PURCHASE CREDITS"}
        </Button>
      </form>
      
      {/* Pending transactions display */}
      {pendingTransactions.length > 0 && (
        <div className="mt-6 border border-[#ff00ff] p-4 rounded-lg bg-black/30">
          <h3 className="text-[#00ffff] text-lg mb-2 flex items-center">
            <span className="mr-2">Pending Transactions</span>
            <span className="animate-pulse inline-block w-2 h-2 bg-[#ff00ff] rounded-full"></span>
          </h3>
          <div className="space-y-3">
            {pendingTransactions.map((tx) => (
              <div key={tx.id} className="flex flex-col text-white p-3 border border-[#ff00ff]/30 rounded-md bg-black/50">
                <div className="flex justify-between items-center mb-2">
                  <div>
                    <span className="text-[#ff00ff] font-bold">{tx.credits} Credits</span> 
                    <span className="text-sm text-gray-400 ml-2">({tx.amount} SOL)</span>
                  </div>
                  <StatusBadge status={tx.status} />
                </div>
                <div className="w-full h-2 bg-[#2a0066]/30 rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${getProgressBarColor(tx.status)}`}
                    style={{ width: getProgressPercentage(tx.status) }}
                  ></div>
                </div>
                <div className="mt-1 text-xs text-gray-400 flex justify-between">
                  <span>ID: {tx.id.substring(0, 8)}...</span>
                  <span>{formatTimestamp(tx.timestamp)}</span>
                </div>
              </div>
            ))}
          </div>
          <p className="text-xs text-gray-400 mt-3 italic">
            Transactions are processed automatically. Credits will appear in your balance after blockchain confirmation.
          </p>
        </div>
      )}
    </div>
  );
}
