import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronUp, Loader2, Clock, CheckCircle } from "lucide-react";
import { useWallet } from "@solana/wallet-adapter-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { Transaction } from "@shared/schema";
import PendingTransactions from "./PendingTransactions";

interface PendingTransaction {
  id: string;
  amount: number;
  credits: number;
  timestamp: number;
  status: string;
}

export default function TransactionHistory() {
  const { publicKey } = useWallet();
  const [showAllTransactions, setShowAllTransactions] = useState(false);
  const [pendingTransactions, setPendingTransactions] = useState<PendingTransaction[]>([]);
  const [refreshInterval, setRefreshInterval] = useState<NodeJS.Timeout | null>(null);
  const [activeTab, setActiveTab] = useState("completed");

  // Query for completed transactions
  const { data: transactions, isLoading, error } = useQuery<Transaction[]>({
    queryKey: ['/api/transactions', publicKey?.toString()],
    queryFn: async () => {
      if (!publicKey) return [];
      const res = await fetch(`/api/transactions/${publicKey.toString()}`);
      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(`Failed to fetch transactions: ${errorText}`);
      }
      return res.json();
    },
    enabled: !!publicKey,
    // Refresh every 10 seconds
    refetchInterval: 10000
  });

  // Fetch pending transactions
  useEffect(() => {
    if (publicKey) {
      fetchPendingTransactions();
      
      // Set up polling for pending transactions
      const interval = setInterval(() => {
        fetchPendingTransactions();
      }, 5000); // Check every 5 seconds
      
      setRefreshInterval(interval);
      
      return () => {
        if (refreshInterval) {
          clearInterval(refreshInterval);
        }
      };
    }
  }, [publicKey]);

  const fetchPendingTransactions = async () => {
    if (!publicKey) return;
    
    try {
      const response = await fetch(`/api/pending-transactions/${publicKey.toString()}`);
      if (response.ok) {
        const data = await response.json();
        setPendingTransactions(data);
        
        // If there are pending transactions, automatically switch to the pending tab
        if (data.length > 0 && activeTab === "completed") {
          setActiveTab("pending");
        }
      }
    } catch (error) {
      console.error("Error fetching pending transactions:", error);
    }
  };

  if (!publicKey) return null;

  // Sort transactions by timestamp (newest first) and determine which to display
  const sortedTransactions = transactions 
    ? [...transactions].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    : [];
    
  // Show only 3 transactions initially, or all transactions in a scrollable view if expanded
  const displayedTransactions = showAllTransactions 
    ? sortedTransactions 
    : sortedTransactions?.slice(0, 3);

  const hasMoreTransactions = sortedTransactions ? sortedTransactions.length > 3 : false;

  // Render a completed transaction row
  const renderTransaction = (tx: Transaction) => (
    <div key={tx.id} className="flex justify-between items-center py-2 border-b border-[#ff00ff33] last:border-0">
      <div className="flex flex-col">
        <span className="text-sm text-[#bbbbff]">
          {new Date(tx.timestamp).toLocaleString()}
        </span>
        {tx.pongCredits !== 0 && (
          <span className={`text-xs ${tx.pongCredits > 0 ? 'text-[#00ffaa]' : 'text-[#ff5577]'}`}>
            {tx.pongCredits > 0 ? '+' : ''}{tx.pongCredits} Pong Credit{tx.pongCredits !== 1 ? 's' : ''}
          </span>
        )}
      </div>
      <span className={`font-medium ${Number(tx.amount) < 0 ? 'text-[#ff5577]' : 'text-[#00ffaa]'}`} 
        style={{textShadow: '0 0 5px currentColor'}}>
        {Number(tx.amount).toFixed(4)} SOL
      </span>
    </div>
  );

  // Render a pending transaction row
  const renderPendingTransaction = (tx: PendingTransaction) => (
    <div key={tx.id} className="flex justify-between items-center py-2 border-b border-[#ff00ff33] last:border-0">
      <div className="flex flex-col">
        <div className="flex items-center gap-1">
          {tx.status === 'pending' || tx.status === 'pre_submission' ? (
            <Clock className="h-3 w-3 text-yellow-500" />
          ) : tx.status === 'submitted' ? (
            <Clock className="h-3 w-3 text-blue-500" />
          ) : tx.status === 'confirmed' ? (
            <CheckCircle className="h-3 w-3 text-green-500" />
          ) : null}
          <span className="text-sm text-[#bbbbff]">
            {new Date(tx.timestamp).toLocaleString()}
          </span>
        </div>
        <span className="text-xs text-[#00ffaa]">
          +{tx.credits} Pong Credit{tx.credits !== 1 ? 's' : ''} ({tx.status})
        </span>
      </div>
      <span className="font-medium text-[#00ffaa]" style={{textShadow: '0 0 5px currentColor'}}>
        {tx.amount.toFixed(4)} SOL
      </span>
    </div>
  );

  const tabTriggerClass = "data-[state=active]:bg-[#2a0066] data-[state=active]:text-[#00ffff] data-[state=active]:shadow-[0_0_5px_#ff00ff]";

  return (
    <div className="pong-card">
      <h2 className="text-[#00ffff] text-xl mb-3 text-center">Transaction History</h2>
      
      {/* New TransactionManager Pending Transactions - show this before tabs */}
      <PendingTransactions />
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-2 mb-4 bg-[#000033]">
          <TabsTrigger value="completed" className={tabTriggerClass}>
            Completed
          </TabsTrigger>
          <TabsTrigger value="pending" className={tabTriggerClass}>
            Pending
            {pendingTransactions.length > 0 && (
              <span className="ml-1 px-1.5 py-0.5 text-xs bg-[#ff00ff] text-white rounded-full">
                {pendingTransactions.length}
              </span>
            )}
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="completed" className="px-1">
          {isLoading ? (
            <div className="flex justify-center py-4">
              <Loader2 className="h-6 w-6 animate-spin text-[#ff00ff]" />
            </div>
          ) : error ? (
            <div className="text-center text-[#ff00ff]">
              Error loading transactions: {error instanceof Error ? error.message : 'Unknown error'}
            </div>
          ) : transactions && transactions.length > 0 ? (
            <div className="space-y-2">
              {/* Conditional rendering based on whether to show all transactions */}
              {!showAllTransactions ? (
                // Show only first 3 transactions
                <div className="space-y-2">
                  {displayedTransactions.map(renderTransaction)}
                </div>
              ) : (
                // Show all transactions in a scrollable container
                <ScrollArea className="h-[320px] rounded-md">
                  <div className="space-y-2 pr-3">
                    {sortedTransactions.map(renderTransaction)}
                  </div>
                </ScrollArea>
              )}
              
              {hasMoreTransactions && (
                <div className="pt-2 flex justify-center">
                  <Button 
                    className="pong-button py-1 px-3 text-xs flex items-center gap-1" 
                    onClick={() => setShowAllTransactions(!showAllTransactions)}
                  >
                    {showAllTransactions ? (
                      <>
                        <ChevronUp className="h-4 w-4" />
                        Show Less
                      </>
                    ) : (
                      <>
                        <ChevronDown className="h-4 w-4" />
                        Show More
                      </>
                    )}
                  </Button>
                </div>
              )}
            </div>
          ) : (
            <p className="text-sm text-[#bbbbff] text-center py-4">No completed transactions yet</p>
          )}
        </TabsContent>
        
        <TabsContent value="pending" className="px-1">
          {pendingTransactions.length > 0 ? (
            <ScrollArea className="h-[320px] rounded-md">
              <div className="space-y-2 pr-3">
                {pendingTransactions.map(renderPendingTransaction)}
              </div>
            </ScrollArea>
          ) : (
            <p className="text-sm text-[#bbbbff] text-center py-4">No pending transactions</p>
          )}
          
          <div className="pt-4">
            <p className="text-xs text-gray-400 italic">
              Transactions are automatically monitored and credits will be awarded after blockchain confirmation.
            </p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}