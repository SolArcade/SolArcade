import { useState, useEffect, useCallback } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronUp, Loader2 } from "lucide-react";
import { useWallet } from "@solana/wallet-adapter-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Transaction } from "@/context/TransactionContext";
import { useSocketEvent } from "@/lib/socketClient";

export default function TransactionHistory() {
  const { publicKey } = useWallet();
  const [showAllTransactions, setShowAllTransactions] = useState(false);
  const queryClient = useQueryClient();

  // Query for transactions
  const { data: transactions, isLoading, error } = useQuery<Transaction[]>({
    queryKey: ['/api/transactions', publicKey?.toString()],
    queryFn: async () => {
      if (!publicKey) return [];
      const res = await fetch(`/api/transactions/${publicKey.toString()}`);
      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(`Failed to fetch transactions: ${errorText}`);
      }
      
      // Get all transactions
      const allTransactions = await res.json();
      
      // Filter out any pending transactions (we now show only completed ones)
      const completedTransactions = allTransactions.filter((tx: Transaction) => 
        tx.status === 'finalized' || (tx.isCompleted === true));
      
      // Group refund transactions that happen within a short time window (1 minute)
      // to prevent duplicate display from the DB recording + Solana transaction 
      const txGroups: { [key: string]: Transaction[] } = {};
      
      // Group similar transactions (like multiple refunds in a short time window)
      completedTransactions.forEach((tx: Transaction) => {
        // For refund transactions, create a special key based on approximate time and amount
        if (tx.type === 'refund') {
          // Create a key using truncated timestamp (to minute) and rounded amount
          const txTime = new Date(tx.timestamp).getTime();
          const minuteKey = Math.floor(txTime / 60000) * 60000; // Round to nearest minute
          const amountKey = Math.round(Number(tx.amount) * 100) / 100; // Round to 2 decimal places
          const walletAddress = tx.description?.split(' ')[0] || ''; // Extract wallet from description if available
          const groupKey = `${tx.type}-${minuteKey}-${amountKey}-${walletAddress}`;
          
          if (!txGroups[groupKey]) {
            txGroups[groupKey] = [];
          }
          txGroups[groupKey].push(tx);
        } else {
          // For non-refund transactions, use the ID as key (no grouping)
          const groupKey = `${tx.id}`;
          txGroups[groupKey] = [tx];
        }
      });
      
      // For each group, keep only the most recent transaction
      const dedupedTransactions = Object.values(txGroups).map(group => {
        // Sort by timestamp descending and take the first one
        return group.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())[0];
      });
      
      return dedupedTransactions;
    },
    enabled: !!publicKey,
    // Refresh every 5 seconds (more frequent to catch updates faster)
    refetchInterval: 5000
  });

  // Socket event for real-time transaction updates - debounced to prevent duplicate fetches
  const [lastUpdateTime, setLastUpdateTime] = useState(0);
  const debounceTimeMs = 500; // Wait 500ms between fetches
  
  const debouncedFetchTransactions = useCallback(() => {
    const now = Date.now();
    if (now - lastUpdateTime > debounceTimeMs) {
      setLastUpdateTime(now);
      console.log('Fetching updated transaction data...');
      queryClient.invalidateQueries({queryKey: ['/api/transactions', publicKey?.toString()]});
    } else {
      console.log('Debounced transaction fetch - too soon after last update');
    }
  }, [queryClient, publicKey, lastUpdateTime]);

  // Socket event for real-time transaction updates
  useSocketEvent('transaction_update', (transaction) => {
    // Check if the transaction is related to this wallet before refreshing data
    if (publicKey && transaction.walletAddress === publicKey.toString()) {
      console.log('Transaction update received:', transaction);
      debouncedFetchTransactions();
    }
  });

  // Socket event for transaction confirmations
  useSocketEvent('transaction_confirmed', (transaction) => {
    // Check if the transaction is related to this wallet before refreshing data
    if (publicKey && transaction.walletAddress === publicKey.toString()) {
      console.log('Transaction confirmed:', transaction);
      debouncedFetchTransactions();
    }
  });

  // Socket event for game stakes
  useSocketEvent('game_stake_confirmed', (gameData) => {
    if (publicKey && gameData?.walletAddress === publicKey.toString()) {
      console.log('Game stake confirmed:', gameData);
      debouncedFetchTransactions();
    }
  });

  if (!publicKey) return null;

  // Sort transactions by timestamp (newest first) and determine which to display
  const sortedTransactions = transactions 
    ? [...transactions].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    : [];
    
  // Show only 3 transactions initially, or all transactions in a scrollable view if expanded
  const displayedTransactions = showAllTransactions 
    ? sortedTransactions 
    : sortedTransactions?.slice(0, 3);

  const hasMoreTransactions = sortedTransactions ? sortedTransactions.length > 3 : false;

  // Render a completed transaction row
  const renderTransaction = (tx: any) => {
    // Get transaction type - could be in transactionType (from API) or type (from context)
    const txType = tx.transactionType || tx.type || '';
    
    // Check for refund transaction types
    const isRefund = txType.includes('refund') || txType === 'refund';
    
    // Determine disconnect refund vs normal cancellation 
    const isDisconnectRefund = isRefund && 
      ((tx.description && typeof tx.description === 'string' && tx.description.includes('disconnect')) || 
       (txType && typeof txType === 'string' && txType.includes('disconnect')));
    
    // Get appropriate emoji and colors
    const getTxEmoji = () => {
      if (txType.includes('stake')) return '🎮';
      if (txType.includes('payout') || txType.includes('winnings')) return '🏆';
      if (txType.includes('disconnect_win')) return '🏅';
      if (isDisconnectRefund) return '🔌';
      if (isRefund) return '↩️';
      return '💰';
    };
    
    // Get transaction label
    const getTxLabel = () => {
      if (txType.includes('stake')) return 'Game Stake';
      if (txType.includes('payout')) return 'Game Payout';
      if (txType.includes('winnings')) return 'Game Winnings';
      if (txType.includes('disconnect_win')) return 'Disconnect Win';
      if (txType.includes('simulated')) return 'Refund (Simulated)';
      if (txType.includes('cancellation_refund')) {
        return isDisconnectRefund ? 'Disconnect Refund' : 'Game Cancellation Refund';
      }
      if (txType === 'refund') return 'Refund';
      return 'SOL Transaction';
    };
    
    // Card background and border styling
    const cardBg = isRefund 
      ? 'bg-gradient-to-r from-[#00ffff08] to-[#00ffff14] border-[#00ffff33]' 
      : (txType.includes('win') || txType.includes('payout'))
        ? 'bg-gradient-to-r from-[#ffff0008] to-[#ffff0014] border-[#ffff0033]'
        : 'border-[#ff00ff33]';
    
    return (
      <div 
        key={tx.id} 
        className={`flex justify-between items-center py-2 px-2 mb-2 rounded-md border-l-4 ${cardBg} last:mb-0`}
      >
        <div className="flex flex-col">
          <span className="text-sm text-[#bbbbff]">
            {new Date(tx.timestamp).toLocaleString()}
          </span>
          <span className={`text-xs flex items-center ${isRefund ? 'text-[#00ffff] font-medium' : txType.includes('win') ? 'text-[#ffff00] font-medium' : 'text-[#00ffaa]'}`}>
            <span className="mr-1 text-base">{getTxEmoji()}</span>
            {getTxLabel()}
          </span>
        </div>
        <span 
          className={`font-medium ${
            isRefund 
              ? 'text-[#00ffff]' 
              : txType.includes('win') || txType.includes('payout')
                ? 'text-[#ffff00]'
                : Number(tx.amount) < 0 
                  ? 'text-[#ff5577]' 
                  : 'text-[#00ffaa]'
          }`} 
          style={{textShadow: '0 0 5px currentColor'}}>
          {Number(tx.amount).toFixed(4)} SOL
        </span>
      </div>
    );
  };



  return (
    <div className="pong-card">
      <h2 className="text-[#00ffff] text-xl mb-3 text-center">Transaction History</h2>
      
      {isLoading ? (
        <div className="flex justify-center py-4">
          <Loader2 className="h-6 w-6 animate-spin text-[#ff00ff]" />
        </div>
      ) : error ? (
        <div className="text-center text-[#ff00ff]">
          Error loading transactions: {error instanceof Error ? error.message : 'Unknown error'}
        </div>
      ) : transactions && transactions.length > 0 ? (
        <div className="space-y-2 px-1">
          {/* Conditional rendering based on whether to show all transactions */}
          {!showAllTransactions ? (
            // Show only first 3 transactions
            <div className="space-y-2">
              {displayedTransactions.map(renderTransaction)}
            </div>
          ) : (
            // Show all transactions in a scrollable container
            <ScrollArea className="h-[320px] rounded-md">
              <div className="space-y-2 pr-3">
                {sortedTransactions.map(renderTransaction)}
              </div>
            </ScrollArea>
          )}
          
          {hasMoreTransactions && (
            <div className="pt-2 flex justify-center">
              <Button 
                className="pong-button py-1 px-3 text-xs flex items-center gap-1" 
                onClick={() => setShowAllTransactions(!showAllTransactions)}
              >
                {showAllTransactions ? (
                  <>
                    <ChevronUp className="h-4 w-4" />
                    Show Less
                  </>
                ) : (
                  <>
                    <ChevronDown className="h-4 w-4" />
                    Show More
                  </>
                )}
              </Button>
            </div>
          )}
          
          <div className="pt-4">
            <p className="text-xs text-gray-400 italic">
              Transactions are automatically monitored and confirmed through the Solana blockchain network.
            </p>
          </div>
        </div>
      ) : (
        <p className="text-sm text-[#bbbbff] text-center py-4">No transactions yet</p>
      )}
    </div>
  );
}