import { useWallet } from "@solana/wallet-adapter-react";
import { useState, useEffect } from "react";
import { toast } from "../hooks/use-toast";
import { RefreshCw } from 'lucide-react';
import { useBalance } from "../context/BalanceContext";

export default function CreditBalance() {
  const wallet = useWallet();
  const { balance: contextBalance, isLoading, error: contextError, refreshBalance } = useBalance();
  const [lastBalanceChange, setLastBalanceChange] = useState<{amount: number, timestamp: number} | null>(null);
  
  // Handle balance update events
  useEffect(() => {
    const handleBalanceUpdated = (event: CustomEvent) => {
      console.log("SOL balance update event received:", event.detail);
      
      // If detail contains SOL amount change
      if (event.detail && typeof event.detail.amount === 'number') {
        setLastBalanceChange({
          amount: event.detail.amount,
          timestamp: Date.now()
        });
        
        // Show a toast notification for balance changes
        if (event.detail.amount > 0) {
          toast({
            title: "SOL Received",
            description: `${event.detail.amount} SOL has been added to your account!`,
            variant: "default",
          });
        } else if (event.detail.amount < 0) {
          toast({
            title: "SOL Staked",
            description: `${Math.abs(event.detail.amount)} SOL has been staked for gameplay.`,
            variant: "default",
          });
        }
      }
    };
    
    // Listen for the standard event
    window.addEventListener('solBalanceUpdated', handleBalanceUpdated as EventListener);
    
    // Also listen for transaction completed events
    const handleTransactionComplete = (event: CustomEvent) => {
      console.log("Transaction completed event received:", event.detail);
      
      if (event.detail && event.detail.amount) {
        setLastBalanceChange({
          amount: event.detail.amount,
          timestamp: Date.now()
        });
        
        // Refresh the balance after a transaction
        refreshBalance();
        
        toast({
          title: "Transaction Complete",
          description: `Your transaction of ${event.detail.amount} SOL has been completed!`,
          variant: "default",
        });
      }
    };
    
    window.addEventListener('transactionCompleted', handleTransactionComplete as EventListener);
    
    // Support legacy event system to prevent errors
    const handleLegacyUpdate = (newAmount: number) => {
      console.log("Legacy update received:", newAmount);
      // Just refresh the balance to get latest value
      refreshBalance();
    };
    
    // Add the legacy global function if it doesn't exist
    if (!window.updatePongCreditsUI) {
      window.updatePongCreditsUI = handleLegacyUpdate;
    }
    
    return () => {
      window.removeEventListener('solBalanceUpdated', handleBalanceUpdated as EventListener);
      window.removeEventListener('transactionCompleted', handleTransactionComplete as EventListener);
    };
  }, [refreshBalance]);
  
  // We don't need to trigger refreshBalance here
  // The BalanceContext will handle fetching when the wallet connects
  useEffect(() => {
    if (wallet.publicKey) {
      console.log("Wallet connected in CreditBalance component");
    }
  }, [wallet.publicKey]);
  
  if (!wallet.publicKey) return null;
  
  return (
    <div 
      className="relative flex items-center gap-2 text-[#00ffff] font-bold cursor-pointer group"
      onClick={() => refreshBalance()}
    >
      {isLoading ? (
        <>
          <RefreshCw className="h-4 w-4 animate-spin" />
          <span className="text-lg">Loading...</span>
        </>
      ) : contextError ? (
        <div className="text-red-400">
          <span className="text-sm">Error loading balance</span>
          <button 
            onClick={(e) => { e.stopPropagation(); refreshBalance(); }}
            className="ml-2 text-cyan-400 underline"
          >
            Retry
          </button>
        </div>
      ) : (
        <>
          <span className="text-lg">{contextBalance !== null ? contextBalance : 0}</span>
          <span className="text-sm uppercase">SOL Balance</span>
          
          <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-6 left-0 bg-black/60 text-cyan-300 text-xs p-1 rounded">
            Click to refresh
          </div>
        </>
      )}
      
      {/* Balance change animation */}
      {lastBalanceChange && Date.now() - lastBalanceChange.timestamp < 2000 && (
        <div 
          className={`absolute text-sm animate-float-up ${lastBalanceChange.amount > 0 ? 'text-green-400' : 'text-red-400'}`}
          style={{top: '-1.5rem', left: '0', opacity: 0.8}}
        >
          {lastBalanceChange.amount > 0 ? `+${lastBalanceChange.amount}` : lastBalanceChange.amount} SOL
        </div>
      )}
      
      {/* Animated glow effect for SOL balance */}
      <div className="relative ml-1">
        <div className="absolute inset-0 rounded-full bg-[#00ffff] opacity-20 animate-ping" 
             style={{animationDuration: '2s'}}></div>
        <div className="h-2 w-2 rounded-full bg-[#00ffff]"
             style={{boxShadow: '0 0 8px 2px #00ffff'}}></div>
      </div>
    </div>
  );
}