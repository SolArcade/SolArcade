import { useTransactionPersistence } from "../App";
import { useWallet } from "@solana/wallet-adapter-react";
import { useState, useEffect } from "react";

export default function CreditBalance() {
  const { publicKey } = useWallet();
  const { credits } = useTransactionPersistence();
  const [apiCredits, setApiCredits] = useState<number | null>(null);
  
  // Fetch credits from API for backward compatibility
  useEffect(() => {
    if (!publicKey) return;
    
    const fetchCredits = async () => {
      try {
        const response = await fetch(`/api/user/${publicKey.toString()}`);
        if (response.ok) {
          const data = await response.json();
          if (data && typeof data.pongCredits === 'number') {
            setApiCredits(data.pongCredits);
          }
        }
      } catch (error) {
        console.error("Error fetching user credits:", error);
      }
    };
    
    fetchCredits();
    
    // Refresh every 10 seconds
    const interval = setInterval(fetchCredits, 10000);
    return () => clearInterval(interval);
  }, [publicKey]);
  
  // Get the definitive credit amount, prioritizing Firebase if available
  const creditBalance = credits || apiCredits || 0;
  
  if (!publicKey) return null;
  
  return (
    <div className="flex items-center gap-2 text-[#00ffff] font-bold">
      <span className="text-lg">{creditBalance}</span>
      <span className="text-sm uppercase">Pong Credits</span>
      {/* Animated glow effect for credits */}
      <div className="relative ml-1">
        <div className="absolute inset-0 rounded-full bg-[#00ffff] opacity-20 animate-ping" 
             style={{animationDuration: '2s'}}></div>
        <div className="h-2 w-2 rounded-full bg-[#00ffff]"
             style={{boxShadow: '0 0 8px 2px #00ffff'}}></div>
      </div>
    </div>
  );
}