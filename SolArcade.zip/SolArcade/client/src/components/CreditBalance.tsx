import { useWallet } from "@solana/wallet-adapter-react";
import { useState, useEffect, useCallback, useMemo } from "react";
import { toast } from "../hooks/use-toast";
import { createBalanceService, setupBalanceRefreshTriggers } from "../lib/balanceService";
import { RefreshCw } from 'lucide-react';

export default function CreditBalance() {
  const wallet = useWallet();
  const [balance, setBalance] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastCreditChange, setLastCreditChange] = useState<{amount: number, timestamp: number} | null>(null);
  
  // Create the balance service
  const balanceService = useMemo(() => createBalanceService(), []);
  
  // Fetch balance function
  const refreshBalance = useCallback(async (forceRefresh = false) => {
    if (!wallet.publicKey) {
      setBalance(null);
      setLoading(false);
      return;
    }
    
    setLoading(true);
    try {
      console.log("Fetching user credits with balanceService");
      const newBalance = await balanceService.fetchBalance(wallet, forceRefresh);
      setBalance(newBalance);
      setError(null);
    } catch (err: any) {
      console.error("Failed to load balance:", err);
      setError("Failed to load your current balance");
    } finally {
      setLoading(false);
    }
  }, [wallet, balanceService]);
  
  // Handle credit update events
  useEffect(() => {
    const handleCreditsUpdated = (event: CustomEvent) => {
      console.log("Credit update event received:", event.detail);
      
      // If detail contains both total credits and change amount
      if (event.detail && typeof event.detail.credits === 'number') {
        // Update the cached balance
        balanceService.updateCachedBalance(event.detail.credits);
        
        // Also update the UI
        setBalance(event.detail.credits);
        
        // If there was a credits delta, record it for animation
        if (event.detail.added && typeof event.detail.added === 'number') {
          setLastCreditChange({
            amount: event.detail.added,
            timestamp: Date.now()
          });
          
          // Show a toast notification for credit changes
          if (event.detail.added > 0) {
            toast({
              title: "Credits Added",
              description: `${event.detail.added} Pong Credits have been added to your account!`,
              variant: "default",
            });
          } else if (event.detail.added < 0) {
            toast({
              title: "Credits Used",
              description: `${Math.abs(event.detail.added)} Pong Credits have been used.`,
              variant: "default",
            });
          }
        }
      }
    };
    
    // Listen for the standard event
    window.addEventListener('pongCreditsUpdated', handleCreditsUpdated as EventListener);
    
    // Also listen for purchase completed events
    const handlePurchaseComplete = (event: CustomEvent) => {
      console.log("Purchase completed event received:", event.detail);
      if (event.detail && typeof event.detail.newBalance === 'number') {
        balanceService.updateCachedBalance(event.detail.newBalance);
        setBalance(event.detail.newBalance);
        
        // Calculate added credits based on SOL amount
        if (event.detail.amount) {
          const addedCredits = event.detail.amount * 100; // 1 SOL = 100 credits
          setLastCreditChange({
            amount: addedCredits,
            timestamp: Date.now()
          });
          
          toast({
            title: "Purchase Complete",
            description: `${addedCredits} Pong Credits have been added to your account!`,
            variant: "default",
          });
        }
      }
    };
    
    window.addEventListener('pongCreditsPurchased', handlePurchaseComplete as EventListener);
    
    // Also support legacy event system
    const handleLegacyUpdate = (newCredits: number) => {
      console.log("Legacy credit update received:", newCredits);
      balanceService.updateCachedBalance(newCredits);
      setBalance(newCredits);
    };
    
    // Add the legacy global function if it doesn't exist
    if (!window.updatePongCreditsUI) {
      window.updatePongCreditsUI = handleLegacyUpdate;
    }
    
    return () => {
      window.removeEventListener('pongCreditsUpdated', handleCreditsUpdated as EventListener);
      window.removeEventListener('pongCreditsPurchased', handlePurchaseComplete as EventListener);
    };
  }, [balanceService]);
  
  // Set up balance refresh triggers
  useEffect(() => {
    refreshBalance();
    const cleanup = setupBalanceRefreshTriggers(wallet, balanceService);
    
    // Also refresh balance every 15 seconds
    const intervalId = setInterval(() => refreshBalance(), 15000);
    
    return () => {
      cleanup();
      clearInterval(intervalId);
    };
  }, [wallet, balanceService, refreshBalance]);
  
  // Refresh when wallet changes
  useEffect(() => {
    refreshBalance(true);
  }, [wallet.publicKey, refreshBalance]);
  
  if (!wallet.publicKey) return null;
  
  return (
    <div 
      className="relative flex items-center gap-2 text-[#00ffff] font-bold cursor-pointer group"
      onClick={() => refreshBalance(true)}
    >
      {loading ? (
        <>
          <RefreshCw className="h-4 w-4 animate-spin" />
          <span className="text-lg">Loading...</span>
        </>
      ) : error ? (
        <div className="text-red-400">
          <span className="text-sm">Error loading balance</span>
          <button 
            onClick={(e) => { e.stopPropagation(); refreshBalance(true); }}
            className="ml-2 text-cyan-400 underline"
          >
            Retry
          </button>
        </div>
      ) : (
        <>
          <span className="text-lg">{balance !== null ? balance : 0}</span>
          <span className="text-sm uppercase">Pong Credits</span>
          
          <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-6 left-0 bg-black/60 text-cyan-300 text-xs p-1 rounded">
            Click to refresh
          </div>
        </>
      )}
      
      {/* Credit change animation */}
      {lastCreditChange && Date.now() - lastCreditChange.timestamp < 2000 && (
        <div 
          className={`absolute text-sm animate-float-up ${lastCreditChange.amount > 0 ? 'text-green-400' : 'text-red-400'}`}
          style={{top: '-1.5rem', left: '0', opacity: 0.8}}
        >
          {lastCreditChange.amount > 0 ? `+${lastCreditChange.amount}` : lastCreditChange.amount}
        </div>
      )}
      
      {/* Animated glow effect for credits */}
      <div className="relative ml-1">
        <div className="absolute inset-0 rounded-full bg-[#00ffff] opacity-20 animate-ping" 
             style={{animationDuration: '2s'}}></div>
        <div className="h-2 w-2 rounded-full bg-[#00ffff]"
             style={{boxShadow: '0 0 8px 2px #00ffff'}}></div>
      </div>
    </div>
  );
}