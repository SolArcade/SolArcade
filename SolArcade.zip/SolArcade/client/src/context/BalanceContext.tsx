import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useConnection } from '@solana/wallet-adapter-react';
import { useWallet } from '@solana/wallet-adapter-react';

// Create context
interface BalanceContextProps {
  balance: number | null;
  isLoading: boolean;
  error: string | null;
  refreshBalance: () => Promise<void>;
  lastUpdated: number;
}

const defaultBalanceContext: BalanceContextProps = {
  balance: null,
  isLoading: false,
  error: null,
  refreshBalance: async () => {},
  lastUpdated: 0
};

const BalanceContext = createContext<BalanceContextProps>(defaultBalanceContext);

// Custom hook to use the balance context
export const useBalance = () => useContext(BalanceContext);

// Balance provider component
export function BalanceProvider({ children }: { children: React.ReactNode }) {
  const { connection } = useConnection();
  const { publicKey } = useWallet();
  const [balance, setBalance] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<number>(0);
  const [serverBalance, setServerBalance] = useState<number | null>(null);

  // Track last successful fetch time to prevent excessive requests
  const [lastFetchTime, setLastFetchTime] = useState<number>(0);

  // Main function to fetch balance from multiple sources
  const fetchBalance = useCallback(async (force = false) => {
    if (!publicKey) {
      setBalance(null);
      return;
    }

    // Don't fetch if already loading and not forced
    if (isLoading && !force) return;

    // Debounce requests - only fetch if forced or if it's been more than 5 seconds since last fetch
    const now = Date.now();
    if (!force && now - lastFetchTime < 5000) {
      console.log('BalanceContext: Skipping fetch, last fetch was too recent');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      // Fetch SOL balance directly from blockchain
      try {
        const solBalance = await connection.getBalance(publicKey);
        const solBalanceInSol = solBalance / 1000000000; // Convert lamports to SOL
        
        console.log('BalanceContext: Fetched SOL balance:', solBalanceInSol);
        
        // Update last fetch time
        setLastFetchTime(now);
        
        // Set balance state
        setBalance(solBalanceInSol);
        setServerBalance(solBalanceInSol);
        setLastUpdated(Date.now());
      } catch (error) {
        console.error('Error fetching SOL balance:', error);
        throw new Error('Failed to fetch SOL balance from blockchain');
      }
    } catch (serverError) {
      console.error('Server balance fetch error:', serverError);
      
      // Fallback to localStorage
      try {
        const storedBalance = localStorage.getItem(`balance_${publicKey.toString()}`);
        if (storedBalance) {
          setBalance(parseInt(storedBalance, 10));
          setLastUpdated(Date.now());
        } else {
          setBalance(0);
        }
      } catch (localError) {
        console.error('Local balance fetch error:', localError);
        setError('Failed to fetch balance from all sources');
        setBalance(0);
      }
    } finally {
      setIsLoading(false);
    }
  }, [publicKey, isLoading, connection]);

  // Public function to refresh balance
  const refreshBalance = useCallback(async () => {
    await fetchBalance(true);
  }, [fetchBalance]);

  // Load balance when wallet connects
  useEffect(() => {
    if (publicKey) {
      // Don't trigger fetchBalance here as it's already called in the polling effect
      console.log("Wallet connected, balance will be fetched by the polling mechanism");
    } else {
      setBalance(null);
    }
  }, [publicKey]);

  // Save balance to localStorage when it changes
  useEffect(() => {
    if (publicKey && balance !== null) {
      localStorage.setItem(`balance_${publicKey.toString()}`, balance.toString());
    }
  }, [publicKey, balance]);

  // Listen for SOL balance update events
  useEffect(() => {
    const handleSolBalanceUpdated = (event: CustomEvent) => {
      const { amount: newBalance } = event.detail;
      if (newBalance !== undefined) {
        setBalance(newBalance);
        setLastUpdated(Date.now());
      }
    };

    // Add event listener
    window.addEventListener('solBalanceUpdated', handleSolBalanceUpdated as EventListener);

    // Cleanup
    return () => {
      window.removeEventListener('solBalanceUpdated', handleSolBalanceUpdated as EventListener);
    };
  }, []);

  // Poll for balance updates every 30 seconds
  useEffect(() => {
    if (!publicKey) return;
    
    // Initial fetch
    fetchBalance();
    
    const interval = setInterval(() => {
      fetchBalance();
    }, 30000);
    
    return () => clearInterval(interval);
  }, [publicKey]);

  // Context value
  const contextValue: BalanceContextProps = {
    balance,
    isLoading,
    error,
    refreshBalance,
    lastUpdated
  };

  return (
    <BalanceContext.Provider value={contextValue}>
      {children}
    </BalanceContext.Provider>
  );
}

export default BalanceContext;