import React, { createContext, useContext, useReducer, useEffect, useCallback } from 'react';
import { useConnection, useWallet } from '@solana/wallet-adapter-react';
import { Transaction as SolanaTransaction, PublicKey } from '@solana/web3.js';
import { nanoid } from 'nanoid';

// Define Transaction type
export interface Transaction {
  id: string;
  signature?: string;
  type: 'pongCredit' | 'transfer' | 'generic' | 'gameStake' | 'refund';
  amount: number;
  status: 'pending' | 'confirming' | 'confirmed' | 'finalized' | 'failed' | 'unknown';
  timestamp: number;
  lastUpdated: number;
  isCompleted?: boolean;
  description?: string;
  confirmations?: number;
  error?: string;
  pongCredits?: number; // Keeping for backward compatibility
  stakeAmount?: number; // Added for direct SOL stake tracking
  originalStake?: number; // Added for refund tracking to show original stake amount
}

// Action types
const ACTIONS = {
  ADD_TRANSACTION: 'ADD_TRANSACTION',
  UPDATE_TRANSACTION: 'UPDATE_TRANSACTION',
  SET_TRANSACTIONS: 'SET_TRANSACTIONS',
  CLEAR_COMPLETED: 'CLEAR_COMPLETED',
  SET_PROCESSING: 'SET_PROCESSING'
};

// Initial state
interface TransactionState {
  transactions: Transaction[];
  isLoading: boolean;
  error: string | null;
  isProcessingPurchase: boolean;
}

const initialState: TransactionState = {
  transactions: [],
  isLoading: false,
  error: null,
  isProcessingPurchase: false
};

// Reducer
function transactionReducer(state: TransactionState, action: any): TransactionState {
  switch (action.type) {
    case ACTIONS.ADD_TRANSACTION:
      // Check if transaction already exists
      const exists = state.transactions.some(tx => 
        (tx.signature && tx.signature === action.payload.signature) || 
        tx.id === action.payload.id
      );
      
      if (exists) {
        return state;
      }
      
      return {
        ...state,
        transactions: [action.payload, ...state.transactions]
      };
    
    case ACTIONS.UPDATE_TRANSACTION:
      return {
        ...state,
        transactions: state.transactions.map(tx =>
          ((tx.signature && tx.signature === action.payload.signature) || 
           tx.id === action.payload.id)
            ? { ...tx, ...action.payload, lastUpdated: Date.now() }
            : tx
        )
      };
    
    case ACTIONS.SET_TRANSACTIONS:
      return {
        ...state,
        transactions: action.payload,
        isLoading: false
      };
      
    case ACTIONS.CLEAR_COMPLETED:
      return {
        ...state,
        transactions: state.transactions.filter(tx =>
          tx.status !== 'finalized' && 
          tx.status !== 'confirmed' && 
          !tx.isCompleted
        )
      };
    
    case ACTIONS.SET_PROCESSING:
      return {
        ...state,
        isProcessingPurchase: action.payload
      };
    
    default:
      return state;
  }
}

// Context interface
interface TransactionContextState {
  pendingTransactions: Transaction[];
  completedTransactions: Transaction[];
  allTransactions: Transaction[];
  addPendingTransaction: (transaction: Partial<Transaction>) => Transaction;
  updateTransactionStatus: (id: string, status: Transaction['status'], metadata?: Record<string, any>) => void;
  cleanupTransactions: () => void;
  purchaseCredits: (solAmount: number) => Promise<{ signature: string }>;
  isProcessingPurchase: boolean;
}

// Create context with default values
const TransactionContextInstance = createContext<TransactionContextState>({
  pendingTransactions: [],
  completedTransactions: [],
  allTransactions: [],
  addPendingTransaction: () => ({ 
    id: '', 
    type: 'generic', 
    amount: 0, 
    status: 'unknown', 
    timestamp: 0, 
    lastUpdated: 0 
  }),
  updateTransactionStatus: () => {},
  cleanupTransactions: () => {},
  purchaseCredits: async () => ({ signature: '' }),
  isProcessingPurchase: false,
});

// Custom hook to use the transaction context
export const useTransactionContext = () => useContext(TransactionContextInstance);

// Helper function to create a purchase instruction
const createPurchaseInstruction = async (
  publicKey: PublicKey, 
  solAmount: number
): Promise<any> => {
  // This is a simplified placeholder - the real implementation would
  // create an actual Solana instruction for your specific program
  console.log('Creating purchase instruction for', publicKey.toString(), 'amount:', solAmount);
  
  // In a real implementation, you'd use specific program instructions
  // This is just a placeholder
  return {
    programId: new PublicKey('45GGPAkoxwisBWj5YtHj1BH1tekmoFbRigSNJ4fT9UD2'),
    data: Buffer.from([]),
    keys: [
      { pubkey: publicKey, isSigner: true, isWritable: true },
      // Add other keys as needed for your program
    ]
  };
};

// Map server status to display status
function mapServerStatus(serverStatus: string): Transaction['status'] {
  switch (serverStatus) {
    case 'pending': return 'pending';
    case 'sol_confirmed': return 'confirming';
    case 'confirming': return 'confirming';
    case 'confirmed': return 'confirmed';
    case 'credits_issued': return 'finalized';
    case 'completed': return 'finalized';
    case 'failed': return 'failed';
    default: return 'unknown';
  }
}

// Provider component
export const TransactionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(transactionReducer, initialState);
  const { connection } = useConnection();
  const wallet = useWallet();
  
  // Computed properties
  const pendingTransactions = state.transactions.filter(tx => 
    tx.status === 'pending' || 
    tx.status === 'confirming' || 
    (tx.status === 'confirmed' && !tx.isCompleted)
  );
  
  const completedTransactions = state.transactions.filter(tx => 
    tx.isCompleted || tx.status === 'finalized'
  );
  
  // Add a transaction to the store
  const addPendingTransaction = useCallback((transaction: Partial<Transaction>): Transaction => {
    const newTx: Transaction = {
      id: transaction.id || nanoid(),
      signature: transaction.signature,
      type: transaction.type || 'gameStake',
      amount: transaction.amount || 0,
      status: transaction.status || 'pending',
      timestamp: transaction.timestamp || Date.now(),
      lastUpdated: Date.now(),
      isCompleted: transaction.isCompleted || false,
      description: transaction.description,
      pongCredits: transaction.pongCredits, // Keep for backward compatibility
      stakeAmount: transaction.stakeAmount || transaction.amount || 0, // New field for stake amount
      confirmations: transaction.confirmations,
      error: transaction.error
    };
    
    dispatch({ type: ACTIONS.ADD_TRANSACTION, payload: newTx });
    
    // Set up listener for this transaction
    if (transaction.signature && connection) {
      setupTransactionListener(transaction.signature);
    }
    
    return newTx;
  }, [connection]);
  
  // Update a transaction in the store
  const updateTransactionStatus = useCallback((idOrSignature: string, status: Transaction['status'], metadata: Record<string, any> = {}): void => {
    dispatch({
      type: ACTIONS.UPDATE_TRANSACTION,
      payload: { 
        ...metadata, 
        id: idOrSignature,
        signature: idOrSignature,
        status,
        lastUpdated: Date.now()
      }
    });
  }, []);
  
  // Enhanced transaction listener for better error recovery
  const setupTransactionListener = useCallback((signature: string): (() => void) => {
    if (!connection) return () => {};
    
    console.log('Setting up enhanced listener for transaction', signature);
    
    // Check initial status with robust recovery handling
    connection.getSignatureStatus(signature)
      .then(result => {
        if (result && result.value) {
          const status = result.value.err ? 'failed' : 
            (result.value.confirmationStatus as any || 'pending');
          
          updateTransactionStatus(signature, status);
          
          // Critical: If the status is already confirmed/finalized in blockchain
          // but credits may not have been issued due to disconnection or refresh,
          // we need to immediately verify with the server
          if (status === 'confirmed' || status === 'finalized') {
            console.log(`Transaction ${signature} already confirmed, checking credit status`);
            checkTransactionServerStatus(signature);
          }
        }
      })
      .catch(error => console.error(`Error checking tx ${signature}:`, error));
    
    // Set up subscription for status updates with enhanced error handling
    let subscriptionId: number | undefined;
    try {
      subscriptionId = connection.onSignature(
        signature,
        (result, context) => {
          const status = result.err ? 'failed' : 'confirmed';
          updateTransactionStatus(signature, status);
          
          // If confirmed, check if this is a pong credit purchase
          // and verify credits were issued - enhanced with retry mechanism
          if (!result.err) {
            checkTransactionServerStatus(signature);
          }
        },
        'confirmed'
      );
    } catch (error) {
      console.error('Error setting up transaction listener:', error);
    }
    
    // Return cleanup function
    return () => {
      if (subscriptionId !== undefined) {
        connection.removeSignatureListener(subscriptionId);
      }
    };
  }, [connection, updateTransactionStatus]);
  
  // Helper function to check and update transaction status from server
  // Extracted for reuse and clarity with robust retry logic
  const checkTransactionServerStatus = useCallback((signature: string, retryCount = 0) => {
    // Wait a moment for any server-side processes to complete
    // Longer initial wait to give server time to process
    setTimeout(() => {
      fetch(`/api/transactions/${signature}/status`)
        .then(response => {
          if (!response.ok) {
            throw new Error(`Server returned ${response.status}`);
          }
          return response.json();
        })
        .then(data => {
          console.log(`Server status for ${signature}:`, data.status);
          
          if (data.status === 'credits_issued' || data.status === 'completed') {
            // Success path - credits were issued
            updateTransactionStatus(signature, 'finalized', { 
              isCompleted: true 
            });
            
            // Dispatch event for UI notification and balance update
            const balanceEvent = new CustomEvent('solBalanceUpdated', {
              detail: { signature, amount: data.amount || 0, stakeAmount: data.stakeAmount || data.amount || 0 }
            });
            window.dispatchEvent(balanceEvent);
          } 
          else if (['pending', 'confirming', 'processing'].includes(data.status)) {
            // Transaction is still being processed by server
            // Retry with exponential backoff if not at max retries
            if (retryCount < 5) {
              console.log(`Transaction ${signature} still processing, retry ${retryCount + 1}`);
              const backoff = Math.min(1000 * Math.pow(2, retryCount), 20000); // Max 20 seconds
              checkTransactionServerStatus(signature, retryCount + 1);
            }
          }
          else if (data.status === 'not_found' && retryCount < 3) {
            // Server might not have seen the transaction yet, retry
            console.log(`Transaction ${signature} not found in server, retrying...`);
            checkTransactionServerStatus(signature, retryCount + 1);
          }
        })
        .catch(error => {
          console.error(`Error checking tx status ${signature}:`, error);
          
          // Retry on server error with backoff if not at max retries
          if (retryCount < 3) {
            const backoff = 2000 * (retryCount + 1); // Increase delay with each retry
            console.log(`Retrying transaction check in ${backoff}ms`);
            setTimeout(() => {
              checkTransactionServerStatus(signature, retryCount + 1);
            }, backoff);
          }
        });
    }, retryCount === 0 ? 3000 : 1500); // Longer initial wait, shorter on retries
  }, [updateTransactionStatus]);
  
  // Clear completed transactions
  const cleanupTransactions = useCallback(() => {
    dispatch({ type: ACTIONS.CLEAR_COMPLETED });
  }, []);
  
  // Load transactions from server and localStorage
  const loadTransactions = useCallback(async () => {
    if (!wallet.publicKey) return;
    
    try {
      // First load from localStorage as fallback
      try {
        const savedTxs = JSON.parse(
          localStorage.getItem(`transactions_${wallet.publicKey.toString()}`) || '[]'
        );
        dispatch({ type: ACTIONS.SET_TRANSACTIONS, payload: savedTxs });
      } catch (e) {
        console.error('Error loading transactions from localStorage:', e);
      }
      
      // Then fetch from server
      const response = await fetch(`/api/transactions/user/${wallet.publicKey.toString()}`);
      
      if (response.ok) {
        const serverTxs = await response.json();
        
        // Convert server format to our format
        const formattedTxs = serverTxs.map((tx: any) => ({
          id: tx.id.toString(),
          signature: tx.transactionSignature,
          type: 'pongCredit' as const,
          amount: parseFloat(tx.amount),
          status: mapServerStatus(tx.status),
          timestamp: new Date(tx.timestamp).getTime(),
          lastUpdated: Date.now(),
          isCompleted: tx.status === 'credits_issued' || tx.status === 'completed',
          description: `${tx.pongCredits} Pong Credits`,
          pongCredits: tx.pongCredits
        }));
        
        dispatch({ type: ACTIONS.SET_TRANSACTIONS, payload: formattedTxs });
        
        // Set up listeners for pending transactions
        formattedTxs
          .filter((tx: Transaction) => !tx.isCompleted && tx.signature)
          .forEach((tx: Transaction) => {
            if (tx.signature) setupTransactionListener(tx.signature);
          });
      }
    } catch (error) {
      console.error('Error loading transactions:', error);
    }
  }, [wallet.publicKey, setupTransactionListener]);
  
  // Purchase Pong Credits function
  const purchaseCredits = async (solAmount: number): Promise<{ signature: string }> => {
    if (!wallet.publicKey || !wallet.sendTransaction) {
      throw new Error('Wallet not connected');
    }
    
    dispatch({ type: ACTIONS.SET_PROCESSING, payload: true });
    
    try {
      // 1. Create the transaction
      const transaction = new SolanaTransaction();
      
      // Add purchase instruction 
      const purchaseInstruction = await createPurchaseInstruction(wallet.publicKey, solAmount);
      transaction.add(purchaseInstruction);
      
      // 2. Send the transaction
      const signature = await wallet.sendTransaction(transaction, connection);
      console.log('Transaction sent:', signature);
      
      // 3. Add to our transaction store IMMEDIATELY
      addPendingTransaction({
        signature,
        type: 'pongCredit',
        amount: solAmount,
        pongCredits: Math.floor(solAmount * 100), // 1 SOL = 100 credits
        timestamp: Date.now(),
        description: `Purchasing Pong Credits`,
        status: 'pending'
      });
      
      // 4. Create a server-side record
      const response = await fetch('/api/transactions/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          signature,
          walletAddress: wallet.publicKey.toString(),
          solAmount
        })
      });
      
      if (!response.ok) {
        console.error('Failed to create transaction record on server');
      }
      
      // 5. Wait for confirmation
      const result = await connection.confirmTransaction(signature, 'confirmed');
      
      if (result.value.err) {
        throw new Error(`Transaction failed: ${JSON.stringify(result.value.err)}`);
      }
      
      // 6. Notify server that SOL transfer is confirmed
      const confirmResponse = await fetch('/api/transactions/confirm-sol', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ signature })
      });
      
      if (!confirmResponse.ok) {
        console.warn('Failed to confirm SOL receipt on server, but transaction was successful');
      }
      
      dispatch({ type: ACTIONS.SET_PROCESSING, payload: false });
      return { signature };
    } catch (error) {
      console.error('Error purchasing credits:', error);
      dispatch({ type: ACTIONS.SET_PROCESSING, payload: false });
      throw error;
    }
  };
  
  // Save transactions to localStorage when they change
  useEffect(() => {
    if (wallet.publicKey && state.transactions.length > 0) {
      localStorage.setItem(
        `transactions_${wallet.publicKey.toString()}`, 
        JSON.stringify(state.transactions)
      );
    }
  }, [state.transactions, wallet.publicKey]);
  
  // Load transactions when wallet connects
  useEffect(() => {
    if (wallet.publicKey) {
      loadTransactions();
    }
  }, [wallet.publicKey, loadTransactions]);
  
  // Also fetch pending transactions from server
  useEffect(() => {
    if (wallet.publicKey) {
      fetch(`/api/pending-transactions/${wallet.publicKey.toString()}`)
        .then(res => res.json())
        .then(data => {
          // Add these transactions to our store
          data.forEach((tx: {
            id: string;
            signature?: string;
            amount: number;
            credits: number;
            status: string;
            timestamp: number;
          }) => {
            addPendingTransaction({
              id: tx.id,
              signature: tx.signature,
              type: 'pongCredit',
              amount: tx.amount,
              pongCredits: tx.credits,
              status: mapServerStatus(tx.status),
              timestamp: tx.timestamp,
              description: `${tx.credits} Pong Credits`
            });
          });
        })
        .catch(e => console.error('Failed to fetch pending transactions', e));
    }
  }, [wallet.publicKey, addPendingTransaction]);
  
  // Enhanced recovery system for incomplete transactions
  useEffect(() => {
    const recoverIncompleteTransactions = async () => {
      if (!wallet.publicKey || !connection) return;
      
      console.log('Running enhanced transaction recovery system...');
      
      try {
        // 1. First check localStorage for any transactions that might not be in the server
        try {
          const localStorageKey = 'pendingTransactions';
          const stored = localStorage.getItem(localStorageKey);
          
          if (stored) {
            let localTxs: any[] = [];
            
            try {
              // Try to parse as new format with version
              const parsed = JSON.parse(stored);
              if (parsed.version && Array.isArray(parsed.transactions)) {
                // Verify wallet matches
                if (!parsed.walletAddress || parsed.walletAddress === wallet.publicKey.toString()) {
                  localTxs = parsed.transactions;
                }
              }
              // Try to parse as old format (direct array)
              else if (Array.isArray(parsed)) {
                localTxs = parsed;
              }
            } catch (e) {
              console.error('Error parsing localStorage transactions:', e);
            }
            
            // Process any pending local transactions
            for (const tx of localTxs) {
              if (tx.signature && !tx.isCompleted && 
                  (tx.status === 'pending' || tx.status === 'confirming')) {
                console.log(`Checking local transaction ${tx.signature} for recovery`);
                
                // Check blockchain status
                try {
                  const status = await connection.getSignatureStatus(tx.signature);
                  
                  if (status && status.value) {
                    const blockchainStatus = status.value.err ? 'failed' : 
                      (status.value.confirmationStatus as 'processed' | 'confirmed' | 'finalized' || 'pending');
                    
                    if (blockchainStatus === 'confirmed' || blockchainStatus === 'finalized') {
                      console.log(`Local transaction ${tx.signature} is confirmed on blockchain, checking server status`);
                      checkTransactionServerStatus(tx.signature);
                    }
                  }
                } catch (error) {
                  console.error(`Error checking local transaction ${tx.signature}:`, error);
                }
              }
            }
          }
        } catch (e) {
          console.error('Error recovering from localStorage:', e);
        }
        
        // 2. Fetch all transactions from the server for this wallet
        const response = await fetch(`/api/transactions/user/${wallet.publicKey.toString()}`);
        
        if (!response.ok) {
          throw new Error(`Failed to fetch transactions: ${response.status}`);
        }
        
        const serverTransactions = await response.json();
        
        // Define transaction interface for recovery
        interface RecoveryTransaction {
          id: number;
          status: string;
          transactionSignature?: string;
          walletAddress: string;
          amount: number;
          pongCredits: number;
          timestamp: string;
          processedAt?: string | null;
        }
        
        // Look for transactions that need recovery
        const recoveryNeededTransactions = serverTransactions.filter((tx: RecoveryTransaction) => {
          // These statuses indicate the transaction is in an incomplete state
          return (
            tx.transactionSignature && 
            ['pending', 'submitted', 'confirming', 'sol_confirmed', 'confirmed']
              .includes(tx.status.toLowerCase())
          );
        });
        
        console.log(`Found ${recoveryNeededTransactions.length} transactions that may need recovery`);
        
        // Process each transaction that needs recovery
        for (const tx of recoveryNeededTransactions) {
          if (!tx.transactionSignature) continue;
          
          console.log(`Checking server transaction ${tx.transactionSignature} (${tx.status}) for recovery`);
          
          try {
            // Check the blockchain status
            const status = await connection.getSignatureStatus(tx.transactionSignature);
            
            if (status && status.value) {
              if (status.value.err) {
                // Transaction failed on blockchain
                console.log(`Transaction ${tx.transactionSignature} failed on blockchain`);
                
                // Notify server of failure
                await fetch('/api/transactions/update', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    signature: tx.transactionSignature,
                    status: 'failed',
                    error: 'Transaction failed on blockchain'
                  })
                });
              } 
              else {
                // Transaction is on the blockchain
                const blockchainStatus = status.value.confirmationStatus as string || 'pending';
                
                // If confirmed or finalized, check if credits were issued
                if (blockchainStatus === 'confirmed' || blockchainStatus === 'finalized') {
                  if (tx.status !== 'completed' && tx.status !== 'credits_issued') {
                    console.log(`Transaction ${tx.transactionSignature} is confirmed but credits not issued, recovering...`);
                    
                    // First update server that SOL is confirmed if needed
                    if (tx.status === 'pending' || tx.status === 'submitted') {
                      await fetch('/api/transactions/confirm-sol', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ signature: tx.transactionSignature })
                      });
                    }
                    
                    // Then check if credits need to be issued
                    checkTransactionServerStatus(tx.transactionSignature);
                  }
                }
                else if (blockchainStatus === 'processed' && tx.status === 'pending') {
                  // Transaction is processed but not confirmed yet
                  console.log(`Transaction ${tx.transactionSignature} is processed but not confirmed`);
                  
                  // Update status to help user see progress
                  updateTransactionStatus(tx.transactionSignature, 'confirming');
                }
              }
            }
            else {
              // Transaction not found on blockchain
              console.log(`Transaction ${tx.transactionSignature} not found on blockchain, may be invalid`);
              
              // If it's been more than 2 hours, mark as failed
              const txTime = new Date(tx.timestamp).getTime();
              const twoHoursAgo = Date.now() - (2 * 60 * 60 * 1000);
              
              if (txTime < twoHoursAgo) {
                console.log(`Transaction ${tx.transactionSignature} is over 2 hours old, marking as failed`);
                
                await fetch('/api/transactions/update', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    signature: tx.transactionSignature,
                    status: 'failed',
                    error: 'Transaction not found on blockchain after 2 hours'
                  })
                });
              }
            }
          } catch (error) {
            console.error(`Error recovering transaction ${tx.transactionSignature}:`, error);
          }
        }
        
        console.log('Transaction recovery check completed');
      } catch (error) {
        console.error('Error in transaction recovery system:', error);
      }
    };
    
    // Run recovery system when wallet connects or app loads
    if (wallet.publicKey && connection) {
      recoverIncompleteTransactions();
    }
    
    // Also set up event listeners for potential manual recovery
    const handleWalletConnect = () => {
      if (wallet.publicKey && connection) {
        console.log('Wallet connected, running recovery check');
        recoverIncompleteTransactions();
      }
    };
    
    // Listen for wallet connect events from UI
    window.addEventListener('walletConnected', handleWalletConnect);
    
    return () => {
      window.removeEventListener('walletConnected', handleWalletConnect);
    };
  }, [wallet.publicKey, connection, checkTransactionServerStatus, updateTransactionStatus]);
  
  const contextValue: TransactionContextState = {
    pendingTransactions,
    completedTransactions,
    allTransactions: state.transactions,
    addPendingTransaction,
    updateTransactionStatus,
    cleanupTransactions,
    purchaseCredits,
    isProcessingPurchase: state.isProcessingPurchase
  };

  return (
    <TransactionContextInstance.Provider value={contextValue}>
      {children}
    </TransactionContextInstance.Provider>
  );
};

export default TransactionContextInstance;