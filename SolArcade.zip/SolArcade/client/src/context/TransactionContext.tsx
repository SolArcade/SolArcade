import React, { createContext, useState, useContext, useEffect } from 'react';
import { useConnection, useWallet } from '@solana/wallet-adapter-react';
import { createTransactionStore, setupTransactionListeners, Transaction } from '../lib/transactionStore';
import createPongCreditPurchaseService from '../lib/purchaseService';
import { PublicKey } from '@solana/web3.js';

// Context interface
interface TransactionContextState {
  pendingTransactions: Transaction[];
  addPendingTransaction: (transaction: Partial<Transaction>) => void;
  updateTransactionStatus: (id: string, status: Transaction['status'], metadata?: Record<string, any>) => void;
  cleanupTransactions: () => void;
  purchaseCredits: (solAmount: number) => Promise<{ signature: string }>;
  isProcessingPurchase: boolean;
}

// Create context with default values
const TransactionContextInstance = createContext<TransactionContextState>({
  pendingTransactions: [],
  addPendingTransaction: () => {},
  updateTransactionStatus: () => {},
  cleanupTransactions: () => {},
  purchaseCredits: async () => ({ signature: '' }),
  isProcessingPurchase: false,
});

// Custom hook to use the transaction context
export const useTransactionContext = () => useContext(TransactionContextInstance);

// Provider component
export const TransactionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { connection } = useConnection();
  const wallet = useWallet();
  const [pendingTransactions, setPendingTransactions] = useState<Transaction[]>([]);
  const [isProcessingPurchase, setIsProcessingPurchase] = useState(false);
  
  // Create transaction store
  const transactionStore = createTransactionStore(setPendingTransactions);
  
  // Create purchase service
  const purchaseService = createPongCreditPurchaseService(connection, '');
  
  // Load transactions from localStorage on mount
  useEffect(() => {
    const loadTransactions = () => {
      try {
        const stored = localStorage.getItem('pendingTransactions');
        if (stored) {
          const parsed = JSON.parse(stored);
          
          // If stored transactions are in the new format
          if (Array.isArray(parsed)) {
            // Make sure all loaded transactions have the correct status type
            const validTransactions = parsed.map((tx: any) => ({
              ...tx,
              // Ensure status is one of the valid enum values
              status: validateTransactionStatus(tx.status)
            }));
            setPendingTransactions(validTransactions as Transaction[]);
          }
          // If stored transactions are in the old format (object keyed by signature)
          else if (typeof parsed === 'object') {
            const transactions = Object.entries(parsed).map(([signature, tx]: [string, any]) => ({
              id: signature,
              signature,
              amount: tx.amount || 0,
              pongCredits: Math.floor((tx.amount || 0) * 100), // Convert SOL to credits
              status: 'pending' as const,
              timestamp: tx.timestamp || Date.now(),
              lastUpdated: tx.lastAttempt || tx.timestamp || Date.now()
            }));
            setPendingTransactions(transactions as Transaction[]);
          }
        }
      } catch (error) {
        console.error('Error loading transactions from localStorage:', error);
      }
    };
    
    // Helper to validate transaction status
    const validateTransactionStatus = (status: any): Transaction['status'] => {
      const validStatuses: Transaction['status'][] = ['pending', 'confirming', 'completed', 'failed', 'unknown'];
      if (typeof status === 'string' && validStatuses.includes(status as Transaction['status'])) {
        return status as Transaction['status'];
      }
      return 'unknown';
    };
    
    loadTransactions();
  }, []);
  
  // Save transactions to localStorage when they change
  useEffect(() => {
    try {
      localStorage.setItem('pendingTransactions', JSON.stringify(pendingTransactions));
    } catch (error) {
      console.error('Error saving transactions to localStorage:', error);
    }
  }, [pendingTransactions]);
  
  // Set up transaction listeners
  useEffect(() => {
    // Only start listeners if we have active transactions
    pendingTransactions
      .filter(tx => tx.status === 'pending' || tx.status === 'confirming')
      .forEach(tx => {
        if (tx.signature) {
          setupTransactionListeners(connection, tx.signature, {
            updateTransaction: (id: string, updates: Partial<Transaction>) => {
              setPendingTransactions(prev => 
                prev.map(t => 
                  t.signature === id ? { ...t, ...updates } : t
                )
              );
            }
          });
        }
      });
      
    // Cleanup old transactions every minute
    const cleanupInterval = setInterval(() => {
      const KEEP_COMPLETED_FOR_MS = 24 * 60 * 60 * 1000; // 24 hours
      
      setPendingTransactions(prev => 
        prev.filter(tx => {
          if (tx.status !== 'completed' && tx.status !== 'failed') return true;
          return (Date.now() - tx.lastUpdated) < KEEP_COMPLETED_FOR_MS;
        })
      );
    }, 60000);
    
    return () => {
      clearInterval(cleanupInterval);
    };
  }, [connection, pendingTransactions]);
  
  // Recover pending purchases on wallet connect
  useEffect(() => {
    if (wallet.connected && wallet.publicKey) {
      purchaseService.recoverPendingPurchases();
    }
  }, [wallet.connected, wallet.publicKey, purchaseService]);
  
  // Function to purchase credits
  const purchaseCredits = async (solAmount: number) => {
    if (!wallet.connected || !wallet.publicKey) {
      throw new Error("Wallet not connected");
    }
    
    setIsProcessingPurchase(true);
    
    try {
      // Type-safe interface for wallet with required fields
      const walletAdapter = {
        publicKey: wallet.publicKey as PublicKey,
        sendTransaction: wallet.sendTransaction.bind(wallet)
      };
      
      const result = await purchaseService.purchasePongCredits(walletAdapter, solAmount);
      
      // Add to pending transactions
      const newTransaction: Transaction = {
        id: result.signature,
        signature: result.signature,
        amount: solAmount,
        pongCredits: solAmount * 100, // Convert SOL to credits
        status: 'pending',
        timestamp: Date.now(),
        lastUpdated: Date.now()
      };
      
      setPendingTransactions(prev => [newTransaction, ...prev]);
      
      return { signature: result.signature };
    } catch (error) {
      console.error('Error purchasing credits:', error);
      throw error;
    } finally {
      setIsProcessingPurchase(false);
    }
  };
  
  // Context value
  const value: TransactionContextState = {
    pendingTransactions,
    addPendingTransaction: (transaction) => {
      setPendingTransactions(prev => [
        {
          ...transaction,
          id: transaction.id || transaction.signature || `tx-${Date.now()}`,
          amount: transaction.amount || 0,
          pongCredits: transaction.pongCredits || 0,
          status: transaction.status || 'pending',
          timestamp: transaction.timestamp || Date.now(),
          lastUpdated: Date.now()
        } as Transaction,
        ...prev
      ]);
    },
    updateTransactionStatus: (id, status, metadata = {}) => {
      setPendingTransactions(prev => 
        prev.map(tx => 
          tx.id === id || tx.signature === id ? 
            { ...tx, status, lastUpdated: Date.now(), ...metadata } : 
            tx
        )
      );
    },
    cleanupTransactions: () => {
      const KEEP_COMPLETED_FOR_MS = 24 * 60 * 60 * 1000; // 24 hours
      
      setPendingTransactions(prev => 
        prev.filter(tx => {
          if (tx.status !== 'completed' && tx.status !== 'failed') return true;
          return (Date.now() - tx.lastUpdated) < KEEP_COMPLETED_FOR_MS;
        })
      );
    },
    purchaseCredits,
    isProcessingPurchase
  };
  
  return (
    <TransactionContextInstance.Provider value={value}>
      {children}
    </TransactionContextInstance.Provider>
  );
};

export default TransactionContextInstance;