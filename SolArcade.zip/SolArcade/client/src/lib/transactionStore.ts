import { nanoid } from 'nanoid';

export interface Transaction {
  id: string;
  signature?: string;
  amount: number;
  pongCredits: number;
  status: 'pending' | 'confirming' | 'completed' | 'failed' | 'unknown';
  timestamp: number;
  lastUpdated: number;
  confirmations?: number;
  error?: string;
}

// Generate unique IDs for transactions
export const generateUniqueId = () => nanoid(10);

// Create a transaction store with state management
export const createTransactionStore = (setState: (fn: (prev: Transaction[]) => Transaction[]) => void) => ({
  // Add a new transaction to the store
  addTransaction: (transaction: Partial<Transaction>) => {
    setState(prev => [
      {
        id: transaction.id || transaction.signature || generateUniqueId(),
        signature: transaction.signature,
        amount: transaction.amount || 0,
        pongCredits: transaction.pongCredits || 0,
        status: transaction.status || 'pending',
        timestamp: transaction.timestamp || Date.now(),
        lastUpdated: Date.now(),
        confirmations: transaction.confirmations || 0,
        error: transaction.error
      } as Transaction,
      ...prev
    ]);
  },

  // Update an existing transaction
  updateTransaction: (id: string, updates: Partial<Transaction>) => {
    setState(prev => 
      prev.map(tx => 
        tx.id === id || tx.signature === id ? 
          { ...tx, ...updates, lastUpdated: Date.now() } : 
          tx
      )
    );
  },

  // Get all transactions
  getTransactions: () => {
    try {
      const stored = localStorage.getItem('pendingTransactions');
      if (stored) {
        return JSON.parse(stored) as Transaction[];
      }
    } catch (error) {
      console.error('Error loading transactions from localStorage:', error);
    }
    return [];
  },

  // Remove a transaction
  removeTransaction: (id: string) => {
    setState(prev => prev.filter(tx => tx.id !== id && tx.signature !== id));
  },

  // Clear completed/failed transactions older than specified time
  cleanupTransactions: (keepCompletedForMs = 24 * 60 * 60 * 1000) => {
    setState(prev => 
      prev.filter(tx => {
        if (tx.status !== 'completed' && tx.status !== 'failed') return true;
        return (Date.now() - tx.lastUpdated) < keepCompletedForMs;
      })
    );
  }
});

// Setup transaction listeners for Solana transactions
export const setupTransactionListeners = (
  connection: any, 
  txId: string, 
  txStore: { updateTransaction: (id: string, updates: Partial<Transaction>) => void }
) => {
  if (!txId) return () => {};
  
  let subscription: number | null = null;
  
  try {
    // Subscribe to transaction confirmations
    subscription = connection.onSignatureChange(
      txId,
      (signatureResult: any, context: any) => {
        console.log(`Transaction ${txId} status update:`, signatureResult);
        
        if (signatureResult.err) {
          txStore.updateTransaction(txId, {
            status: 'failed',
            error: JSON.stringify(signatureResult.err)
          });
          return;
        }
        
        // Transaction confirmed successfully
        if (context.slot) {
          const confirmations = context.confirmations || 0;
          
          if (confirmations >= 1) {
            txStore.updateTransaction(txId, {
              status: 'completed',
              confirmations
            });
          } else {
            txStore.updateTransaction(txId, {
              status: 'confirming',
              confirmations
            });
          }
        }
      },
      'confirmed'
    );
    
    // Also check the transaction status immediately
    connection.getSignatureStatus(txId)
      .then((result: any) => {
        if (!result || !result.value) return;
        
        const status = result.value;
        
        if (status?.err) {
          txStore.updateTransaction(txId, {
            status: 'failed',
            error: JSON.stringify(status.err)
          });
        } else if (status?.confirmations) {
          const confirmations = status.confirmations;
          
          if (confirmations >= 1) {
            txStore.updateTransaction(txId, {
              status: 'completed',
              confirmations
            });
          } else {
            txStore.updateTransaction(txId, {
              status: 'confirming',
              confirmations
            });
          }
        }
      })
      .catch((error: any) => {
        console.error(`Error checking transaction ${txId}:`, error);
      });
    
  } catch (error) {
    console.error(`Error setting up listener for ${txId}:`, error);
  }
  
  // Return cleanup function
  return () => {
    if (subscription !== null) {
      connection.removeSignatureListener(subscription);
    }
  };
};

// Transaction context utilities and constants
export const TransactionContext = {
  // SOL to Pong Credit conversion rate
  CREDIT_RATE: 100, // 1 SOL = 100 credits
  
  // Calculate pong credits from SOL amount
  calculateCredits: (solAmount: number) => Math.floor(solAmount * 100),
  
  // Format SOL amount with appropriate precision
  formatSolAmount: (amount: number) => amount.toFixed(amount < 0.01 ? 8 : 4),
  
  // Format relative time for transactions
  formatRelativeTime: (timestamp: number) => {
    const seconds = Math.floor((Date.now() - timestamp) / 1000);
    
    if (seconds < 60) return `${seconds}s ago`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
  }
};