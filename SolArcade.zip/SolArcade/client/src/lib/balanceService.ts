import { WalletContextState } from '@solana/wallet-adapter-react';

// Cache configuration
const CACHE_EXPIRY_MS = 10000; // 10 seconds cache expiry

interface BalanceService {
  fetchBalance: (wallet: WalletContextState, forceRefresh?: boolean) => Promise<number>;
  refreshBalance: (wallet: WalletContextState) => Promise<number>;
  updateCachedBalance: (newBalance: number) => void;
}

// Balance cache storage
interface BalanceCache {
  balance: number | null;
  timestamp: number;
  walletAddress: string | null;
}

// Create a balance service that handles fetching and caching the user's balance
export const createBalanceService = (): BalanceService => {
  const balanceCache: BalanceCache = {
    balance: null,
    timestamp: 0,
    walletAddress: null
  };
  
  const service = {
    // Fetch balance with optional force refresh
    fetchBalance: async (wallet: WalletContextState, forceRefresh = false): Promise<number> => {
      if (!wallet.publicKey) {
        return 0;
      }
      
      const walletAddress = wallet.publicKey.toString();
      
      // If we have a cached balance that's still valid and for the same wallet
      if (
        !forceRefresh && 
        balanceCache.balance !== null && 
        balanceCache.walletAddress === walletAddress &&
        Date.now() - balanceCache.timestamp < CACHE_EXPIRY_MS
      ) {
        console.log("Using cached balance:", balanceCache.balance);
        return balanceCache.balance;
      }
      
      try {
        // Fetch from API
        console.log("Fetching balance from server for wallet:", walletAddress);
        const response = await fetch(`/api/user/${walletAddress}`);
        
        if (!response.ok) {
          throw new Error(`Error fetching user balance: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data && typeof data.pongCredits === 'number') {
          // Update cache
          balanceCache.balance = data.pongCredits;
          balanceCache.timestamp = Date.now();
          balanceCache.walletAddress = walletAddress;
          
          console.log("Balance fetched successfully:", data.pongCredits);
          return data.pongCredits;
        } else {
          console.warn("Invalid balance data received:", data);
          return 0;
        }
      } catch (error) {
        console.error("Error fetching balance:", error);
        return 0;
      }
    },
    
    // Force refresh balance from server
    refreshBalance: async (wallet: WalletContextState): Promise<number> => {
      return await service.fetchBalance(wallet, true);
    },
    
    // Manually update the cached balance (used when we know the balance has changed)
    updateCachedBalance: (newBalance: number): void => {
      balanceCache.balance = newBalance;
      balanceCache.timestamp = Date.now();
      console.log("Cached balance updated manually:", newBalance);
    }
  };
  
  return service;
};

// Set up triggers that should refresh the balance
export const setupBalanceRefreshTriggers = (wallet: WalletContextState, balanceService: BalanceService) => {
  if (!wallet.publicKey) return () => {};
  
  // We'll listen for the standard transaction completion event
  const handleTransactionComplete = (event: Event) => {
    const customEvent = event as CustomEvent;
    if (customEvent.detail && 
        customEvent.detail.walletAddress && 
        wallet.publicKey && 
        customEvent.detail.walletAddress === wallet.publicKey.toString()) {
      console.log("Transaction completed, refreshing balance");
      balanceService.fetchBalance(wallet, true);
    }
  };
  
  // Also react to wallet changes
  const handleWalletChange = () => {
    if (wallet.publicKey) {
      console.log("Wallet changed, refreshing balance");
      balanceService.fetchBalance(wallet, true);
    }
  };
  
  // Set up event listeners
  window.addEventListener('transactionComplete', handleTransactionComplete);
  window.addEventListener('walletChanged', handleWalletChange);
  
  // Return a cleanup function
  return () => {
    window.removeEventListener('transactionComplete', handleTransactionComplete);
    window.removeEventListener('walletChanged', handleWalletChange);
  };
};