// Sound effects for the Pong game

class SoundManager {
  private sounds: Map<string, AudioBuffer>;
  private audioContext: AudioContext | null;
  private soundsLoaded: boolean;
  private isMuted: boolean;

  constructor() {
    this.sounds = new Map();
    this.audioContext = null;
    this.soundsLoaded = false;
    this.isMuted = false;
  }

  public init(): void {
    if (typeof window === 'undefined') return;
    
    try {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      this.loadSounds();
    } catch (e) {
      console.error('Web Audio API not supported in this browser', e);
    }
  }

  private async loadSounds(): Promise<void> {
    if (!this.audioContext) return;

    const soundsList = {
      'paddle': this.generatePaddleHitSound,
      'wall': this.generateWallHitSound,
      'score': this.generateScoreSound,
      'countdown': this.generateCountdownSound,
      'gameStart': this.generateGameStartSound,
      'gameOver': this.generateGameOverSound
    };

    try {
      for (const [name, generator] of Object.entries(soundsList)) {
        const buffer = await generator.call(this, this.audioContext);
        this.sounds.set(name, buffer);
      }
      this.soundsLoaded = true;
    } catch (error) {
      console.error('Failed to load sounds:', error);
    }
  }

  public play(name: string): void {
    if (!this.audioContext || !this.soundsLoaded || this.isMuted) return;

    const soundBuffer = this.sounds.get(name);
    if (!soundBuffer) return;

    const source = this.audioContext.createBufferSource();
    source.buffer = soundBuffer;
    source.connect(this.audioContext.destination);
    source.start(0);
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    return this.isMuted;
  }

  public isMutedState(): boolean {
    return this.isMuted;
  }

  // Sound generators
  private async generatePaddleHitSound(ctx: AudioContext): Promise<AudioBuffer> {
    const duration = 0.1;
    const sampleRate = ctx.sampleRate;
    const buffer = ctx.createBuffer(1, sampleRate * duration, sampleRate);
    const data = buffer.getChannelData(0);
    
    for (let i = 0; i < buffer.length; i++) {
      // Retro paddle hit sound
      const t = i / sampleRate;
      data[i] = 0.5 * Math.sin(2 * Math.PI * 800 * t) * Math.exp(-10 * t);
    }
    
    return buffer;
  }

  private async generateWallHitSound(ctx: AudioContext): Promise<AudioBuffer> {
    const duration = 0.1;
    const sampleRate = ctx.sampleRate;
    const buffer = ctx.createBuffer(1, sampleRate * duration, sampleRate);
    const data = buffer.getChannelData(0);
    
    for (let i = 0; i < buffer.length; i++) {
      // Retro wall hit sound (higher pitch)
      const t = i / sampleRate;
      data[i] = 0.3 * Math.sin(2 * Math.PI * 1200 * t) * Math.exp(-12 * t);
    }
    
    return buffer;
  }

  private async generateScoreSound(ctx: AudioContext): Promise<AudioBuffer> {
    const duration = 0.6;
    const sampleRate = ctx.sampleRate;
    const buffer = ctx.createBuffer(1, sampleRate * duration, sampleRate);
    const data = buffer.getChannelData(0);
    
    for (let i = 0; i < buffer.length; i++) {
      // Score sound - descending notes
      const t = i / sampleRate;
      const note1 = Math.sin(2 * Math.PI * 660 * t) * Math.exp(-3 * t);
      const note2 = Math.sin(2 * Math.PI * 440 * t) * Math.exp(-3 * (t - 0.2)) * (t > 0.2 ? 1 : 0);
      const note3 = Math.sin(2 * Math.PI * 220 * t) * Math.exp(-3 * (t - 0.4)) * (t > 0.4 ? 1 : 0);
      data[i] = 0.3 * (note1 + note2 + note3);
    }
    
    return buffer;
  }

  private async generateCountdownSound(ctx: AudioContext): Promise<AudioBuffer> {
    const duration = 0.1;
    const sampleRate = ctx.sampleRate;
    const buffer = ctx.createBuffer(1, sampleRate * duration, sampleRate);
    const data = buffer.getChannelData(0);
    
    for (let i = 0; i < buffer.length; i++) {
      // Simple beep
      const t = i / sampleRate;
      data[i] = 0.5 * Math.sin(2 * Math.PI * 440 * t) * Math.exp(-5 * t);
    }
    
    return buffer;
  }

  private async generateGameStartSound(ctx: AudioContext): Promise<AudioBuffer> {
    const duration = 1.0;
    const sampleRate = ctx.sampleRate;
    const buffer = ctx.createBuffer(1, sampleRate * duration, sampleRate);
    const data = buffer.getChannelData(0);
    
    for (let i = 0; i < buffer.length; i++) {
      // Ascending arpeggio
      const t = i / sampleRate;
      const note1 = Math.sin(2 * Math.PI * 220 * t) * Math.exp(-2 * t);
      const note2 = Math.sin(2 * Math.PI * 330 * t) * Math.exp(-2 * (t - 0.2)) * (t > 0.2 ? 1 : 0);
      const note3 = Math.sin(2 * Math.PI * 440 * t) * Math.exp(-2 * (t - 0.4)) * (t > 0.4 ? 1 : 0);
      const note4 = Math.sin(2 * Math.PI * 660 * t) * Math.exp(-2 * (t - 0.6)) * (t > 0.6 ? 1 : 0);
      data[i] = 0.2 * (note1 + note2 + note3 + note4);
    }
    
    return buffer;
  }

  private async generateGameOverSound(ctx: AudioContext): Promise<AudioBuffer> {
    const duration = 1.5;
    const sampleRate = ctx.sampleRate;
    const buffer = ctx.createBuffer(1, sampleRate * duration, sampleRate);
    const data = buffer.getChannelData(0);
    
    for (let i = 0; i < buffer.length; i++) {
      // Game over sound - descending pattern
      const t = i / sampleRate;
      const freq = 320 - 100 * t;
      data[i] = 0.3 * Math.sin(2 * Math.PI * freq * t) * Math.exp(-1.5 * t);
    }
    
    return buffer;
  }
}

// Export a singleton instance
export const soundManager = new SoundManager();