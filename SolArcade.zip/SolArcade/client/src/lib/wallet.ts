import {
  Connection,
  PublicKey,
  SystemProgram,
  Transaction,
  LAMPORTS_PER_SOL,
  ComputeBudgetProgram
} from "@solana/web3.js";

// Define SendTransactionOptions interface
interface SendTransactionOptions {
  skipPreflight?: boolean;
  preflightCommitment?: string;
  maxRetries?: number;
}

// Send a transaction with priority fees for faster confirmation
export async function sendTransaction(
  connection: Connection,
  sendTransaction: (
    transaction: Transaction,
    connection: Connection,
    options?: SendTransactionOptions
  ) => Promise<string>,
  from: PublicKey,
  amount: number
) {
  const toWallet = new PublicKey("45GGPAkoxwisBWj5YtHj1BH1tekmoFbRigSNJ4fT9UD2");

  // Get recent blockhash for the transaction
  const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash("confirmed");

  // Create a new transaction with that blockhash
  const transaction = new Transaction({
    feePayer: from,
    blockhash,
    lastValidBlockHeight
  });

  // Add compute budget instruction to set priority fee
  // This helps ensure faster transaction confirmation
  try {
    // Query for an optimal priority fee from the server
    const priorityFeeResponse = await fetch('/api/priority-fee');
    
    if (priorityFeeResponse.ok) {
      const { priorityFee } = await priorityFeeResponse.json();
      console.log(`Using server-recommended priority fee: ${priorityFee} lamports`);
      
      transaction.add(
        ComputeBudgetProgram.setComputeUnitPrice({
          microLamports: priorityFee
        })
      );
    } else {
      // Use a default priority fee if server request fails
      console.log("Using default priority fee: 10000 microLamports");
      transaction.add(
        ComputeBudgetProgram.setComputeUnitPrice({
          microLamports: 10000
        })
      );
    }
  } catch (error) {
    console.error("Error setting priority fee, continuing with default:", error);
    // Use a default priority fee if server request fails
    transaction.add(
      ComputeBudgetProgram.setComputeUnitPrice({
        microLamports: 10000
      })
    );
  }

  // Add the transfer instruction
  transaction.add(
    SystemProgram.transfer({
      fromPubkey: from,
      toPubkey: toWallet,
      lamports: amount * LAMPORTS_PER_SOL,
    })
  );

  console.log(`Sending ${amount} SOL to ${toWallet.toString()} with priority fee`);

  // Send the transaction
  const signature = await sendTransaction(transaction, connection, {
    skipPreflight: false,
    preflightCommitment: "confirmed",
  });

  console.log(`Transaction sent with signature: ${signature}`);
  
  // Wait for confirmation
  console.log(`Waiting for transaction confirmation...`);
  await connection.confirmTransaction({
    signature,
    blockhash,
    lastValidBlockHeight
  }, "confirmed");
  
  console.log(`Transaction confirmed: ${signature}`);
  return signature;
}

// Send winnings to the winner with priority fees
export async function sendWinnings(
  connection: Connection,
  sendTransaction: (
    transaction: Transaction,
    connection: Connection,
    options?: SendTransactionOptions
  ) => Promise<string>,
  houseWallet: PublicKey,
  winnerWallet: PublicKey,
  amount: number
) {
  // Get recent blockhash for the transaction
  const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash("confirmed");

  // Create a new transaction with that blockhash
  const transaction = new Transaction({
    feePayer: houseWallet,
    blockhash,
    lastValidBlockHeight
  });

  // Add compute budget instruction to set priority fee
  try {
    // Query for an optimal priority fee from the server
    const priorityFeeResponse = await fetch('/api/priority-fee');
    
    if (priorityFeeResponse.ok) {
      const { priorityFee } = await priorityFeeResponse.json();
      console.log(`Using server-recommended priority fee for winnings: ${priorityFee} lamports`);
      
      transaction.add(
        ComputeBudgetProgram.setComputeUnitPrice({
          microLamports: priorityFee
        })
      );
    } else {
      // Use a default priority fee if server request fails
      transaction.add(
        ComputeBudgetProgram.setComputeUnitPrice({
          microLamports: 10000
        })
      );
    }
  } catch (error) {
    console.error("Error setting priority fee for winnings, continuing with default:", error);
    // Use a default priority fee if server request fails
    transaction.add(
      ComputeBudgetProgram.setComputeUnitPrice({
        microLamports: 10000
      })
    );
  }

  // Add the transfer instruction
  transaction.add(
    SystemProgram.transfer({
      fromPubkey: houseWallet,
      toPubkey: winnerWallet,
      lamports: amount * LAMPORTS_PER_SOL,
    })
  );
  
  console.log(`Sending ${amount} SOL winnings to ${winnerWallet.toString()} with priority fee`);
  
  // Send the transaction
  const signature = await sendTransaction(transaction, connection, {
    skipPreflight: false,
    preflightCommitment: "confirmed",
  });
  
  console.log(`Winnings transaction sent with signature: ${signature}`);
  
  // Wait for confirmation
  console.log(`Waiting for winnings transaction confirmation...`);
  await connection.confirmTransaction({
    signature,
    blockhash,
    lastValidBlockHeight
  }, "confirmed");
  
  console.log(`Winnings transaction confirmed: ${signature}`);
  return signature;
}