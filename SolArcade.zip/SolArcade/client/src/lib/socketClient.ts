import { io, Socket } from 'socket.io-client';
import { useEffect, useState } from 'react';

let socket: Socket | null = null;
const listeners = new Map<string, Set<Function>>();

// Create a persistent socket connection that doesn't disconnect on component unmounts
export function getSocket(): Socket {
  if (!socket) {
    // Connect to the server's Socket.IO endpoint
    // The URL is relative to the client, so it connects to the same host
    socket = io({
      transports: ['websocket'],
      autoConnect: true,
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000
    });

    // Set up global event listeners
    socket.on('connect', () => {
      console.log('Socket.IO connected, ID:', socket?.id);
    });

    socket.on('disconnect', (reason) => {
      console.log('Socket.IO disconnected:', reason);
    });

    socket.on('connect_error', (error) => {
      console.error('Socket.IO connection error:', error);
    });

    // Listen for transaction events even before components set up listeners
    socket.on('transaction:global', (data) => {
      console.log('Global transaction event received:', data);
      notifyListeners('transaction:global', data);
    });

    socket.on('transaction:complete', (data) => {
      console.log('Transaction complete event received:', data);
      notifyListeners('transaction:complete', data);
    });

    socket.on('credits:updated', (data) => {
      console.log('Credits updated event received:', data);
      notifyListeners('credits:updated', data);
      
      // Dispatch a browser event for other components to listen to
      const creditsEvent = new CustomEvent('creditsUpdated', { 
        detail: { 
          pongCredits: data.pongCredits,
          walletAddress: data.walletAddress,
          signature: data.signature
        } 
      });
      window.dispatchEvent(creditsEvent);
      
      // Also update the credits directly in the window object if it exists
      if (window.updatePongCreditsUI) {
        window.updatePongCreditsUI(data.pongCredits);
      }
    });
  }
  
  return socket;
}

// Function to add an event listener
export function addEventListener(event: string, callback: Function): void {
  if (!listeners.has(event)) {
    listeners.set(event, new Set());
  }
  listeners.get(event)?.add(callback);
}

// Function to remove an event listener
export function removeEventListener(event: string, callback: Function): void {
  const eventListeners = listeners.get(event);
  if (eventListeners) {
    eventListeners.delete(callback);
  }
}

// Function to notify all registered listeners for an event
function notifyListeners(event: string, data: any): void {
  const eventListeners = listeners.get(event);
  if (eventListeners) {
    eventListeners.forEach(callback => {
      try {
        callback(data);
      } catch (error) {
        console.error(`Error in listener for event ${event}:`, error);
      }
    });
  }
}

// Subscribe to a wallet address to receive updates
export function subscribeToWallet(walletAddress: string): void {
  const s = getSocket();
  console.log(`Subscribing to wallet: ${walletAddress}`);
  s.emit('subscribe:wallet', walletAddress);
}

// Subscribe to a transaction to receive updates
export function subscribeToTransaction(signature: string): void {
  const s = getSocket();
  console.log(`Subscribing to transaction: ${signature}`);
  s.emit('subscribe:transaction', signature);
}

// React hook to use socket events in components
export function useSocketEvent(event: string, callback: (data: any) => void) {
  useEffect(() => {
    getSocket(); // Ensure socket is initialized
    addEventListener(event, callback);
    
    return () => {
      removeEventListener(event, callback);
    };
  }, [event, callback]);
}

// Hook for connection status
export function useSocketConnected() {
  const [isConnected, setIsConnected] = useState<boolean>(false);
  
  useEffect(() => {
    const s = getSocket();
    
    const handleConnect = () => setIsConnected(true);
    const handleDisconnect = () => setIsConnected(false);
    
    s.on('connect', handleConnect);
    s.on('disconnect', handleDisconnect);
    
    // Initial connection state
    setIsConnected(s.connected);
    
    return () => {
      s.off('connect', handleConnect);
      s.off('disconnect', handleDisconnect);
    };
  }, []);
  
  return isConnected;
}