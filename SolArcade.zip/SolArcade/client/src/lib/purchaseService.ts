import { Connection, PublicKey, Transaction, SystemProgram, sendAndConfirmTransaction } from '@solana/web3.js';
import { toast } from '../hooks/use-toast';
import { nanoid } from 'nanoid';

// Generate unique IDs for transactions before they have signatures
export const generateUniqueId = () => nanoid(10);

// Interface definitions for pending purchases
interface PendingPurchase {
  signature: string;
  amount: number;
  wallet: string;
  timestamp: number;
  attempts: number;
  lastAttempt: number | null;
}

// Interface for recovery items from local storage
interface RecoveryItem {
  signature: string;
  wallet: string;
  amount: number;
  timestamp: number;
}

// Create a transaction instruction for purchasing pong credits
const createPurchasePongCreditsInstruction = async (walletPublicKey: PublicKey, solAmount: number) => {
  // Target wallet is the house wallet/game treasury
  const targetWallet = new PublicKey("45GGPAkoxwisBWj5YtHj1BH1tekmoFbRigSNJ4fT9UD2");
  
  // Create a simple transfer instruction
  return SystemProgram.transfer({
    fromPubkey: walletPublicKey,
    toPubkey: targetWallet,
    lamports: solAmount * 1_000_000_000 // Convert SOL to lamports
  });
};

// Create the pong credit purchase service
export const createPongCreditPurchaseService = (connection: Connection, programId: string) => {
  // Store pending purchases in memory
  const pendingPurchases = new Map<string, PendingPurchase>();
  
  // Store in localStorage for recovery across sessions
  const storePendingPurchase = (signature: string, amount: number, wallet: PublicKey) => {
    try {
      // Get existing purchases
      const stored = localStorage.getItem('pendingPurchases');
      const pendingPurchases = stored ? JSON.parse(stored) : [];
      
      // Add new purchase
      pendingPurchases.push({
        signature,
        amount,
        wallet: wallet.toString(),
        timestamp: Date.now()
      });
      
      // Save back to localStorage
      localStorage.setItem('pendingPurchases', JSON.stringify(pendingPurchases));
      console.log(`Stored pending purchase: ${signature} for ${amount} SOL`);
    } catch (error) {
      console.error('Error storing pending purchase:', error);
    }
  };
  
  // Remove a purchase from localStorage after processing
  const removePendingPurchase = (signature: string) => {
    try {
      const stored = localStorage.getItem('pendingPurchases');
      if (!stored) return;
      
      const pendingPurchases = JSON.parse(stored);
      const filtered = pendingPurchases.filter((purchase: RecoveryItem) => purchase.signature !== signature);
      
      localStorage.setItem('pendingPurchases', JSON.stringify(filtered));
      console.log(`Removed pending purchase: ${signature}`);
    } catch (error) {
      console.error('Error removing pending purchase:', error);
    }
  };
  
  // Ask the server if the transaction was processed
  const checkTransactionProcessed = async (signature: string): Promise<boolean> => {
    try {
      const response = await fetch(`/api/verify-purchase?signature=${signature}`);
      if (!response.ok) {
        throw new Error(`Error checking purchase: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data.success && data.status === 'completed') {
        console.log(`Transaction ${signature} is already processed`);
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Error checking transaction status:', error);
      return false;
    }
  };
  
  // Submit a pre-transaction to reserve pong credits
  const createPreSubmission = async (walletAddress: string, amount: number): Promise<string> => {
    try {
      const response = await fetch('/api/pre-submit-transaction', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          walletAddress,
          amount,
          expectedCredits: Math.floor(amount * 100) // 1 SOL = 100 credits
        })
      });
      
      if (!response.ok) {
        throw new Error(`Error pre-submitting transaction: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data.id) {
        console.log(`Created pre-submission ID: ${data.id}`);
        return data.id;
      }
      
      throw new Error('No pre-submission ID returned');
    } catch (error) {
      console.error('Error creating pre-submission:', error);
      throw error;
    }
  };
  
  // Notify the server about a successful transaction
  const notifyPurchaseComplete = async (signature: string, amount: number, preSubmissionId?: string) => {
    try {
      const response = await fetch('/api/complete-purchase', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          signature,
          amount,
          preSubmissionId
        })
      });
      
      if (!response.ok) {
        throw new Error(`Error notifying purchase complete: ${response.status}`);
      }
      
      const data = await response.json();
      console.log('Purchase notification response:', data);
      
      // Update UI with new balance if provided
      if (data.newBalance) {
        // Dispatch event for balance update
        const event = new CustomEvent('pongCreditsPurchased', {
          detail: {
            newBalance: data.newBalance,
            added: Math.floor(amount * 100),
            amount,
            signature
          }
        });
        window.dispatchEvent(event);
      }
      
      return data;
    } catch (error) {
      console.error('Error notifying purchase complete:', error);
      throw error;
    }
  };
  
  // Verify a transaction has been confirmed and processed for pong credits
  const verifyTransactionProcessed = async (signature: string, amount: number, preSubmissionId?: string): Promise<boolean> => {
    try {
      // Wait for 1 second to ensure transaction is indexed
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Use our API to verify the transaction
      const response = await fetch(`/api/verify-purchase?signature=${signature}&preSubmissionId=${preSubmissionId || ''}`);
      
      if (!response.ok) {
        console.error(`Error verifying purchase: ${response.status}`);
        return false;
      }
      
      const data = await response.json();
      
      if (data.success === true) {
        console.log(`Transaction ${signature} verified successfully:`, data);
        
        // If the transaction is pending, we need to wait
        if (data.status === 'pending') {
          return false;
        }
        
        // If the transaction is completed, we're done
        if (data.status === 'completed') {
          return true;
        }
        
        // If we have a signature but the credits weren't awarded yet, 
        // call the complete-purchase endpoint
        if (data.status === 'confirming' || !data.status) {
          await notifyPurchaseComplete(signature, amount, preSubmissionId);
          return true;
        }
      }
      
      return false;
    } catch (error) {
      console.error('Error verifying transaction:', error);
      return false;
    }
  };
  
  // Fetch user's pong credits from the blockchain (or our DB)
  const fetchUserPongCreditsFromBlockchain = async (publicKey: PublicKey): Promise<number> => {
    try {
      const response = await fetch(`/api/user/${publicKey.toString()}`);
      if (!response.ok) {
        throw new Error(`Error fetching user credits: ${response.status}`);
      }
      
      const data = await response.json();
      return data.pongCredits || 0;
    } catch (error) {
      console.error('Error fetching user pong credits:', error);
      return 0;
    }
  };
  
  return {
    // Main function to purchase pong credits
    purchasePongCredits: async (wallet: { publicKey: PublicKey, sendTransaction: Function }, solAmount: number) => {
      if (!wallet.publicKey) {
        throw new Error("Wallet not connected");
      }
      
      let preSubmissionId: string | undefined;
      
      try {
        // Step 1: Create a pre-submission record to reserve the credits
        preSubmissionId = await createPreSubmission(wallet.publicKey.toString(), solAmount);
        
        // Step 2: Create the transaction
        const transaction = new Transaction();
        
        // Step 3: Add the purchase instruction
        const purchaseIx = await createPurchasePongCreditsInstruction(wallet.publicKey, solAmount);
        transaction.add(purchaseIx);
        
        // Step 4: Set recent blockhash & fee payer
        transaction.recentBlockhash = (await connection.getLatestBlockhash()).blockhash;
        transaction.feePayer = wallet.publicKey;
        
        // Step 5: Send the transaction
        console.log(`Sending transaction for ${solAmount} SOL...`);
        const signature = await wallet.sendTransaction(transaction, connection);
        console.log(`Transaction sent! Signature: ${signature}`);
        
        // Step 6: Store pending purchase for recovery
        storePendingPurchase(signature, solAmount, wallet.publicKey);
        
        // Step 7: Show pending transaction in UI
        if (window.showPendingTransaction) {
          window.showPendingTransaction(
            signature, 
            solAmount,
            Math.floor(solAmount * 100) // 1 SOL = 100 credits
          );
        }
        
        // Step 8: Start transaction monitoring in the background
        setTimeout(async () => {
          try {
            // Check if transaction is confirmed and processed
            const isProcessed = await verifyTransactionProcessed(signature, solAmount, preSubmissionId);
            
            if (isProcessed) {
              console.log(`Transaction ${signature} is confirmed and processed`);
              // Clean up
              removePendingPurchase(signature);
              
              // Dispatch event
              const event = new CustomEvent('transactionComplete', {
                detail: {
                  signature,
                  amount: solAmount,
                  walletAddress: wallet.publicKey?.toString()
                }
              });
              window.dispatchEvent(event);
            } else {
              console.log(`Transaction ${signature} is not fully processed yet, will check again later`);
              // Schedule another verification
              setTimeout(async () => {
                const isProcessedRetry = await verifyTransactionProcessed(signature, solAmount, preSubmissionId);
                
                if (isProcessedRetry) {
                  console.log(`Transaction ${signature} is confirmed and processed on retry`);
                  removePendingPurchase(signature);
                } else {
                  console.warn(`Transaction ${signature} still not fully processed after retry`);
                }
              }, 5000); // Check again in 5 seconds
            }
          } catch (error) {
            console.error(`Error monitoring transaction ${signature}:`, error);
          }
        }, 3000); // Start monitoring after 3 seconds
        
        // Return the transaction signature
        return { signature };
      } catch (error: any) {
        // If we have a pre-submission, notify the server about the failure
        if (preSubmissionId) {
          try {
            await fetch('/api/cancel-pre-submission', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                preSubmissionId,
                reason: error.message || 'Transaction failed'
              })
            });
          } catch (cancelError) {
            console.error('Error canceling pre-submission:', cancelError);
          }
        }
        
        console.error('Error purchasing pong credits:', error);
        toast({
          title: "Transaction Failed",
          description: error.message || "Could not complete the purchase. Please try again.",
          variant: "destructive",
        });
        throw error;
      }
    },
    
    // Recover any pending purchases from previous sessions
    recoverPendingPurchases: async () => {
      try {
        const stored = localStorage.getItem('pendingPurchases');
        if (!stored) return;
        
        const pendingPurchases = JSON.parse(stored) as RecoveryItem[];
        console.log(`Found ${pendingPurchases.length} pending purchases to recover`);
        
        if (pendingPurchases.length === 0) return;
        
        // Process each pending purchase
        for (const purchase of pendingPurchases) {
          // Skip purchases older than 24 hours
          if (Date.now() - purchase.timestamp > 24 * 60 * 60 * 1000) {
            removePendingPurchase(purchase.signature);
            continue;
          }
          
          // Check if transaction is already processed
          const isProcessed = await checkTransactionProcessed(purchase.signature);
          
          if (isProcessed) {
            removePendingPurchase(purchase.signature);
            continue;
          }
          
          // Show in UI
          if (window.showPendingTransaction) {
            window.showPendingTransaction(
              purchase.signature,
              purchase.amount,
              Math.floor(purchase.amount * 100)
            );
          }
          
          // Verify transaction status
          verifyTransactionProcessed(purchase.signature, purchase.amount)
            .then(isProcessed => {
              if (isProcessed) {
                removePendingPurchase(purchase.signature);
              }
            })
            .catch(error => {
              console.error(`Error verifying recovered transaction ${purchase.signature}:`, error);
            });
        }
      } catch (error) {
        console.error('Error recovering pending purchases:', error);
      }
    }
  };
};

export default createPongCreditPurchaseService;