import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import {
  ConnectionProvider,
  WalletProvider,
  useConnection,
  useWallet,
} from "@solana/wallet-adapter-react";
import { WalletModalProvider } from "@solana/wallet-adapter-react-ui";
import { PhantomWalletAdapter, SolflareWalletAdapter } from "@solana/wallet-adapter-wallets";
import { WalletAdapterNetwork } from "@solana/wallet-adapter-base";
import { useMemo, useState, useEffect, createContext, useContext } from "react";
import '@solana/wallet-adapter-react-ui/styles.css';
import TransactionPersistence from '../../TransactionPersistence';
// @ts-ignore - Import TransactionManager
import TransactionManager from '../../TransactionManager';
import { db } from './lib/firebase.ts';
import { TransactionProvider } from './context/TransactionContext';

// Extend Window interface to include our global functions
declare global {
  interface Window {
    transactionManager: any;
    updatePongCreditsUI: (newAmount: number) => void;
    showPendingTransaction: (signature: string, amount: number, pongCredits: number) => void;
  }
}

// Create context for transaction persistence
export const TransactionPersistenceContext = createContext<{
  txPersistence: TransactionPersistence | null;
  transactionManager: any | null;
  credits: number;
}>({
  txPersistence: null,
  transactionManager: null,
  credits: 0
});

// Custom hook to use the transaction persistence context
export function useTransactionPersistence() {
  return useContext(TransactionPersistenceContext);
}

function TransactionPersistenceProvider({ children }: { children: React.ReactNode }) {
  const { connection } = useConnection();
  const wallet = useWallet();
  const [txPersistence, setTxPersistence] = useState<TransactionPersistence | null>(null);
  const [transactionManager, setTransactionManager] = useState(null);
  const [credits, setCredits] = useState<number>(0);
  
  // Initialize the transaction persistence system when wallet connects
  useEffect(() => {
    if (wallet.connected && connection && wallet.publicKey) {
      console.log("Initializing TransactionPersistence system");
      const persistence = new TransactionPersistence(connection, wallet, db);
      setTxPersistence(persistence);
      
      // Set up listener for credits updates
      const handleCreditsUpdate = (event: CustomEvent) => {
        if (event.detail && typeof event.detail.credits === 'number') {
          setCredits(event.detail.credits);
        }
      };
      
      window.addEventListener('pongCreditsUpdated', handleCreditsUpdate as EventListener);
      
      return () => {
        window.removeEventListener('pongCreditsUpdated', handleCreditsUpdate as EventListener);
      };
    } else {
      setTxPersistence(null);
    }
  }, [connection, wallet.connected, wallet.publicKey]);
  
  // Initialize the new Transaction Manager system when wallet connects
  useEffect(() => {
    // Only initialize when all dependencies are available
    if (wallet && connection && db && wallet.publicKey) {
      console.log("Initializing transaction manager...");
      try {
        // Create the transaction manager
        const manager = new TransactionManager(connection, wallet, db);
        
        // Make globally available
        window.transactionManager = manager;
        
        // Store in state
        setTransactionManager(manager);
        
        console.log("Transaction manager initialized successfully");
        
        // Cleanup function
        return () => {
          if (manager && manager.cleanup) {
            manager.cleanup();
          }
        };
      } catch (error) {
        console.error("Error initializing transaction manager:", error);
      }
    }
  }, [wallet, connection, db, wallet?.publicKey?.toString()]);

  return (
    <TransactionPersistenceContext.Provider value={{ txPersistence, transactionManager, credits }}>
      {children}
    </TransactionPersistenceContext.Provider>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const endpoint = useMemo(() => import.meta.env.VITE_QUICKNODE_RPC_URL, []);
  const network = WalletAdapterNetwork.Mainnet;

  const wallets = useMemo(() => {
    return [
      new PhantomWalletAdapter(),
      new SolflareWalletAdapter({ network }),
    ];
  }, [network]);
  
  // Add UI Update Handlers
  useEffect(() => {
    // Global function to update pong credits display
    window.updatePongCreditsUI = (newAmount: number): void => {
      console.log(`Updating pong credits UI: ${newAmount}`);
      
      // Dispatch a custom event to update UI components
      const event = new CustomEvent('pongCreditsUpdated', {
        detail: { 
          credits: newAmount,
          added: 0, // We don't know how many were added in this case
          signature: null
        }
      });
      window.dispatchEvent(event);
    };
    
    // Function to show pending transaction in UI
    window.showPendingTransaction = (signature: string, amount: number, pongCredits: number): void => {
      console.log(`Showing pending transaction: ${signature}, amount: ${amount}, credits: ${pongCredits}`);
      
      // Dispatch an event that can be picked up by the TransactionContext
      const event = new CustomEvent('pendingTransaction', {
        detail: {
          signature,
          amount,
          pongCredits,
          timestamp: Date.now()
        }
      });
      window.dispatchEvent(event);
    };
    
    // Listen for pong credits updated event
    const handleCreditsUpdated = (event: CustomEvent): void => {
      if (!event.detail) return;
      
      const { credits, added, signature } = event.detail;
      
      // Show notification if desired
      console.log(`Pong credits updated: ${credits} ${added ? `(+${added})` : ''}`);
    };
    
    // Register event listener
    window.addEventListener('pongCreditsUpdated', handleCreditsUpdated as EventListener);
    
    // Cleanup
    return () => {
      window.removeEventListener('pongCreditsUpdated', handleCreditsUpdated as EventListener);
    };
  }, []);

  if (!endpoint) {
    return <div className="p-4 text-red-500">Error: Solana RPC endpoint not configured</div>;
  }

  return (
    <ConnectionProvider endpoint={endpoint}>
      <WalletProvider wallets={wallets} autoConnect={false}>
        <WalletModalProvider>
          <TransactionPersistenceProvider>
            <TransactionProvider>
              <QueryClientProvider client={queryClient}>
                <Router />
                <Toaster />
              </QueryClientProvider>
            </TransactionProvider>
          </TransactionPersistenceProvider>
        </WalletModalProvider>
      </WalletProvider>
    </ConnectionProvider>
  );
}

export default App;