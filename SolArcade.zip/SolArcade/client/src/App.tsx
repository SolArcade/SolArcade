import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import {
  ConnectionProvider,
  WalletProvider,
  useConnection,
  useWallet,
} from "@solana/wallet-adapter-react";
import { WalletModalProvider } from "@solana/wallet-adapter-react-ui";
import { PhantomWalletAdapter, SolflareWalletAdapter } from "@solana/wallet-adapter-wallets";
import { WalletAdapterNetwork } from "@solana/wallet-adapter-base";
import { useMemo, useState, useEffect, createContext, useContext } from "react";
import '@solana/wallet-adapter-react-ui/styles.css';
import TransactionPersistence from '../../TransactionPersistence';
import { db } from './lib/firebase.ts';

// Create context for transaction persistence
export const TransactionPersistenceContext = createContext<{
  txPersistence: TransactionPersistence | null;
  credits: number;
}>({
  txPersistence: null,
  credits: 0
});

// Custom hook to use the transaction persistence context
export function useTransactionPersistence() {
  return useContext(TransactionPersistenceContext);
}

function TransactionPersistenceProvider({ children }: { children: React.ReactNode }) {
  const { connection } = useConnection();
  const wallet = useWallet();
  const [txPersistence, setTxPersistence] = useState<TransactionPersistence | null>(null);
  const [credits, setCredits] = useState<number>(0);
  
  // Initialize the transaction persistence system when wallet connects
  useEffect(() => {
    if (wallet.connected && connection && wallet.publicKey) {
      console.log("Initializing TransactionPersistence system");
      const persistence = new TransactionPersistence(connection, wallet, db);
      setTxPersistence(persistence);
      
      // Set up listener for credits updates
      const handleCreditsUpdate = (event: CustomEvent) => {
        setCredits(event.detail.credits);
      };
      
      window.addEventListener('pongCreditsUpdated', handleCreditsUpdate as EventListener);
      
      return () => {
        window.removeEventListener('pongCreditsUpdated', handleCreditsUpdate as EventListener);
      };
    } else {
      setTxPersistence(null);
    }
  }, [connection, wallet.connected, wallet.publicKey]);

  return (
    <TransactionPersistenceContext.Provider value={{ txPersistence, credits }}>
      {children}
    </TransactionPersistenceContext.Provider>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const endpoint = useMemo(() => import.meta.env.VITE_QUICKNODE_RPC_URL, []);
  const network = WalletAdapterNetwork.Mainnet;

  const wallets = useMemo(() => {
    return [
      new PhantomWalletAdapter(),
      new SolflareWalletAdapter({ network }),
    ];
  }, [network]);

  if (!endpoint) {
    return <div className="p-4 text-red-500">Error: Solana RPC endpoint not configured</div>;
  }

  return (
    <ConnectionProvider endpoint={endpoint}>
      <WalletProvider wallets={wallets} autoConnect={false}>
        <WalletModalProvider>
          <TransactionPersistenceProvider>
            <QueryClientProvider client={queryClient}>
              <Router />
              <Toaster />
            </QueryClientProvider>
          </TransactionPersistenceProvider>
        </WalletModalProvider>
      </WalletProvider>
    </ConnectionProvider>
  );
}

export default App;