import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import {
  ConnectionProvider,
  WalletProvider,
  useConnection,
  useWallet,
} from "@solana/wallet-adapter-react";
import { WalletModalProvider } from "@solana/wallet-adapter-react-ui";
import { PhantomWalletAdapter, SolflareWalletAdapter } from "@solana/wallet-adapter-wallets";
import { WalletAdapterNetwork } from "@solana/wallet-adapter-base";
import { useMemo, useState, useEffect, createContext, useContext } from "react";
import '@solana/wallet-adapter-react-ui/styles.css';
import TransactionPersistence from '../../TransactionPersistence';
// @ts-ignore - Import TransactionManager
import TransactionManager from '../../TransactionManager';
import { db } from './lib/firebase.ts';
import { TransactionProvider } from './context/TransactionContext';
import { BalanceProvider } from './context/BalanceContext';

// Extend Window interface to include our global functions
declare global {
  interface Window {
    transactionManager: any;
    updatePongCreditsUI: (newAmount: number) => void;
    showPendingTransaction?: (signature: string, amount: number, pongCredits: number) => void;
  }
}

// Create context for transaction persistence
export const TransactionPersistenceContext = createContext<{
  txPersistence: TransactionPersistence | null;
  transactionManager: any | null;
  solBalance: number;
}>({
  txPersistence: null,
  transactionManager: null,
  solBalance: 0
});

// Custom hook to use the transaction persistence context
export function useTransactionPersistence() {
  return useContext(TransactionPersistenceContext);
}

function TransactionPersistenceProvider({ children }: { children: React.ReactNode }) {
  const { connection } = useConnection();
  const wallet = useWallet();
  const [txPersistence, setTxPersistence] = useState<TransactionPersistence | null>(null);
  const [transactionManager, setTransactionManager] = useState(null);
  const [solBalance, setSolBalance] = useState<number>(0);
  
  // CRITICAL FIX: Enhanced transaction persistence initialization with automatic recovery
  useEffect(() => {
    // Only initialize when wallet is connected
    if (wallet.connected && connection && wallet.publicKey) {
      console.log("Initializing enhanced TransactionPersistence system with recovery");
      
      // Create the persistence instance with additional logging
      console.log("Creating TransactionPersistence instance with wallet:", wallet.publicKey.toString());
      const persistence = new TransactionPersistence(connection, wallet);
      setTxPersistence(persistence);
      
      // CRITICAL: dispatch a wallet connection event to trigger transaction recovery
      // This is important for recovering transactions after page refresh
      try {
        console.log("Dispatching walletConnected event to trigger transaction recovery");
        const connectEvent = new CustomEvent('walletConnected', {
          detail: { walletAddress: wallet.publicKey.toString() }
        });
        window.dispatchEvent(connectEvent);
      } catch (e) {
        console.error("Error dispatching wallet connect event:", e);
      }
      
      // Set up listener for SOL balance updates with better error handling
      const handleBalanceUpdate = (event: CustomEvent) => {
        try {
          if (event.detail && typeof event.detail.amount === 'number') {
            console.log(`SOL balance update received: ${event.detail.amount}`);
            setSolBalance(event.detail.amount);
            
            // Force fetch pending transactions after balance update
            try {
              const refreshEvent = new CustomEvent('transactionUpdated');
              window.dispatchEvent(refreshEvent);
            } catch (e) {
              console.error("Error dispatching refresh event after balance update:", e);
            }
          }
        } catch (error) {
          console.error("Error handling SOL balance update event:", error);
        }
      };
      
      // Register event listeners with better error handling
      console.log("Setting up event listeners for transaction updates");
      window.addEventListener('solBalanceUpdated', handleBalanceUpdate as EventListener);
      
      // CRITICAL: Immediately fetch user SOL balance upon connection
      const fetchBalance = async () => {
        try {
          // Use the Solana connection to get the wallet's SOL balance
          const solBalance = await connection.getBalance(wallet.publicKey);
          const solBalanceInSol = solBalance / 1000000000; // Convert lamports to SOL
          console.log("Initial SOL balance fetch:", solBalanceInSol);
          setSolBalance(solBalanceInSol);
        } catch (error) {
          console.error("Error fetching initial SOL balance:", error);
        }
      };
      
      fetchBalance();
      
      // Cleanup function with better error handling
      return () => {
        try {
          console.log("Cleaning up TransactionPersistence");
          window.removeEventListener('solBalanceUpdated', handleBalanceUpdate as EventListener);
          
          if (persistence) {
            try {
              persistence.cleanup();
            } catch (e) {
              console.error("Error during persistence cleanup:", e);
            }
          }
        } catch (e) {
          console.error("Error during cleanup:", e);
        }
        
        setTxPersistence(null);
      };
    } else {
      setTxPersistence(null);
    }
  }, [connection, wallet.connected, wallet.publicKey]);
  
  // CRITICAL FIX: Enhanced TransactionManager initialization with better error handling and recovery
  useEffect(() => {
    // Only initialize when all dependencies are available
    if (wallet && connection && wallet.publicKey) {
      console.log("Initializing enhanced transaction manager with recovery capabilities...");
      
      try {
        // CRITICAL: Add error handler before creating the manager
        window.onerror = function(message, source, lineno, colno, error) {
          console.error("Global error caught:", { message, source, lineno, colno, error });
          return false; // Let default error handling continue
        };
        
        // Create the transaction manager with enhanced error handling
        console.log("Creating TransactionManager instance with wallet:", wallet.publicKey.toString());
        const manager = new TransactionManager(connection, wallet, null);
        
        // CRITICAL: Make globally available immediately to catch transactions
        window.transactionManager = manager;
        
        // Store in state
        setTransactionManager(manager);
        
        console.log("Transaction manager initialized successfully");
        
        // CRITICAL: Run recovery check explicitly after initialization
        try {
          console.log("Running transaction recovery check");
          const checkEvent = new CustomEvent('checkPendingTransactions');
          window.dispatchEvent(checkEvent);
          
          // Also check for incomplete transactions on the blockchain
          if (manager._checkAllPendingTransactions) {
            console.log("Running blockchain transaction verification");
            manager._checkAllPendingTransactions();
          }
        } catch (recoveryError) {
          console.error("Error during transaction recovery:", recoveryError);
        }
        
        // Cleanup function with better error handling
        return () => {
          try {
            console.log("Cleaning up TransactionManager");
            if (manager && manager.cleanup) {
              manager.cleanup();
            }
            
            // Remove from window object to prevent memory leaks
            if (window.transactionManager === manager) {
              window.transactionManager = null;
            }
          } catch (cleanupError) {
            console.error("Error cleaning up transaction manager:", cleanupError);
          }
        };
      } catch (error) {
        console.error("Error initializing transaction manager:", error);
        // Still try to update UI on initialization error
        try {
          const errorEvent = new CustomEvent('transactionManagerError', {
            detail: { error: String(error) }
          });
          window.dispatchEvent(errorEvent);
        } catch (e) {
          console.error("Error dispatching error event:", e);
        }
      }
    }
  }, [wallet, connection, wallet?.publicKey?.toString()]);

  return (
    <TransactionPersistenceContext.Provider value={{ txPersistence, transactionManager, solBalance }}>
      {children}
    </TransactionPersistenceContext.Provider>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const endpoint = useMemo(() => import.meta.env.VITE_QUICKNODE_RPC_URL, []);
  const network = WalletAdapterNetwork.Mainnet;

  const wallets = useMemo(() => {
    return [
      new PhantomWalletAdapter(),
      new SolflareWalletAdapter({ network }),
    ];
  }, [network]);
  
  // Add UI Update Handlers with more robust implementation
  useEffect(() => {
    // Enhanced global function to update SOL balance display with better error handling
    window.updatePongCreditsUI = (newAmount: number): void => {
      console.log(`Updating SOL balance UI: ${newAmount}`);
      
      try {
        // Dispatch a custom event to update UI components
        const event = new CustomEvent('solBalanceUpdated', {
          detail: { 
            amount: newAmount,
            added: 0, // We don't know how many were added in this case
            signature: null
          }
        });
        window.dispatchEvent(event);
        
        // Also try to update any balance displays
        const balanceEvent = new CustomEvent('balanceUpdated', {
          detail: { amount: newAmount }
        });
        window.dispatchEvent(balanceEvent);
      } catch (error) {
        console.error('Error updating UI for SOL balance:', error);
      }
    };
    
    // CRITICAL FIX: Enhanced function to show pending transaction in UI
    // This ensures transactions are immediately visible and persist across refreshes
    window.showPendingTransaction = (signature: string, amount: number, stakeAmount: number): void => {
      console.log(`Showing pending transaction: ${signature || 'unsigned'}, amount: ${amount}, stake: ${stakeAmount}`);
      
      try {
        // First, store in localStorage for persistence across refreshes
        const pendingTxs = JSON.parse(localStorage.getItem('pendingTransactions') || '[]');
        const txId = signature || `pending-${Date.now()}`;
        
        // Check if this transaction already exists
        const existingIndex = pendingTxs.findIndex((tx: any) => 
          (signature && tx.signature === signature) || 
          (!signature && tx.amount === amount && tx.stakeAmount === stakeAmount)
        );
        
        const newTx = {
          id: txId,
          signature: signature || undefined,
          type: 'solStake',
          amount: amount,
          stakeAmount: stakeAmount,
          status: 'pending',
          timestamp: Date.now(),
          lastUpdated: Date.now(),
          confirmations: 0
        };
        
        if (existingIndex >= 0) {
          // Update existing transaction
          pendingTxs[existingIndex] = { ...pendingTxs[existingIndex], ...newTx };
        } else {
          // Add new transaction
          pendingTxs.push(newTx);
        }
        
        // Save to localStorage for persistence across refreshes
        localStorage.setItem('pendingTransactions', JSON.stringify(pendingTxs));
        
        // Dispatch event to immediately update UI
        const event = new CustomEvent('pendingTransactionAdded', {
          detail: {
            transaction: newTx
          }
        });
        window.dispatchEvent(event);
        
        // Also dispatch legacy event for backward compatibility
        const legacyEvent = new CustomEvent('pendingTransaction', {
          detail: {
            signature,
            amount,
            stakeAmount,
            timestamp: Date.now()
          }
        });
        window.dispatchEvent(legacyEvent);
        
        console.log(`Pending transaction saved and UI updated for ${signature || 'unsigned tx'}`);
      } catch (error) {
        console.error('Error showing pending transaction:', error);
        
        // Fallback: still try to dispatch the event even if localStorage fails
        try {
          const event = new CustomEvent('pendingTransaction', {
            detail: {
              signature,
              amount,
              stakeAmount,
              timestamp: Date.now()
            }
          });
          window.dispatchEvent(event);
        } catch (e) {
          console.error('Even fallback event dispatch failed:', e);
        }
      }
    };
    
    // Listen for SOL balance updated event with better error handling
    const handleBalanceUpdated = (event: CustomEvent): void => {
      try {
        if (!event.detail) return;
        
        const { amount, added, signature } = event.detail;
        
        // Log the update
        console.log(`SOL balance updated: ${amount} ${added ? `(+${added})` : ''}`);
        
        // Notify PendingTransactions component to refresh
        const refreshEvent = new CustomEvent('transactionUpdated', {
          detail: { signature, status: 'completed' }
        });
        window.dispatchEvent(refreshEvent);
      } catch (error) {
        console.error('Error handling SOL balance update event:', error);
      }
    };
    
    // Register event listeners
    window.addEventListener('solBalanceUpdated', handleBalanceUpdated as EventListener);
    
    // Force a transaction check on wallet connection or page load
    const checkTransactions = (): void => {
      try {
        const event = new CustomEvent('checkPendingTransactions');
        window.dispatchEvent(event);
      } catch (error) {
        console.error('Error triggering transaction check:', error);
      }
    };
    
    // Check transactions on load
    checkTransactions();
    
    // Register for wallet connect events
    window.addEventListener('walletConnected', checkTransactions);
    
    // Cleanup all event listeners
    return () => {
      window.removeEventListener('solBalanceUpdated', handleBalanceUpdated as EventListener);
      window.removeEventListener('walletConnected', checkTransactions);
    };
  }, []);

  if (!endpoint) {
    return <div className="p-4 text-red-500">Error: Solana RPC endpoint not configured</div>;
  }

  return (
    <ConnectionProvider endpoint={endpoint}>
      <WalletProvider wallets={wallets} autoConnect={false}>
        <WalletModalProvider>
          <TransactionPersistenceProvider>
            <TransactionProvider>
              <BalanceProvider>
                <QueryClientProvider client={queryClient}>
                  <Router />
                  <Toaster />
                </QueryClientProvider>
              </BalanceProvider>
            </TransactionProvider>
          </TransactionPersistenceProvider>
        </WalletModalProvider>
      </WalletProvider>
    </ConnectionProvider>
  );
}

export default App;