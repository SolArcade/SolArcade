import { pgTable, text, serial, numeric, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  walletAddress: text("wallet_address").notNull(),
  amount: numeric("amount", { precision: 10, scale: 4 }).notNull(),
  status: text("status").notNull(),
  timestamp: text("timestamp").notNull(),
  transactionSignature: text("transaction_signature"),
  preSubmissionId: text("pre_submission_id"),
  transactionType: text("transaction_type").default("game_stake"), // "game_stake", "game_payout", "game_winnings", "game_disconnect_win", "game_cancellation_refund", "game_cancellation_refund_simulated"
  gameId: text("game_id"), // To track which game this transaction belongs to
  processingAttempts: integer("processing_attempts").default(0),
  lastProcessingTimestamp: text("last_processing_timestamp"),
});

export const insertTransactionSchema = createInsertSchema(transactions).pick({
  walletAddress: true,
  amount: true,
  status: true,
  timestamp: true,
  transactionSignature: true,
  preSubmissionId: true,
  transactionType: true,
  gameId: true,
  processingAttempts: true,
  lastProcessingTimestamp: true,
}).extend({
  amount: z.number().min(0), // Allow zero amount transactions
  timestamp: z.string().datetime(),
  status: z.enum(['completed', 'pending', 'processing', 'submitted', 'confirmed', 'failed']),
  transactionSignature: z.string().optional(),
  preSubmissionId: z.string().optional(),
  transactionType: z.enum([
    'game_stake', 
    'game_payout', 
    'game_winnings', 
    'game_disconnect_win', 
    'game_cancellation_refund', 
    'game_cancellation_refund_simulated'
  ]).optional(),
  gameId: z.string().optional(),
  processingAttempts: z.number().int().optional(),
  lastProcessingTimestamp: z.string().datetime().optional(),
});

// User table with game stats
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  walletAddress: text("wallet_address").notNull().unique(),
  gamesPlayed: integer("games_played").notNull().default(0),
  gamesWon: integer("games_won").notNull().default(0),
  totalStaked: numeric("total_staked", { precision: 10, scale: 4 }).notNull().default("0"),
  totalWon: numeric("total_won", { precision: 10, scale: 4 }).notNull().default("0"),
  lastUpdated: text("last_updated").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  walletAddress: true,
  gamesPlayed: true,
  gamesWon: true,
  totalStaked: true,
  totalWon: true,
  lastUpdated: true,
}).extend({
  gamesPlayed: z.number().int().default(0),
  gamesWon: z.number().int().default(0),
  totalStaked: z.number().or(z.string()).transform(val => typeof val === 'number' ? val.toString() : val),
  totalWon: z.number().or(z.string()).transform(val => typeof val === 'number' ? val.toString() : val),
  lastUpdated: z.string().datetime(),
});

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;