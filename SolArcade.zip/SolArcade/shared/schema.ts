import { pgTable, text, serial, numeric, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  walletAddress: text("wallet_address").notNull(),
  amount: numeric("amount", { precision: 10, scale: 4 }).notNull(),
  status: text("status").notNull(),
  timestamp: text("timestamp").notNull(),
  pongCredits: integer("pong_credits").notNull().default(0),
  transactionSignature: text("transaction_signature"),
  preSubmissionId: text("pre_submission_id"),
  expectedCredits: integer("expected_credits"),
  processingAttempts: integer("processing_attempts").default(0),
  lastProcessingTimestamp: text("last_processing_timestamp"),
});

export const insertTransactionSchema = createInsertSchema(transactions).pick({
  walletAddress: true,
  amount: true,
  status: true,
  timestamp: true,
  pongCredits: true,
  transactionSignature: true,
  preSubmissionId: true,
  expectedCredits: true,
  processingAttempts: true,
  lastProcessingTimestamp: true,
}).extend({
  amount: z.number().min(0), // Allow zero amount transactions
  timestamp: z.string().datetime(),
  status: z.enum(['completed', 'pending', 'processing', 'submitted', 'confirmed', 'failed']),
  pongCredits: z.number().int(), // Allow both positive and negative values for credit updates
  transactionSignature: z.string().optional(),
  preSubmissionId: z.string().optional(),
  expectedCredits: z.number().int().optional(),
  processingAttempts: z.number().int().optional(),
  lastProcessingTimestamp: z.string().datetime().optional(),
});

// User table to store credit balances
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  walletAddress: text("wallet_address").notNull().unique(),
  pongCredits: integer("pong_credits").notNull().default(0),
  lastUpdated: text("last_updated").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  walletAddress: true,
  pongCredits: true,
  lastUpdated: true,
}).extend({
  pongCredits: z.number().int(), 
  lastUpdated: z.string().datetime(),
});

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;