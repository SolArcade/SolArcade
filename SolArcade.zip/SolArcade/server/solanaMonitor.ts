import { Connection, PublicKey, LAMPORTS_PER_SOL, TransactionSignature } from "@solana/web3.js";
import { storage } from "./storage";
import WebSocket from 'ws';
import { v4 as uuidv4 } from 'uuid';

// Map to store pending transactions by signature
interface PendingCredit {
  id: string;             // Unique ID for tracking before signature is available
  walletAddress: string;
  amount: number;
  credits: number;
  timestamp: number;
  retryCount: number;
  status: 'pending' | 'submitted' | 'confirmed' | 'failed';
}

// Used for pending transactions before signature is available
interface PreSubmissionTransaction {
  id: string;
  walletAddress: string;
  amount: number;
  credits: number;
  timestamp: number;
}

// Singleton class for monitoring Solana transactions
export class SolanaMonitor {
  private static instance: SolanaMonitor;
  private connection: Connection;
  private wsConnection: WebSocket | null = null;
  private houseWalletAddress: string = "45GGPAkoxwisBWj5YtHj1BH1tekmoFbRigSNJ4fT9UD2";
  private houseWallet: PublicKey;
  private pendingCredits: Map<string, PendingCredit> = new Map(); // Map by signature
  private preSubmissionTransactions: Map<string, PreSubmissionTransaction> = new Map(); // Map by generated ID
  private monitorInterval: NodeJS.Timeout | null = null;
  private wsReconnectInterval: NodeJS.Timeout | null = null;
  private isMonitoring: boolean = false;
  private wsUrl: string;

  private constructor() {
    this.connection = new Connection(process.env.QUICKNODE_RPC_URL!, "confirmed");
    this.houseWallet = new PublicKey(this.houseWalletAddress);
    this.wsUrl = process.env.QUICKNODE_RPC_URL!.replace('https://', 'wss://');
    
    // Start both HTTP and WebSocket monitoring
    this.startMonitoring();
    this.connectWebSocket();
  }

  public static getInstance(): SolanaMonitor {
    if (!SolanaMonitor.instance) {
      SolanaMonitor.instance = new SolanaMonitor();
    }
    return SolanaMonitor.instance;
  }

  // Create a pre-submission transaction record
  public createPreSubmissionTransaction(walletAddress: string, amount: number, credits: number): string {
    const id = uuidv4();
    console.log(`Creating pre-submission transaction record with ID ${id} for wallet ${walletAddress}, amount ${amount}, credits ${credits}`);
    
    this.preSubmissionTransactions.set(id, {
      id,
      walletAddress,
      amount,
      credits,
      timestamp: Date.now()
    });
    
    // Make sure monitoring is running
    if (!this.isMonitoring) {
      this.startMonitoring();
    }
    
    return id;
  }

  // Track a transaction with signature after submission
  public trackTransaction(signature: string, walletAddress: string, amount: number, credits: number, preSubmissionId?: string): void {
    console.log(`Tracking transaction ${signature} for wallet ${walletAddress}, amount ${amount}, credits ${credits}`);
    
    // Create a pending credit entry
    this.pendingCredits.set(signature, {
      id: preSubmissionId || uuidv4(), // Use pre-submission ID if available or generate a new one
      walletAddress,
      amount,
      credits,
      timestamp: Date.now(),
      retryCount: 0,
      status: 'submitted'
    });
    
    // If this was tracked from a pre-submission record, remove it from pre-submission transactions
    if (preSubmissionId && this.preSubmissionTransactions.has(preSubmissionId)) {
      console.log(`Removing pre-submission record ${preSubmissionId} now that we have signature ${signature}`);
      this.preSubmissionTransactions.delete(preSubmissionId);
    }
    
    // Make sure monitoring is running
    if (!this.isMonitoring) {
      this.startMonitoring();
    }
    
    // Also subscribe to this specific transaction for real-time updates
    this.subscribeToTransaction(signature);
  }

  // Start the HTTP polling monitoring process
  private startMonitoring(): void {
    if (this.isMonitoring) return;
    
    this.isMonitoring = true;
    console.log("Starting Solana transaction monitoring via HTTP polling");
    
    this.monitorInterval = setInterval(async () => {
      await this.processAllPendingCredits();
    }, 5000); // Check every 5 seconds as a fallback mechanism
  }
  
  // Connect to QuickNode WebSocket for real-time updates
  private connectWebSocket(): void {
    try {
      console.log("Connecting to QuickNode WebSocket...");
      
      // Close any existing connection
      if (this.wsConnection) {
        this.wsConnection.close();
      }
      
      // Create new WebSocket connection
      this.wsConnection = new WebSocket(this.wsUrl);
      
      this.wsConnection.on('open', () => {
        console.log("QuickNode WebSocket connected successfully");
        // Subscribe to all pending transactions
        this.subscribeToAllPendingTransactions();
      });
      
      this.wsConnection.on('message', (data: WebSocket.Data) => {
        try {
          const response = JSON.parse(data.toString());
          this.handleWebSocketMessage(response);
        } catch (error) {
          console.error("Failed to parse WebSocket message:", error);
        }
      });
      
      this.wsConnection.on('error', (error) => {
        console.error("QuickNode WebSocket error:", error);
      });
      
      this.wsConnection.on('close', () => {
        console.log("QuickNode WebSocket connection closed, scheduling reconnect");
        // Schedule reconnection
        if (!this.wsReconnectInterval) {
          this.wsReconnectInterval = setInterval(() => {
            this.connectWebSocket();
          }, 10000); // Try to reconnect every 10 seconds
        }
      });
    } catch (error) {
      console.error("Failed to connect to QuickNode WebSocket:", error);
    }
  }
  
  // Subscribe to all currently pending transactions via WebSocket
  private subscribeToAllPendingTransactions(): void {
    if (!this.wsConnection || this.wsConnection.readyState !== WebSocket.OPEN) {
      return;
    }
    
    console.log("Subscribing to all pending transactions via WebSocket");
    
    // Subscribe to each pending transaction - use Array.from to avoid iterator issues
    Array.from(this.pendingCredits.keys()).forEach(signature => {
      this.subscribeToTransaction(signature);
    });
  }
  
  // Subscribe to a specific transaction via WebSocket
  private subscribeToTransaction(signature: string): void {
    if (!this.wsConnection || this.wsConnection.readyState !== WebSocket.OPEN) {
      return;
    }
    
    console.log(`Subscribing to transaction ${signature} via WebSocket`);
    
    // Send subscription request
    this.wsConnection.send(JSON.stringify({
      jsonrpc: "2.0",
      id: signature.substring(0, 8), // Use part of the signature as the ID
      method: "signatureSubscribe",
      params: [
        signature,
        {
          commitment: "confirmed"
        }
      ]
    }));
  }
  
  // Handle WebSocket message (transaction confirmation)
  private async handleWebSocketMessage(response: any): Promise<void> {
    // Check if this is a signature notification
    if (response.method === "signatureNotification" && response.params?.result?.value) {
      const signature = response.params.subscription;
      const status = response.params.result.value;
      
      console.log(`WebSocket notification received for transaction: ${signature}`);
      
      // Check if transaction is confirmed or failed
      if (status.err) {
        console.log(`Transaction ${signature} failed: ${JSON.stringify(status.err)}`);
        
        // Check if transaction exists in database and update status
        const dbTransaction = await storage.getTransactionBySignature(signature);
        if (dbTransaction) {
          await storage.updateTransactionStatus(dbTransaction.id, 'failed');
          console.log(`Updated transaction ${signature} status to failed in database due to WebSocket notification`);
        }
        
        // Remove from pending credits
        this.pendingCredits.delete(signature);
      } else {
        console.log(`Transaction ${signature} confirmed via WebSocket!`);
        
        // Process this confirmed transaction
        const pendingCredit = this.pendingCredits.get(signature);
        if (pendingCredit) {
          try {
            // Check if this transaction was already processed
            const dbTransaction = await storage.getTransactionBySignature(signature);
            
            if (dbTransaction && dbTransaction.status === 'completed') {
              console.log(`Transaction ${signature} was already processed, skipping credit award`);
              this.pendingCredits.delete(signature);
              return;
            }
            
            // Double-check with an HTTP request to ensure transaction is valid
            const isValid = await this.verifyTransaction(signature, pendingCredit);
            
            if (isValid) {
              // Award credits to the user
              await this.addCreditsToUser(signature, pendingCredit);
              this.pendingCredits.delete(signature);
            }
          } catch (error) {
            console.error(`Error processing WebSocket confirmation for ${signature}:`, error);
          }
        }
      }
    }
  }

  // Process all pending credits transactions (HTTP polling fallback)
  private async processAllPendingCredits(): Promise<void> {
    // First check pre-submission transactions
    await this.processPreSubmissionTransactions();
    
    // Then check pending credits with signatures
    if (this.pendingCredits.size === 0) return;
    
    console.log(`HTTP Polling: Processing ${this.pendingCredits.size} pending credit transactions`);
    
    // Create a list of entries to be processed (to avoid concurrent modification issues)
    const entries = Array.from(this.pendingCredits.entries());
    
    for (const [signature, pendingCredit] of entries) {
      try {
        // Skip if retry count is too high (been trying for a long time)
        if (pendingCredit.retryCount > 60) { // ~5 minutes max (60 x 5 seconds)
          console.log(`Giving up on transaction ${signature} after ${pendingCredit.retryCount} retries`);
          
          // Even for expired transactions, check one last time if it exists in database
          const dbTransaction = await storage.getTransactionBySignature(signature);
          
          // If it's already completed in the database, we don't need to worry
          if (dbTransaction && dbTransaction.status === 'completed') {
            console.log(`Transaction ${signature} was already processed successfully in the database`);
            this.pendingCredits.delete(signature);
            continue;
          }
          
          // Also check for pre-submission records
          if (pendingCredit.id) {
            const preSubmissionTx = await storage.getTransactionByPreSubmissionId(pendingCredit.id);
            if (preSubmissionTx && preSubmissionTx.status === 'completed') {
              console.log(`Transaction with pre-submission ID ${pendingCredit.id} was already processed in the database`);
              this.pendingCredits.delete(signature);
              continue;
            } else if (preSubmissionTx) {
              // Update the pre-submission transaction to have the signature
              await storage.updateTransactionSignature(preSubmissionTx.id, signature);
              await storage.updateTransactionStatus(preSubmissionTx.id, 'failed');
              console.log(`Updated pre-submission transaction ${pendingCredit.id} status to failed in database`);
            }
          }
          
          // Update transaction status to failed in the database
          if (dbTransaction) {
            await storage.updateTransactionStatus(dbTransaction.id, 'failed');
            console.log(`Updated transaction ${signature} status to failed in database`);
          }
          
          this.pendingCredits.delete(signature);
          continue;
        }
        
        // Try to verify the transaction
        const isVerified = await this.verifyTransaction(signature, pendingCredit);
        
        if (isVerified) {
          // Update status to confirmed
          pendingCredit.status = 'confirmed';
          
          // Check if this transaction was already processed (e.g., via WebSocket)
          const dbTransaction = await storage.getTransactionBySignature(signature);
          
          if (dbTransaction && dbTransaction.status === 'completed') {
            console.log(`Transaction ${signature} was already processed via another channel`);
            this.pendingCredits.delete(signature);
            continue;
          }
          
          // Check if there's a pre-submission transaction
          if (pendingCredit.id) {
            const preSubmissionTx = await storage.getTransactionByPreSubmissionId(pendingCredit.id);
            if (preSubmissionTx && preSubmissionTx.status === 'completed') {
              console.log(`Transaction with pre-submission ID ${pendingCredit.id} was already processed`);
              this.pendingCredits.delete(signature);
              continue;
            } else if (preSubmissionTx && preSubmissionTx.status !== 'failed') {
              // Update the pre-submission transaction to have the signature
              await storage.updateTransactionSignature(preSubmissionTx.id, signature);
            }
          }
          
          // If verified and not already processed, add the credits to the user's account
          await this.addCreditsToUser(signature, pendingCredit);
          this.pendingCredits.delete(signature);
        } else {
          // Increment retry count
          pendingCredit.retryCount++;
          this.pendingCredits.set(signature, pendingCredit);
        }
      } catch (error) {
        console.error(`Error processing pending credit for transaction ${signature}:`, error);
        // Increment retry count even on error
        pendingCredit.retryCount++;
        this.pendingCredits.set(signature, pendingCredit);
      }
    }
  }
  
  // Process all transactions that were tracked before submission (pre-signature)
  private async processPreSubmissionTransactions(): Promise<void> {
    if (this.preSubmissionTransactions.size === 0) return;
    
    console.log(`Processing ${this.preSubmissionTransactions.size} pre-submission transactions`);
    
    // Create a list of pre-submission transactions to process
    const entries = Array.from(this.preSubmissionTransactions.entries());
    
    // For each pre-submission transaction, check if it's in the database with a signature
    for (const [id, transaction] of entries) {
      try {
        const now = Date.now();
        const fiveMinutesMs = 5 * 60 * 1000;
        
        // First check if it's older than 5 minutes - if so, remove it
        if (now - transaction.timestamp > fiveMinutesMs) {
          console.log(`Pre-submission transaction ${id} is older than 5 minutes, removing it`);
          this.preSubmissionTransactions.delete(id);
          continue;
        }
        
        // Check if this transaction was processed through another channel (like a server restart)
        // by looking it up in the database by preSubmissionId
        const dbTransaction = await storage.getTransactionByPreSubmissionId(id);
        
        if (dbTransaction) {
          console.log(`Pre-submission transaction ${id} found in database with status ${dbTransaction.status}`);
          
          // If it has a signature and is completed, we can remove it from our tracking
          if (dbTransaction.status === 'completed' || 
              (dbTransaction.transactionSignature && dbTransaction.status !== 'failed')) {
            console.log(`Pre-submission transaction ${id} is already processed, removing from tracking`);
            this.preSubmissionTransactions.delete(id);
          } 
          // If it has a signature but hasn't been completed yet, add it to pendingCredits for monitoring
          else if (dbTransaction.transactionSignature) {
            console.log(`Pre-submission transaction ${id} has signature ${dbTransaction.transactionSignature}, adding to pendingCredits`);
            this.trackTransaction(
              dbTransaction.transactionSignature, 
              dbTransaction.walletAddress, 
              parseFloat(dbTransaction.amount.toString()), 
              dbTransaction.expectedCredits || dbTransaction.pongCredits,
              id
            );
            
            // Remove from pre-submission tracking since it's now in pendingCredits
            this.preSubmissionTransactions.delete(id);
          }
        }
      } catch (error) {
        console.error(`Error processing pre-submission transaction ${id}:`, error);
      }
    }
  }
  
  // Get all pending transactions for a wallet
  public getPendingTransactions(walletAddress: string): { id: string, amount: number, credits: number, timestamp: number, status: string }[] {
    const result: { id: string, amount: number, credits: number, timestamp: number, status: string }[] = [];
    
    // Check pre-submission transactions using Array.from to avoid iterator issues
    Array.from(this.preSubmissionTransactions.entries()).forEach(([id, transaction]) => {
      if (transaction.walletAddress === walletAddress) {
        result.push({
          id,
          amount: transaction.amount,
          credits: transaction.credits,
          timestamp: transaction.timestamp,
          status: 'pre_submission'
        });
      }
    });
    
    // Check pending credits with signatures using Array.from to avoid iterator issues
    Array.from(this.pendingCredits.entries()).forEach(([signature, pendingCredit]) => {
      if (pendingCredit.walletAddress === walletAddress) {
        result.push({
          id: pendingCredit.id,
          amount: pendingCredit.amount,
          credits: pendingCredit.credits,
          timestamp: pendingCredit.timestamp,
          status: pendingCredit.status
        });
      }
    });
    
    return result;
  }

  // Verify a Solana transaction
  private async verifyTransaction(signature: string, pendingCredit: PendingCredit): Promise<boolean> {
    try {
      console.log(`Verifying transaction ${signature}`);
      
      // Get the transaction details from Solana
      const transaction = await this.connection.getTransaction(signature, {
        commitment: "confirmed"
      });
      
      // If transaction doesn't exist or has failed, return false
      if (!transaction || transaction.meta?.err) {
        console.log(`Transaction ${signature} verification failed: ${!transaction ? 'not found' : 'has errors'}`);
        return false;
      }
      
      // Check if transaction is a transfer to the house wallet address
      const isValid = this.validateTransaction(transaction, pendingCredit);
      
      if (isValid) {
        console.log(`Transaction ${signature} is valid`);
        return true;
      }
      
      console.log(`Transaction ${signature} verification failed: not a valid transfer`);
      return false;
    } catch (error) {
      console.error(`Error verifying transaction ${signature}:`, error);
      return false;
    }
  }
  
  // Validate transaction details (more thorough check)
  private validateTransaction(transaction: any, pendingCredit: PendingCredit): boolean {
    try {
      // In a real production environment, you'd want to perform a more thorough validation:
      // 1. Check that this is a System Program transfer
      // 2. Verify the sender's address matches pendingCredit.walletAddress
      // 3. Verify the recipient is the house wallet address
      // 4. Verify the amount matches pendingCredit.amount
      
      // For now, we're simplifying and assuming QuickNode's signature verification is sufficient
      // This is a decision point for how thorough you want the validation to be
      return true;
    } catch (error) {
      console.error("Transaction validation error:", error);
      return false;
    }
  }

  // Add credits to the user's account after verifying the transaction
  private async addCreditsToUser(signature: string, pendingCredit: PendingCredit): Promise<void> {
    try {
      console.log(`Adding ${pendingCredit.credits} credits to wallet ${pendingCredit.walletAddress}`);
      
      // First, check if this transaction is already in the database
      let existingTransaction = await storage.getTransactionBySignature(signature);
      let existingPresubmissionTransaction = pendingCredit.id ? 
        await storage.getTransactionByPreSubmissionId(pendingCredit.id) : null;
      
      // If we found an existing transaction that's already completed, nothing to do
      if ((existingTransaction && existingTransaction.status === 'completed') ||
          (existingPresubmissionTransaction && existingPresubmissionTransaction.status === 'completed')) {
        console.log(`Transaction ${signature} already processed, skipping credit award`);
        return;
      }
      
      // If we found a pending transaction with this pre-submission ID, update it
      if (existingPresubmissionTransaction && existingPresubmissionTransaction.status !== 'completed') {
        console.log(`Updating existing transaction with pre-submission ID ${pendingCredit.id}`);
        
        // Update the transaction's signature and status
        await storage.updateTransactionSignature(existingPresubmissionTransaction.id, signature);
        await storage.updateTransactionStatus(existingPresubmissionTransaction.id, 'completed');
        
        // 1. Update the user's credit balance
        const updatedUser = await storage.updateUserCredits(
          pendingCredit.walletAddress, 
          pendingCredit.credits
        );
        
        if (!updatedUser) {
          console.warn(`User not found for wallet ${pendingCredit.walletAddress}, may have been created`);
        } else {
          console.log(`Updated user credits, new balance: ${updatedUser.pongCredits}`);
        }
        
        console.log(`Credits added successfully for pre-submission transaction ${pendingCredit.id} with signature ${signature}`);
        return;
      }
      
      // If we found a pending transaction with this signature, update it
      if (existingTransaction && existingTransaction.status !== 'completed') {
        console.log(`Updating existing transaction with signature ${signature}`);
        
        // Update the transaction status
        await storage.updateTransactionStatus(existingTransaction.id, 'completed');
        
        // Update the user's credit balance
        const updatedUser = await storage.updateUserCredits(
          pendingCredit.walletAddress, 
          pendingCredit.credits
        );
        
        if (!updatedUser) {
          console.warn(`User not found for wallet ${pendingCredit.walletAddress}, may have been created`);
        } else {
          console.log(`Updated user credits, new balance: ${updatedUser.pongCredits}`);
        }
        
        console.log(`Credits added successfully for existing transaction ${signature}`);
        return;
      }
      
      // No existing transaction found, create a new one
      console.log(`Creating new transaction record for ${signature}`);
      
      // 1. First update the user's credit balance
      const updatedUser = await storage.updateUserCredits(
        pendingCredit.walletAddress, 
        pendingCredit.credits
      );
      
      if (!updatedUser) {
        console.warn(`User not found for wallet ${pendingCredit.walletAddress}, may have been created`);
      } else {
        console.log(`Updated user credits, new balance: ${updatedUser.pongCredits}`);
      }
      
      // 2. Then record the transaction with the signature for tracking
      const transaction = await storage.createTransaction({
        walletAddress: pendingCredit.walletAddress,
        amount: pendingCredit.amount,
        status: 'completed',
        timestamp: new Date().toISOString(),
        pongCredits: pendingCredit.credits,
        transactionSignature: signature,
        preSubmissionId: pendingCredit.id,
        expectedCredits: pendingCredit.credits,
        processingAttempts: pendingCredit.retryCount + 1,
        lastProcessingTimestamp: new Date().toISOString()
      });
      
      console.log(`Credits added successfully for new transaction ${signature}`);
    } catch (error) {
      console.error(`Error adding credits for transaction ${signature}:`, error);
      throw error; // Re-throw to handle in the calling function
    }
  }

  // Check the status of a specific transaction
  public async getTransactionStatus(signature: string): Promise<string> {
    if (this.pendingCredits.has(signature)) {
      return "pending";
    }
    
    try {
      const transaction = await this.connection.getTransaction(signature, {
        commitment: "confirmed"
      });
      
      if (!transaction) return "not_found";
      if (transaction.meta?.err) return "failed";
      return "confirmed";
    } catch (error) {
      console.error(`Error getting transaction status for ${signature}:`, error);
      return "error";
    }
  }

  // Get priority fee estimate for faster transactions
  public async getPriorityFeeEstimate(): Promise<number> {
    try {
      // Query recent priority fees to calculate an optimal fee
      const recentFees = await this.connection.getRecentPrioritizationFees();
      
      if (recentFees.length === 0) {
        // Default to 10000 lamports if no data available
        return 10000;
      }
      
      // Sort fees by slot (most recent first)
      recentFees.sort((a, b) => b.slot - a.slot);
      
      // Get the 20 most recent fees
      const recentFeesSlice = recentFees.slice(0, 20);
      
      // Calculate a reasonable fee (average of recent fees, plus 20%)
      const avgFee = recentFeesSlice.reduce((sum, fee) => sum + fee.prioritizationFee, 0) / recentFeesSlice.length;
      const recommendedFee = Math.ceil(avgFee * 1.2); // Add 20% margin
      
      console.log(`Calculated priority fee: ${recommendedFee} lamports`);
      return recommendedFee;
    } catch (error) {
      console.error("Error getting priority fee estimate:", error);
      // Default to 10000 lamports if there's an error
      return 10000;
    }
  }

  // Stop monitoring (for cleanup)
  public stopMonitoring(): void {
    // Stop HTTP polling
    if (this.monitorInterval) {
      clearInterval(this.monitorInterval);
      this.monitorInterval = null;
    }
    
    // Stop WebSocket reconnect attempts
    if (this.wsReconnectInterval) {
      clearInterval(this.wsReconnectInterval);
      this.wsReconnectInterval = null;
    }
    
    // Close WebSocket connection
    if (this.wsConnection) {
      this.wsConnection.close();
      this.wsConnection = null;
    }
    
    this.isMonitoring = false;
    console.log("Stopped all Solana transaction monitoring");
  }
}

// Export the singleton instance
export const solanaMonitor = SolanaMonitor.getInstance();