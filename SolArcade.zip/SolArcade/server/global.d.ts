import { EventEmitter } from 'events';
import { Server as SocketIOServer } from 'socket.io';
import WebSocket from 'ws';

declare global {
  var eventEmitter: EventEmitter;
  var io: SocketIOServer;
  var wss: WebSocket.Server;
  var completedTransactions: Array<{
    walletAddress: string;
    pongCredits: number;
    signature: string;
    timestamp: number;
  }>;
}