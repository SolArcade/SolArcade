import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertTransactionSchema } from "@shared/schema";
import { Connection, PublicKey, Keypair, SystemProgram, Transaction, LAMPORTS_PER_SOL } from "@solana/web3.js";
import { solanaMonitor } from "./solanaMonitor";

interface GameRoom {
  id: string;
  players: WebSocket[];
  playerWallets: PublicKey[];
  stake: number;
  gameState: {
    ball: { x: number; y: number; dx: number; dy: number; };
    paddles: { p1: number; p2: number; };
    score: { p1: number; p2: number; };
    lastScorer?: number; // 1 for player 1, 2 for player 2
    lastDirection?: string; // 'left' or 'right' - used to alternate ball direction
    countdownActive?: boolean; // Whether the round countdown is active
  };
}

const gameRooms = new Map<string, GameRoom>();

// Pending search map to track players who are waiting for matches 
// and their stake amounts for refunds in case of disconnection
interface PendingPlayer {
  wallet: string;
  stake: number;
  stakeCredits: number; // Number of credits staked
  timestamp: number;
}
const pendingPlayers = new Map<WebSocket, PendingPlayer>();

export async function registerRoutes(app: Express): Promise<Server> {
  // Regular transaction API endpoint (for non-purchase transactions)
  app.post("/api/transactions", async (req, res) => {
    try {
      const data = insertTransactionSchema.parse(req.body);
      console.log('Creating transaction:', JSON.stringify(data));

      const transaction = await storage.createTransaction({
        ...data,
        amount: Number(data.amount),
        pongCredits: Number(data.pongCredits)
      });

      console.log('Transaction created:', JSON.stringify(transaction));
      res.json(transaction);
    } catch (error) {
      console.error('Transaction creation error:', error);
      res.status(400).json({ error: error instanceof Error ? error.message : "Invalid transaction data" });
    }
  });
  
  // New endpoint specifically for verifying Solana transactions and crediting pong credits
  app.post("/api/verify-purchase", async (req, res) => {
    try {
      const { signature, walletAddress, amount, credits, preSubmissionId } = req.body;
      
      if (!signature || !walletAddress || !amount) {
        return res.status(400).json({ error: "Missing required fields" });
      }
      
      // Determine credits based on amount if not explicitly provided
      let creditAmount = credits;
      if (!creditAmount) {
        if (amount === 0.01) creditAmount = 1;
        else if (amount === 0.1) creditAmount = 10; 
        else if (amount === 1.0) creditAmount = 100;
        else {
          return res.status(400).json({ error: "Invalid amount. Must be one of: 0.01, 0.1, or 1.0" });
        }
      }
      
      console.log(`Verifying purchase: ${signature} from ${walletAddress} for ${amount} SOL (${creditAmount} credits)`);
      
      try {
        // First, check if transaction is already being tracked by the monitor
        const txStatus = await solanaMonitor.getTransactionStatus(signature);
        
        if (txStatus === "pending") {
          // If it's already being monitored, let the client know to check back later
          return res.json({ 
            success: true, 
            status: "pending", 
            message: "Transaction is being processed" 
          });
        }
        
        // Verify the transaction on Solana
        const transactionDetails = await connection.getTransaction(signature, {
          commitment: "confirmed",
        });
        
        if (!transactionDetails) {
          // If transaction not found, add it to the monitor for continuous checking
          // This is the key improvement - we'll keep checking for this transaction
          // Use preSubmissionId if available (for tracking across page refreshes)
          solanaMonitor.trackTransaction(
            signature, 
            walletAddress, 
            Number(amount), 
            Number(creditAmount),
            preSubmissionId
          );
          
          return res.json({ 
            success: true, 
            status: "tracking", 
            message: "Transaction is being tracked and will be credited when confirmed",
            signature,
            preSubmissionId
          });
        }
        
        // Make sure it's a successful transaction
        if (transactionDetails.meta?.err) {
          return res.status(400).json({ error: "Transaction failed on Solana" });
        }
        
        // If we got this far, the transaction exists and is confirmed
        // We can add the credits immediately
        const transaction = await storage.createTransaction({
          walletAddress,
          amount: Number(amount),
          status: 'completed',
          timestamp: new Date().toISOString(),
          pongCredits: Number(creditAmount),
          transactionSignature: signature,
          preSubmissionId: preSubmissionId,
          expectedCredits: Number(creditAmount)
        });
        
        console.log('Purchase verified and credits added:', JSON.stringify(transaction));
        res.json({ 
          success: true, 
          status: "completed", 
          transaction,
          signature,
          preSubmissionId
        });
        
      } catch (error) {
        console.error('Error verifying Solana transaction:', error);
        
        // Even if verification fails, add it to the monitor for continuous checking
        // Use preSubmissionId if available (for tracking across page refreshes)
        solanaMonitor.trackTransaction(
          signature, 
          walletAddress, 
          Number(amount), 
          Number(creditAmount),
          preSubmissionId
        );
        
        // Let the client know we're tracking it
        return res.json({ 
          success: true, 
          status: "tracking", 
          message: "Transaction verification failed, but it will be monitored and credited when confirmed",
          signature,
          preSubmissionId
        });
      }
    } catch (error) {
      console.error('Transaction verification error:', error);
      res.status(400).json({ error: error instanceof Error ? error.message : "Invalid verification data" });
    }
  });
  
  // Endpoint to check transaction status
  app.get("/api/transaction-status/:signature", async (req, res) => {
    try {
      const { signature } = req.params;
      
      if (!signature) {
        return res.status(400).json({ error: "Missing transaction signature" });
      }
      
      // Get status from the Solana monitor
      const status = await solanaMonitor.getTransactionStatus(signature);
      
      res.json({ status });
    } catch (error) {
      console.error('Error checking transaction status:', error);
      res.status(500).json({ error: "Failed to check transaction status" });
    }
  });
  
  // Endpoint to get recommended priority fee
  app.get("/api/priority-fee", async (req, res) => {
    try {
      const priorityFee = await solanaMonitor.getPriorityFeeEstimate();
      res.json({ priorityFee });
    } catch (error) {
      console.error('Error getting priority fee estimate:', error);
      res.status(500).json({ error: "Failed to get priority fee estimate", priorityFee: 10000 });
    }
  });
  
  // Create a pre-submission transaction record
  app.post("/api/pre-submit-transaction", async (req, res) => {
    try {
      const { walletAddress, amount } = req.body;
      
      if (!walletAddress || !amount) {
        return res.status(400).json({ error: "Missing required fields" });
      }
      
      // Determine credits based on amount
      let credits = 0;
      if (amount === 0.01) credits = 1;
      else if (amount === 0.1) credits = 10; 
      else if (amount === 1.0) credits = 100;
      else {
        return res.status(400).json({ error: "Invalid amount. Must be one of: 0.01, 0.1, or 1.0" });
      }
      
      // Create a pre-submission transaction record in memory
      const id = solanaMonitor.createPreSubmissionTransaction(walletAddress, amount, credits);
      
      console.log(`Created pre-submission transaction ${id} for wallet ${walletAddress}`);
      
      // Also create a database record with the pre-submission ID
      try {
        const transaction = await storage.createTransaction({
          walletAddress,
          amount: amount,
          status: 'pending',
          timestamp: new Date().toISOString(),
          pongCredits: 0, // No credits awarded yet
          preSubmissionId: id,
          expectedCredits: credits
        });
        
        console.log(`Database record created for pre-submission transaction ${id}`);
      } catch (dbError) {
        console.error('Failed to create database record for pre-submission:', dbError);
        // Continue even if database entry fails - the solanaMonitor still has the record
      }
      
      res.json({ 
        id, 
        status: "pre_submission", 
        message: "Transaction recorded before submission. Use this ID when submitting the transaction.",
        credits 
      });
    } catch (error) {
      console.error('Pre-submission transaction error:', error);
      res.status(400).json({ error: error instanceof Error ? error.message : "Invalid transaction data" });
    }
  });
  
  // Get pending transactions for a wallet
  app.get("/api/pending-transactions/:walletAddress", async (req, res) => {
    try {
      const { walletAddress } = req.params;
      
      if (!walletAddress) {
        return res.status(400).json({ error: "Missing wallet address" });
      }
      
      // Get in-memory pending transactions from Solana monitor
      const monitorPendingTransactions = solanaMonitor.getPendingTransactions(walletAddress);
      
      // Get pending transactions from database
      const dbPendingTransactions = await storage.getPendingTransactionsByWallet(walletAddress);
      
      // Convert DB transactions to the same format as monitor transactions
      const formattedDbTransactions = dbPendingTransactions
        .filter(tx => tx.status !== 'completed') // Filter out completed transactions
        .map(tx => ({
          id: tx.preSubmissionId || `db-${tx.id}`,
          walletAddress: tx.walletAddress,
          amount: parseFloat(tx.amount.toString()),
          credits: tx.expectedCredits || 0,
          timestamp: new Date(tx.timestamp).getTime(),
          status: tx.status
        }));
      
      // Combine both sources, avoiding duplicates by ID
      const combinedTransactions = [...monitorPendingTransactions];
      
      // Add DB transactions if they don't already exist in the monitor's list
      for (const dbTx of formattedDbTransactions) {
        // Skip if this transaction is already in the monitor's list
        if (!combinedTransactions.some(tx => 
          tx.id === dbTx.id || 
          (tx.id === `db-${dbTx.id}`) ||
          (dbTx.id === `db-${tx.id}`)
        )) {
          combinedTransactions.push(dbTx);
        }
      }
      
      // Remove any old transactions (older than 1 hour)
      const oneHourAgo = Date.now() - (60 * 60 * 1000);
      const filteredTransactions = combinedTransactions.filter(tx => tx.timestamp > oneHourAgo);
      
      console.log(`Found ${filteredTransactions.length} pending transactions for wallet ${walletAddress}`);
      res.json(filteredTransactions);
    } catch (error) {
      console.error('Error getting pending transactions:', error);
      res.status(500).json({ error: "Failed to get pending transactions" });
    }
  });

  app.get("/api/transactions/:walletAddress", async (req, res) => {
    try {
      console.log('Fetching transactions for wallet:', req.params.walletAddress);
      const transactions = await storage.getTransactionsByWallet(
        req.params.walletAddress
      );
      console.log('Retrieved transactions:', JSON.stringify(transactions));
      res.json(transactions);
    } catch (error) {
      console.error('Transaction fetch error:', error);
      res.status(500).json({ error: "Failed to fetch transactions" });
    }
  });

  const httpServer = createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Initialize Solana connection
  const connection = new Connection(process.env.QUICKNODE_RPC_URL!, "confirmed");

  // House wallet setup
  let houseKeypair: Keypair;
  try {
    const privateKey = process.env.HOUSE_WALLET_PRIVATE_KEY;
    if (!privateKey) {
      throw new Error("House wallet private key not found");
    }
    const secretKey = new Uint8Array(JSON.parse(privateKey));
    houseKeypair = Keypair.fromSecretKey(secretKey);
  } catch (error) {
    console.error('Failed to initialize house wallet:', error);
    throw new Error('House wallet setup failed');
  }

  wss.on('connection', (ws: WebSocket) => {
    console.log('New WebSocket connection established');

    ws.on('message', (message: string) => {
      try {
        const data = JSON.parse(message.toString());
        console.log('Received game message:', data);
        handleGameMessage(ws, data);
      } catch (e) {
        console.error('Failed to parse message:', e);
      }
    });

    ws.on('close', () => {
      console.log('WebSocket connection closed');
      handlePlayerDisconnect(ws);
    });
  });

  function handleGameMessage(ws: WebSocket, data: any) {
    console.log('Processing game message:', data.type);

    switch (data.type) {
      case 'join':
        console.log('Player joining game with stake:', data.stake);
        matchPlayer(ws, data);
        break;
      case 'paddle_move':
        updatePaddlePosition(ws, data.position);
        break;
      case 'cancel_search':
        console.log('Player canceling search');
        cancelPlayerSearch(ws);
        break;
    }
  }
  
  // Function to handle cancellation of game search
  function cancelPlayerSearch(ws: WebSocket) {
    // Remove the player from any game rooms they might be in
    let roomRemoved = false;
    Array.from(gameRooms.entries()).forEach(([roomId, room]) => {
      // Look for rooms with only this player (they were waiting for an opponent)
      if (room.players.length === 1 && room.players[0] === ws) {
        console.log(`Removing search-state game room ${roomId} for player who canceled search`);
        gameRooms.delete(roomId);
        roomRemoved = true;
      }
    });
    
    if (roomRemoved) {
      console.log('Successfully removed matchmaking session for player');
    }
    
    // Also remove from pending players list if they're in it
    // (refund is handled by the client in this case)
    if (pendingPlayers.has(ws)) {
      console.log('Removing player from pending players list');
      pendingPlayers.delete(ws);
    }
  }

  function matchPlayer(ws: WebSocket, data: { type: string; stake: number; wallet: string }) {
    let matched = false;
    
    // Get stake in terms of credits based on SOL value
    let stakeCredits = 0;
    if (data.stake === 0.01) stakeCredits = 1;
    else if (data.stake === 0.1) stakeCredits = 10;
    else if (data.stake === 1.0) stakeCredits = 100;
    
    // First, add this player to the pending players map
    pendingPlayers.set(ws, {
      wallet: data.wallet,
      stake: data.stake,
      stakeCredits: stakeCredits,
      timestamp: Date.now()
    });
    
    // Convert Map.entries() to Array for iteration to avoid LSP errors
    Array.from(gameRooms.entries()).forEach(([roomId, room]) => {
      if (room.players.length === 1 && room.stake === data.stake && !matched) {
        console.log('Matching player to existing room:', roomId);
        room.players.push(ws);
        room.playerWallets.push(new PublicKey(data.wallet));
        matched = true;
        
        // Game is starting, remove both players from pending list
        pendingPlayers.delete(ws);
        pendingPlayers.delete(room.players[0]);
        
        startGame(roomId);
      }
    });

    if (!matched) {
      const roomId = Math.random().toString(36).substring(7);
      console.log('Creating new game room:', roomId);
      gameRooms.set(roomId, {
        id: roomId,
        players: [ws],
        playerWallets: [new PublicKey(data.wallet)],
        stake: data.stake,
        gameState: initGameState()
      });
      ws.send(JSON.stringify({ type: 'waiting' }));
      
      // Player is still in pending state until matched
      // pendingPlayers already updated above
    }
  }

  function initGameState() {
    return {
      ball: { x: 400, y: 300, dx: 5, dy: 5 },
      paddles: { p1: 250, p2: 250 },
      score: { p1: 0, p2: 0 },
      countdownActive: false,
      lastDirection: 'right' // Initial direction
    };
  }

  function startGame(roomId: string) {
    const room = gameRooms.get(roomId);
    if (!room) return;

    room.players.forEach((player, index) => {
      player.send(JSON.stringify({
        type: 'game_start',
        playerNumber: index + 1
      }));
    });

    gameLoop(roomId);
  }

  function gameLoop(roomId: string) {
    const room = gameRooms.get(roomId);
    if (!room) return;

    updateGameState(room);

    const gameState = room.gameState;
    room.players.forEach(player => {
      if (player.readyState === WebSocket.OPEN) {
        player.send(JSON.stringify({
          type: 'game_state',
          state: gameState
        }));
      }
    });

    setTimeout(() => gameLoop(roomId), 1000 / 60);
  }

  function updateGameState(room: GameRoom) {
    const { ball, paddles, score, countdownActive } = room.gameState;

    // Don't move the ball during countdown
    if (!countdownActive) {
      ball.x += ball.dx;
      ball.y += ball.dy;

      if (ball.y <= 0 || ball.y >= 600) {
        ball.dy *= -1;
      }

      if (ball.x <= 30 && ball.y >= paddles.p1 && ball.y <= paddles.p1 + 100) {
        ball.dx *= -1;
      }
      if (ball.x >= 770 && ball.y >= paddles.p2 && ball.y <= paddles.p2 + 100) {
        ball.dx *= -1;
      }

      if (ball.x <= 0) {
        score.p2++;
        room.gameState.lastScorer = 2;
        resetBall(room, ball);
        checkGameEnd(room);
      }
      if (ball.x >= 800) {
        score.p1++;
        room.gameState.lastScorer = 1;
        resetBall(room, ball);
        checkGameEnd(room);
      }
    }
  }

  // Update game end score to 12 and alternate ball direction after each score
  function resetBall(room: GameRoom, ball: any) {
    ball.x = 400;
    ball.y = 300;
    
    // Alternate direction after each score, regardless of who scored
    if (!room.gameState.lastDirection || room.gameState.lastDirection === 'left') {
      // If last direction was left or undefined, go right
      ball.dx = 5;  // Send ball right
      room.gameState.lastDirection = 'right';
    } else {
      // If last direction was right, go left
      ball.dx = -5; // Send ball left
      room.gameState.lastDirection = 'left';
    }
    
    // Randomize vertical direction
    ball.dy = Math.random() > 0.5 ? 5 : -5;
    
    // Set countdown active
    room.gameState.countdownActive = true;
    startRound(room); // Start the countdown after reset
  }

  async function checkGameEnd(room: GameRoom) {
    if (room.gameState.score.p1 >= 12 || room.gameState.score.p2 >= 12) {
      const winner = room.gameState.score.p1 >= 12 ? 0 : 1;
      
      // Notify players about game outcome
      room.players.forEach((player, index) => {
        if (player.readyState === WebSocket.OPEN) {
          player.send(JSON.stringify({
            type: 'game_over',
            winner: index === winner
          }));
        }
      });
      
      // Process the winnings payout
      const success = await processWinningsPayout(room, winner);
      
      // Remove the room to prevent multiple payments
      gameRooms.delete(room.id);
    }
  }

  // Add round start countdown
  function startRound(room: GameRoom) {
    let countdown = 3;
    
    // Stop ball movement during countdown
    room.gameState.countdownActive = true;
    
    const countdownInterval = setInterval(() => {
      room.players.forEach(player => {
        if (player.readyState === WebSocket.OPEN) {
          player.send(JSON.stringify({
            type: 'countdown',
            count: countdown
          }));
        }
      });
      countdown--;

      if (countdown < 0) {
        clearInterval(countdownInterval);
        // Resume ball movement after countdown
        room.gameState.countdownActive = false;
        room.players.forEach(player => {
          if (player.readyState === WebSocket.OPEN) {
            player.send(JSON.stringify({
              type: 'round_start'
            }));
          }
        });
      }
    }, 1000);
  }

  function updatePaddlePosition(ws: WebSocket, position: number) {
    Array.from(gameRooms.values()).some(room => {
      const playerIndex = room.players.indexOf(ws);
      if (playerIndex !== -1) {
        if (playerIndex === 0) {
          room.gameState.paddles.p1 = position;
        } else {
          room.gameState.paddles.p2 = position;
        }
        return true; // Break the loop once we found and updated the player
      }
      return false;
    });
  }

  async function handlePlayerDisconnect(ws: WebSocket) {
    // First, check if the player is in a pending search state
    // If so, refund their credits and remove them from the pending list
    const pendingPlayer = pendingPlayers.get(ws);
    if (pendingPlayer) {
      console.log(`Player disconnected while searching for a game. Refunding ${pendingPlayer.stakeCredits} credits.`);
      
      try {
        // Process credit refund
        await storage.createTransaction({
          walletAddress: pendingPlayer.wallet,
          amount: 0, // No SOL amount for credit refund
          status: 'completed',
          timestamp: new Date().toISOString(),
          pongCredits: pendingPlayer.stakeCredits // Refund the credits
        });
        
        console.log(`Successfully refunded ${pendingPlayer.stakeCredits} credits to wallet ${pendingPlayer.wallet}`);
      } catch (error) {
        console.error('Failed to process credit refund:', error);
      }
      
      // Remove from pending players list
      pendingPlayers.delete(ws);
      
      // Also need to remove the game room associated with this player 
      // so they don't get placed in a game after reconnecting
      let roomRemoved = false;
      Array.from(gameRooms.entries()).forEach(([roomId, room]) => {
        // Look for rooms with only this player (they were waiting for an opponent)
        if (room.players.length === 1 && room.players[0] === ws) {
          console.log(`Removing search-state game room ${roomId} for disconnected player`);
          gameRooms.delete(roomId);
          roomRemoved = true;
        }
      });
      
      if (roomRemoved) {
        console.log('Successfully removed matchmaking session for disconnected player');
      }
      
      // If we've handled a pending player, no need to continue checking active game rooms
      return;
    }
    
    // Second, check if the player is in an active game
    Array.from(gameRooms.entries()).some(([roomId, room]) => {
      const playerIndex = room.players.indexOf(ws);
      if (playerIndex !== -1) {
        console.log(`Player ${playerIndex + 1} disconnected from room ${roomId}`);
        
        // The player who disconnected is at playerIndex
        // The other player (who's still connected) is the winner
        const remainingPlayerIndex = playerIndex === 0 ? 1 : 0;
        const remainingPlayer = room.players[remainingPlayerIndex];
        
        // Make sure the remaining player is still connected
        if (remainingPlayer && remainingPlayer.readyState === WebSocket.OPEN) {
          console.log(`Player ${remainingPlayerIndex + 1} wins by default due to disconnect`);
          
          // Send win notification to the remaining player
          remainingPlayer.send(JSON.stringify({ 
            type: 'game_over',
            winner: true,
            winReason: 'disconnect', 
            message: 'You win! Your opponent disconnected.'
          }));
          
          // Process the winnings asynchronously (with delay to ensure disconnect handling completes)
          setTimeout(async () => {
            try {
              console.log(`Processing disconnect winnings for player ${remainingPlayerIndex + 1}`);
              
              // Get winner wallet
              const winnerWallet = room.playerWallets[remainingPlayerIndex];
              if (!winnerWallet) {
                console.error('Winner wallet not found for index:', remainingPlayerIndex);
                throw new Error('Winner wallet not found');
              }
              
              // Calculate winnings amount
              const winAmount = room.stake * 1.5;
              
              let signature = '';
              
              try {
                // Attempt to send actual SOL to the winner using the house wallet
                console.log(`Attempting real Solana transaction from house wallet to ${winnerWallet.toString()} for disconnect win`);
                
                // Create a Solana transaction
                const transaction = new Transaction().add(
                  SystemProgram.transfer({
                    fromPubkey: houseKeypair.publicKey,
                    toPubkey: winnerWallet,
                    lamports: Math.floor(winAmount * LAMPORTS_PER_SOL), // Convert SOL to lamports
                  })
                );
                
                // Set a recent blockhash
                transaction.recentBlockhash = (await connection.getLatestBlockhash()).blockhash;
                transaction.feePayer = houseKeypair.publicKey;
                
                // Sign transaction with the house wallet
                transaction.sign(houseKeypair);
                
                // Send and confirm transaction
                signature = await connection.sendRawTransaction(transaction.serialize());
                await connection.confirmTransaction(signature, 'confirmed');
                
                console.log(`Disconnect Solana transaction successful! Signature: ${signature}`);
              } catch (txError) {
                console.error('Disconnect Solana transaction failed:', txError);
                // Fallback to simulated transaction if real transaction fails
                signature = `simulated-transaction-${Date.now()}-disconnect`;
                console.log(`Falling back to simulated transaction with ID: ${signature}`);
              }
              
              // Record transaction in database regardless of whether it was real or simulated
              await storage.createTransaction({
                walletAddress: winnerWallet.toString(),
                amount: winAmount,
                status: 'completed',
                timestamp: new Date().toISOString(),
                pongCredits: 0
              });
              
              console.log(`Disconnect transaction recorded in database for ${winnerWallet.toString()}`);
              
              // Directly send payout notification to avoid dependencies on room state
              if (remainingPlayer.readyState === WebSocket.OPEN) {
                console.log(`Sending disconnect payout notification for ${winAmount} SOL`);
                
                remainingPlayer.send(JSON.stringify({
                  type: 'payout_complete',
                  winnings: winAmount,
                  signature: signature
                }));
                
                // Also send backup notification
                setTimeout(() => {
                  if (remainingPlayer.readyState === WebSocket.OPEN) {
                    remainingPlayer.send(JSON.stringify({
                      type: 'payout_notification',
                      winnings: winAmount,
                      signature: signature
                    }));
                  }
                }, 1000);
                
                console.log(`Disconnect payout notifications sent successfully`);
              } else {
                console.log(`Remaining player no longer connected`);
              }
              
            } catch (error) {
              console.error('Error in disconnect payout processing:', error);
              // Attempt to notify player about the error
              if (remainingPlayer.readyState === WebSocket.OPEN) {
                remainingPlayer.send(JSON.stringify({
                  type: 'error',
                  message: 'Failed to process winnings due to an unexpected error.'
                }));
              }
            }
          }, 1500);
        } else {
          console.log(`No remaining players in room ${roomId}, simply cleaning up`);
        }
        
        // Remove the game room
        console.log(`Deleting game room ${roomId}`);
        gameRooms.delete(roomId);
        return true; // Break the loop once we found and processed the disconnect
      }
      return false;
    });
  }
  
  // Helper function to process payout (extracted from checkGameEnd to avoid code duplication)
  async function processWinningsPayout(room: GameRoom, winnerIndex: number) {
    try {
      // Get the winner's wallet
      const winnerWallet = room.playerWallets[winnerIndex];
      if (!winnerWallet) {
        console.error('Winner wallet not found for index:', winnerIndex);
        throw new Error('Winner wallet not found');
      }
      
      console.log(`Processing payout to wallet: ${winnerWallet.toString()}`);
      console.log(`Stake amount: ${room.stake} SOL`);
      
      // Calculate amount (stake amount in SOL + 50% bonus for the winner)
      const winAmount = room.stake * 1.5;
      
      let signature = '';
      
      try {
        // Attempt to send actual SOL to the winner using the house wallet
        console.log(`Attempting real Solana transaction from house wallet to ${winnerWallet.toString()}`);
        
        // Create a Solana transaction
        const transaction = new Transaction().add(
          SystemProgram.transfer({
            fromPubkey: houseKeypair.publicKey,
            toPubkey: winnerWallet,
            lamports: Math.floor(winAmount * LAMPORTS_PER_SOL), // Convert SOL to lamports
          })
        );
        
        // Set a recent blockhash
        transaction.recentBlockhash = (await connection.getLatestBlockhash()).blockhash;
        transaction.feePayer = houseKeypair.publicKey;
        
        // Sign transaction with the house wallet
        transaction.sign(houseKeypair);
        
        // Send and confirm transaction
        signature = await connection.sendRawTransaction(transaction.serialize());
        await connection.confirmTransaction(signature, 'confirmed');
        
        console.log(`Solana transaction successful! Signature: ${signature}`);
      } catch (txError) {
        console.error('Solana transaction failed:', txError);
        // Fallback to simulated transaction if real transaction fails
        signature = `simulated-transaction-${Date.now().toString()}`;
        console.log(`Falling back to simulated transaction with ID: ${signature}`);
      }
      
      // Record transaction in database regardless of whether it was real or simulated
      await storage.createTransaction({
        walletAddress: winnerWallet.toString(),
        amount: winAmount,
        status: 'completed',
        timestamp: new Date().toISOString(),
        pongCredits: 0
      });
      
      console.log(`Transaction recorded in database for ${winnerWallet.toString()}`);
      
      // Notify the winner about their winnings
      const winnerPlayer = room.players[winnerIndex];
      if (winnerPlayer && winnerPlayer.readyState === WebSocket.OPEN) {
        console.log(`Sending payout notification to winner (${winnerIndex}) with amount ${winAmount} SOL`);
        
        // First send a separate message to ensure it gets through
        winnerPlayer.send(JSON.stringify({
          type: 'payout_complete',
          winnings: winAmount,
          signature: signature
        }));
        
        // Also notify through game_over message as a backup
        setTimeout(() => {
          if (winnerPlayer.readyState === WebSocket.OPEN) {
            winnerPlayer.send(JSON.stringify({
              type: 'payout_notification',
              winnings: winAmount,
              signature: signature
            }));
          }
        }, 1000); // Send after a short delay to ensure they're processed separately
        
        console.log(`Payout notification sent to winner (${winnerIndex})`);
      } else {
        console.log(`Winner player (${winnerIndex}) not available or not connected`);
      }
      
      return true;
    } catch (error) {
      console.error('Failed to process winnings:', error);
      
      // Try to notify players about the error
      try {
        room.players.forEach((player, idx) => {
          if (player && player.readyState === WebSocket.OPEN) {
            player.send(JSON.stringify({
              type: 'error',
              message: 'Failed to process winnings. Please contact support.'
            }));
            console.log(`Error notification sent to player ${idx}`);
          }
        });
      } catch (notifyError) {
        console.error('Failed to notify players about error:', notifyError);
      }
      
      return false;
    }
  }

  return httpServer;
}