import { 
  transactions,
  users,
  type Transaction, 
  type InsertTransaction,
  type User,
  type InsertUser
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, isNull, not } from "drizzle-orm";
import { sql } from "drizzle-orm/sql";

export interface IStorage {
  // Transaction methods
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getTransactionsByWallet(walletAddress: string): Promise<Transaction[]>;
  getPendingTransactionsByWallet(walletAddress: string): Promise<Transaction[]>;
  getTransactionBySignature(signature: string): Promise<Transaction | null>;
  getTransactionByPreSubmissionId(preSubmissionId: string): Promise<Transaction | null>;
  updateTransactionSignature(id: number, signature: string): Promise<Transaction | null>;
  updateTransactionStatus(id: number, status: string): Promise<Transaction | null>;
  getTransactionsByGameId(gameId: string): Promise<Transaction[]>;
  
  // User methods
  getUserByWallet(walletAddress: string): Promise<User | null>;
  createUser(userData: InsertUser): Promise<User>;
  updateUserGameStats(walletAddress: string, gameWon: boolean, stakeAmount: number, winAmount: number): Promise<User | null>;
}

export class DatabaseStorage implements IStorage {
  /**
   * Updates a user's game statistics
   * @param walletAddress The wallet address of the user
   * @param gameWon Whether the user won the game
   * @param stakeAmount The amount of SOL staked in the game
   * @param winAmount The amount of SOL won in the game (0 if lost)
   * @returns The updated user object or null if update failed
   */
  async updateUserGameStats(walletAddress: string, gameWon: boolean, stakeAmount: number, winAmount: number): Promise<User | null> {
    try {
      console.log(`Updating game stats for wallet ${walletAddress}: won=${gameWon}, stake=${stakeAmount}, winnings=${winAmount}`);
      
      // First check if the user exists
      const existingUser = await this.getUserByWallet(walletAddress);
      
      if (!existingUser) {
        // Create new user if not exists
        const newUser = await this.createUser({
          walletAddress,
          gamesPlayed: 1,
          gamesWon: gameWon ? 1 : 0,
          totalStaked: stakeAmount,
          totalWon: gameWon ? winAmount : 0,
          lastUpdated: new Date().toISOString()
        });
        return newUser;
      }
      
      // Update existing user's stats
      const [updatedUser] = await db
        .update(users)
        .set({
          gamesPlayed: sql`${users.gamesPlayed} + 1`,
          gamesWon: gameWon ? sql`${users.gamesWon} + 1` : users.gamesWon,
          totalStaked: sql`${users.totalStaked} + ${stakeAmount.toString()}`,
          totalWon: gameWon ? sql`${users.totalWon} + ${winAmount.toString()}` : users.totalWon,
          lastUpdated: new Date().toISOString()
        })
        .where(eq(users.walletAddress, walletAddress))
        .returning();

      return updatedUser || null;
    } catch (error) {
      console.error('Error updating user game stats:', error);
      throw new Error(`Failed to update user game stats: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  // Transaction methods
  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    try {
      console.log('Creating transaction with data:', JSON.stringify(insertTransaction));
      
      const [transaction] = await db
        .insert(transactions)
        .values({
          ...insertTransaction,
          amount: insertTransaction.amount.toString(), // Convert number to string for NUMERIC column
          processingAttempts: insertTransaction.processingAttempts || 0,
          lastProcessingTimestamp: insertTransaction.lastProcessingTimestamp || new Date().toISOString()
        })
        .returning();

      if (!transaction) {
        throw new Error('Failed to create transaction: No transaction returned');
      }

      console.log('Created transaction:', JSON.stringify(transaction));
      return transaction;
    } catch (error) {
      console.error('Error creating transaction:', error);
      throw new Error(`Failed to create transaction: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getTransactionsByWallet(walletAddress: string): Promise<Transaction[]> {
    try {
      console.log('Fetching transactions for wallet:', walletAddress);
      const result = await db
        .select()
        .from(transactions)
        .where(eq(transactions.walletAddress, walletAddress))
        .orderBy(desc(transactions.timestamp)); // Order by timestamp descending (newest first)

      return result || [];
    } catch (error) {
      console.error('Error fetching transactions:', error);
      throw new Error(`Failed to fetch transactions: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getPendingTransactionsByWallet(walletAddress: string): Promise<Transaction[]> {
    try {
      console.log('Fetching pending transactions for wallet:', walletAddress);
      const result = await db
        .select()
        .from(transactions)
        .where(
          and(
            eq(transactions.walletAddress, walletAddress),
            not(eq(transactions.status, 'completed')),
            not(eq(transactions.status, 'failed'))
          )
        )
        .orderBy(desc(transactions.timestamp)); // Order by timestamp descending

      return result || [];
    } catch (error) {
      console.error('Error fetching pending transactions:', error);
      throw new Error(`Failed to fetch pending transactions: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getTransactionBySignature(signature: string): Promise<Transaction | null> {
    try {
      console.log('Fetching transaction by signature:', signature);
      const [result] = await db
        .select()
        .from(transactions)
        .where(eq(transactions.transactionSignature, signature));

      return result || null;
    } catch (error) {
      console.error('Error fetching transaction by signature:', error);
      throw new Error(`Failed to fetch transaction by signature: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getTransactionByPreSubmissionId(preSubmissionId: string): Promise<Transaction | null> {
    try {
      console.log('Fetching transaction by pre-submission ID:', preSubmissionId);
      const [result] = await db
        .select()
        .from(transactions)
        .where(eq(transactions.preSubmissionId, preSubmissionId));

      return result || null;
    } catch (error) {
      console.error('Error fetching transaction by pre-submission ID:', error);
      throw new Error(`Failed to fetch transaction by pre-submission ID: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async updateTransactionSignature(id: number, signature: string): Promise<Transaction | null> {
    try {
      console.log(`Updating transaction ${id} with signature: ${signature}`);
      const [updated] = await db
        .update(transactions)
        .set({
          transactionSignature: signature,
          status: 'submitted',
          lastProcessingTimestamp: new Date().toISOString()
        })
        .where(eq(transactions.id, id))
        .returning();

      return updated || null;
    } catch (error) {
      console.error('Error updating transaction signature:', error);
      throw new Error(`Failed to update transaction signature: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async updateTransactionStatus(id: number, status: string): Promise<Transaction | null> {
    try {
      console.log(`Updating transaction ${id} status to: ${status}`);
      const [updated] = await db
        .update(transactions)
        .set({
          status,
          lastProcessingTimestamp: new Date().toISOString(),
          processingAttempts: sql`${transactions.processingAttempts} + 1`
        })
        .where(eq(transactions.id, id))
        .returning();

      return updated || null;
    } catch (error) {
      console.error('Error updating transaction status:', error);
      throw new Error(`Failed to update transaction status: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // User methods
  async getUserByWallet(walletAddress: string): Promise<User | null> {
    try {
      console.log('Fetching user by wallet address:', walletAddress);
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.walletAddress, walletAddress));

      return user || null;
    } catch (error) {
      console.error('Error fetching user:', error);
      throw new Error(`Failed to fetch user: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async createUser(userData: InsertUser): Promise<User> {
    try {
      console.log('Creating user with data:', JSON.stringify(userData));
      
      // Convert numeric values to strings for database
      const processedData = {
        walletAddress: userData.walletAddress,
        gamesPlayed: userData.gamesPlayed || 0,
        gamesWon: userData.gamesWon || 0,
        totalStaked: typeof userData.totalStaked === 'number' ? userData.totalStaked.toString() : userData.totalStaked || "0",
        totalWon: typeof userData.totalWon === 'number' ? userData.totalWon.toString() : userData.totalWon || "0",
        lastUpdated: userData.lastUpdated
      };
      
      const [user] = await db
        .insert(users)
        .values(processedData)
        .returning();

      if (!user) {
        throw new Error('Failed to create user: No user returned');
      }

      console.log('Created user:', JSON.stringify(user));
      return user;
    } catch (error) {
      console.error('Error creating user:', error);
      throw new Error(`Failed to create user: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getTransactionsByGameId(gameId: string): Promise<Transaction[]> {
    try {
      console.log('Fetching transactions for game:', gameId);
      const result = await db
        .select()
        .from(transactions)
        .where(eq(transactions.gameId, gameId))
        .orderBy(desc(transactions.timestamp));

      return result || [];
    } catch (error) {
      console.error('Error fetching transactions by game ID:', error);
      throw new Error(`Failed to fetch transactions by game ID: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
}

export const storage = new DatabaseStorage();