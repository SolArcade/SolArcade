import { Connection, PublicKey, Finality, SignatureResult, TransactionError, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { WalletContextState } from '@solana/wallet-adapter-react';
import { Socket } from 'socket.io-client';
import { getSocket, subscribeToTransaction } from './client/src/lib/socketClient';

/**
 * Interface for transactions pending confirmation and credit award
 */
interface PendingTransaction {
  signature: string;
  amount: number;
  pongCredits: number;
  timestamp: number;
  lastChecked?: number;
  retryCount?: number;
  status?: string;
}

/**
 * Transaction data structure for API interactions
 */
interface TransactionData {
  signature: string;
  walletAddress: string;
  amount: number;
  pongCredits: number;
  status: string;
  timestamp: string;
  processedAt?: string | null;
  error?: string;
  preSubmissionId?: string;
}

/**
 * Enhanced TransactionPersistence class with robust persistence mechanisms
 * for handling Solana transactions across page refreshes and network interruptions
 */
class TransactionPersistence {
  private connection: Connection;
  private wallet: WalletContextState;
  private socket: Socket | null = null;
  private pendingTransactions: PendingTransaction[];
  private localStorageKey = 'sol_arcade_pending_transactions';
  private pollingInterval: NodeJS.Timeout | null = null;
  private commitment: Finality = 'finalized';
  private maxRetries = 10;
  private checkIntervalMs = 10000; // 10 seconds between checks
  private isCheckingTransactions = false;
  
  /**
   * Constructor initializes the transaction persistence system
   * @param connection - Solana connection object
   * @param wallet - Wallet context state from wallet adapter
   * @param db - Optional database parameter (no longer used, kept for compatibility)
   */
  constructor(connection: Connection, wallet: WalletContextState, _unused?: any) {
    this.connection = connection;
    this.wallet = wallet;
    this.pendingTransactions = [];
    
    // Load pending transactions from localStorage
    this._loadFromStorage();
    
    // Initialize socket connection
    try {
      this.socket = getSocket();
    } catch (err) {
      console.error('Failed to initialize socket connection:', err);
    }
    
    // Start transaction monitoring system
    this._startTracking();
    
    // Log initialization
    console.log('TransactionPersistence system initialized');
    console.log(`Loaded ${this.pendingTransactions.length} pending transactions from storage`);
  }
  
  /**
   * Load pending transactions from localStorage
   * Enhanced with better error handling and format validation
   */
  async _loadFromStorage(): Promise<void> {
    try {
      // Retrieve transactions from localStorage
      const stored = localStorage.getItem(this.localStorageKey);
      if (!stored) {
        this.pendingTransactions = [];
        return;
      }
      
      // Parse and validate the stored data
      const parsed = JSON.parse(stored);
      if (!Array.isArray(parsed)) {
        console.error('Invalid storage format - expected array');
        this.pendingTransactions = [];
        return;
      }
      
      // Filter out invalid transactions and add default properties
      this.pendingTransactions = parsed
        .filter(tx => tx && tx.signature && typeof tx.amount === 'number')
        .map(tx => ({
          ...tx,
          retryCount: tx.retryCount || 0,
          lastChecked: tx.lastChecked || 0,
          status: tx.status || 'pending'
        }));
      
      console.log(`Successfully loaded ${this.pendingTransactions.length} pending transactions from localStorage`);
      
      // After loading from localStorage, check if we have any incomplete transactions
      // that need recovery
      if (this.pendingTransactions.length > 0 && this.wallet.publicKey) {
        await this._recoverIncompleteTransactions();
      }
    } catch (error) {
      console.error('Error loading from localStorage:', error);
      this.pendingTransactions = [];
    }
  }
  
  /**
   * Recover incomplete transactions after page refresh or disconnect
   * This ensures credits are awarded even if user refreshed or disconnected
   */
  private async _recoverIncompleteTransactions(): Promise<void> {
    try {
      console.log(`Starting recovery check for ${this.pendingTransactions.length} pending transactions`);
      
      // Get all local pending transactions
      const localPendingTxs = [...this.pendingTransactions];
      
      // Get pending transactions from server if wallet is connected
      let serverPendingTxs: PendingTransaction[] = [];
      if (this.wallet.publicKey) {
        try {
          const response = await fetch(`/api/transactions/pending/${this.wallet.publicKey.toString()}`);
          if (response.ok) {
            const serverTxs = await response.json();
            serverPendingTxs = serverTxs.map((tx: any) => ({
              signature: tx.transactionSignature,
              amount: parseFloat(tx.amount),
              pongCredits: tx.pongCredits,
              timestamp: new Date(tx.timestamp).getTime(),
              status: tx.status,
            }));
          }
        } catch (fetchError) {
          console.error('Error fetching server pending transactions:', fetchError);
        }
      }
      
      // Combine signatures from both sources
      const allSignatures = new Set<string>();
      
      // Add local transactions
      localPendingTxs.forEach((tx: PendingTransaction) => {
        if (tx.signature) {
          allSignatures.add(tx.signature);
        }
      });
      
      // Add server transactions
      serverPendingTxs.forEach((tx: PendingTransaction) => {
        if (tx.signature) {
          allSignatures.add(tx.signature);
        }
      });
      
      console.log(`Combined ${allSignatures.size} unique transactions to check`);
      
      // Now check each transaction on the blockchain
      // Convert Set to Array for compatibility with all TypeScript targets
      for (const signature of Array.from(allSignatures)) {
        try {
          console.log(`Checking status of transaction ${signature} for recovery`);
          
          // Check transaction status on blockchain
          const status = await this.connection.getSignatureStatus(signature, {
            searchTransactionHistory: true
          });
          
          // If transaction not found
          if (!status || !status.value) {
            console.log(`Transaction ${signature} not found on chain during recovery check`);
            continue;
          }
          
          // If transaction failed (with null check for safety)
          if (status.value && status.value.err) {
            console.error(`Transaction ${signature} failed on chain during recovery check:`, status.value.err);
            
            // Remove from pending if it failed
            this._removeFromPending(signature);
            continue;
          }
          
          // Transaction exists and succeeded, check if it's confirmed (with null check for safety)
          if (status.value && status.value.confirmationStatus === this.commitment) {
            console.log(`Found confirmed transaction ${signature} during recovery`);
            
            // Find transaction amount - first try local pending list
            let amount = 0;
            const localTx = localPendingTxs.find((localTx: PendingTransaction) => localTx.signature === signature);
            if (localTx) {
              amount = localTx.amount;
            } else {
              // If not in local list, try server list
              const serverTx = serverPendingTxs.find((serverTx: PendingTransaction) => serverTx.signature === signature);
              if (serverTx) {
                amount = serverTx.amount;
              } else {
                // Need to query blockchain for amount if not found locally
                try {
                  const txDetails = await this.connection.getTransaction(signature, {
                    commitment: this.commitment,
                    maxSupportedTransactionVersion: 0
                  });
                  
                  if (txDetails && txDetails.meta) {
                    // Try to determine amount from transaction data
                    amount = Math.abs(txDetails.meta.preBalances[0] - txDetails.meta.postBalances[0]) / LAMPORTS_PER_SOL;
                  }
                } catch (txError) {
                  console.error(`Error getting transaction details during recovery:`, txError);
                }
              }
            }
            
            if (amount) {
              // Process the transaction to issue credits
              await this._processTransaction(signature, amount);
            } else {
              console.warn(`Cannot recover transaction ${signature}: unknown amount`);
            }
          }
        } catch (error) {
          console.error(`Error recovering transaction ${signature}:`, error);
        }
      }
      
      console.log('Transaction recovery check completed');
    } catch (error) {
      console.error('Error in transaction recovery:', error);
    }
  }
  
  /**
   * Save pending transactions to localStorage
   * Enhanced with error handling and data validation
   */
  _saveToStorage(): void {
    try {
      // Validate transactions before saving
      const validTransactions = this.pendingTransactions.filter(tx => 
        tx && tx.signature && typeof tx.amount === 'number' && typeof tx.timestamp === 'number'
      );
      
      // Save to localStorage
      localStorage.setItem(this.localStorageKey, JSON.stringify(validTransactions));
      
      console.log(`Saved ${validTransactions.length} pending transactions to localStorage`);
    } catch (error) {
      console.error('Error saving to storage:', error);
    }
  }
  
  /**
   * Start background tracking and monitoring of transactions
   * Enhanced with socket connections and optimized polling
   */
  async _startTracking(): Promise<void> {
    console.log('Starting transaction tracking system...');
    
    // Process any pending transactions immediately
    await this._checkAllPendingTransactions();
    
    // Set up polling interval for transaction checking
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
    }
    
    this.pollingInterval = setInterval(() => {
      if (!this.isCheckingTransactions) {
        this._checkAllPendingTransactions();
      }
    }, this.checkIntervalMs);
    
    // Listen for transaction updates via socket
    if (this.socket) {
      console.log('Setting up socket listeners for transactions');
      
      // Subscribe to transaction updates for all pending transactions
      this.pendingTransactions.forEach(tx => {
        if (this.socket) {
          this.socket.emit('subscribe:transaction', tx.signature);
          
          // Also set up subscription via the client-side helper
          subscribeToTransaction(tx.signature);
        }
      });
    }
    
    console.log('Transaction tracking system started');
  }
  
  /**
   * Track a new transaction - main entry point
   * Enhanced with pre-allocated credits and better error handling
   */
  async trackTransaction(signature: string, amount: number, preSubmissionId?: string): Promise<number> {
    try {
      console.log(`Tracking new transaction ${signature} for ${amount} SOL`);
      
      // Calculate pong credits
      const pongCredits = Math.floor(amount * 100);
      
      // Check if already tracking this transaction
      const existing = this.pendingTransactions.find(tx => tx.signature === signature);
      if (existing) {
        console.log(`Already tracking transaction ${signature}`);
        return existing.pongCredits;
      }
      
      // Add to pending transactions
      const newTransaction: PendingTransaction = {
        signature,
        amount,
        pongCredits,
        timestamp: Date.now(),
        lastChecked: 0,
        retryCount: 0,
        status: 'pending'
      };
      
      this.pendingTransactions.push(newTransaction);
      this._saveToStorage();
      
      // Subscribe to this transaction via socket
      if (this.socket) {
        this.socket.emit('subscribe:transaction', signature);
        subscribeToTransaction(signature);
      }
      
      // Record in server via API
      await this._recordTransactionInServer(signature, amount, pongCredits, preSubmissionId);
      
      // Start monitoring via direct connection
      this._monitorTransaction(signature, amount);
      
      // Return expected credits so UI can show pending amount
      return pongCredits;
    } catch (error) {
      console.error(`Error tracking transaction ${signature}:`, error);
      
      // Still add to pending even if server recording failed
      const pongCredits = Math.floor(amount * 100);
      this.pendingTransactions.push({
        signature,
        amount,
        pongCredits,
        timestamp: Date.now(),
        retryCount: 0,
        status: 'pending'
      });
      this._saveToStorage();
      
      return pongCredits;
    }
  }
  
  /**
   * Record transaction in server database via API
   */
  private async _recordTransactionInServer(
    signature: string, 
    amount: number, 
    pongCredits: number,
    preSubmissionId?: string
  ): Promise<void> {
    if (!this.wallet.publicKey) {
      console.error('Cannot record transaction: wallet not connected');
      return;
    }
    
    try {
      const walletAddress = this.wallet.publicKey.toString();
      
      const response = await fetch('/api/transactions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          walletAddress,
          amount,
          pongCredits,
          transactionSignature: signature,
          status: 'pending',
          timestamp: new Date().toISOString(),
          preSubmissionId
        })
      });
      
      if (!response.ok) {
        throw new Error(`Server responded with ${response.status}: ${response.statusText}`);
      }
      
      console.log(`Successfully recorded transaction ${signature} in server database`);
    } catch (error) {
      console.error(`Error recording transaction in server:`, error);
      // Transaction will still be tracked locally even if server recording fails
    }
  }
  
  /**
   * Monitor a transaction for confirmation - optimized for speed
   */
  async _monitorTransaction(signature: string, amount: number): Promise<void> {
    try {
      console.log(`Monitoring transaction ${signature} with amount ${amount}`);
      
      // Check initial status to detect quick confirmations
      await this._checkTransactionStatus(signature, amount);
      
      // Immediate check would have removed from pending if completed
      // so if it's still pending, set up additional listeners
      const stillPending = this.pendingTransactions.find(tx => tx.signature === signature);
      if (!stillPending) {
        console.log(`Transaction ${signature} already processed`);
        return;
      }
      
      try {
        // Attempt a websocket-based approach first (faster)
        // WebSocket monitor automatically calls _processTransaction when confirmed
        console.log(`Setting up confirmation listener for ${signature}`);
        
        // Use the browser's websocket connection
        if (this.connection.commitment !== this.commitment) {
          console.log(`Note: Connection commitment is ${this.connection.commitment}, but we're using ${this.commitment}`);
        }
        
        // Set up a confirmation listener that works alongside our polling system
        const subId = this.connection.onSignatureWithOptions(
          signature,
          (notification, context) => {
            if ('err' in notification && notification.err) {
              console.error(`Transaction ${signature} failed:`, notification.err);
              this._markTransactionFailed(signature, notification.err);
            } else {
              console.log(`Transaction ${signature} received confirmation notification`);
              this._processTransaction(signature, amount);
            }
          },
          { commitment: this.commitment }
        );
        
        // The websocket listener is a backup; we still check via polling
        console.log(`WebSocket confirmation subscription set up for ${signature}`);
      } catch (wsError) {
        console.warn(`WebSocket monitoring failed for ${signature}, falling back to polling:`, wsError);
        // Polling will continue via the interval set up in _startTracking
      }
      
    } catch (error) {
      console.error(`Error setting up monitoring for ${signature}:`, error);
      // This transaction will be picked up by the periodic checks
    }
  }
  
  /**
   * Check all pending transactions from both memory and localStorage
   */
  async _checkAllPendingTransactions(): Promise<void> {
    if (this.isCheckingTransactions || this.pendingTransactions.length === 0) {
      return;
    }
    
    this.isCheckingTransactions = true;
    console.log(`Checking ${this.pendingTransactions.length} pending transactions...`);
    
    try {
      // First make a copy to avoid mutation issues during iteration
      const transactions = [...this.pendingTransactions];
      
      // Schedule them to be checked with a slight delay between each
      // This avoids overwhelming the RPC endpoint
      for (const tx of transactions) {
        await this._checkTransactionStatus(tx.signature, tx.amount);
        
        // Small delay between checks
        await new Promise(resolve => setTimeout(resolve, 200));
      }
      
      // Also check for any pending transactions in the server database
      if (this.wallet.publicKey) {
        await this._checkServerPendingTransactions();
      }
    } catch (error) {
      console.error('Error checking pending transactions:', error);
    } finally {
      this.isCheckingTransactions = false;
    }
  }
  
  /**
   * Check pending transactions stored in the server database
   */
  async _checkServerPendingTransactions(): Promise<void> {
    if (!this.wallet.publicKey) return;
    
    try {
      const walletAddress = this.wallet.publicKey.toString();
      
      // Fetch pending transactions from the server
      const response = await fetch(`/api/transactions/pending/${walletAddress}`);
      
      if (!response.ok) {
        console.error(`Failed to fetch pending transactions: ${response.statusText}`);
        return;
      }
      
      const pendingTxs = await response.json();
      console.log(`Found ${pendingTxs.length} pending transactions in server database`);
      
      // Process each pending transaction
      for (const tx of pendingTxs) {
        // Skip if we're already tracking it locally
        if (this.pendingTransactions.some(localTx => localTx.signature === tx.transactionSignature)) {
          continue;
        }
        
        // Parse amount from string to number
        const amount = parseFloat(tx.amount);
        
        // Add to local tracking
        console.log(`Adding server transaction ${tx.transactionSignature} to local tracking`);
        this.pendingTransactions.push({
          signature: tx.transactionSignature,
          amount,
          pongCredits: tx.pongCredits,
          timestamp: new Date(tx.timestamp).getTime(),
          lastChecked: 0,
          retryCount: 0,
          status: 'pending'
        });
        
        // Check it immediately
        await this._checkTransactionStatus(tx.transactionSignature, amount);
      }
      
      // Save updated pending transactions
      this._saveToStorage();
      
    } catch (error) {
      console.error('Error checking server pending transactions:', error);
    }
  }
  
  /**
   * Check transaction status directly from blockchain
   * Enhanced with retry counting and status tracking
   */
  async _checkTransactionStatus(signature: string, amount: number): Promise<void> {
    // Find the transaction in our pending list
    const txIndex = this.pendingTransactions.findIndex(tx => tx.signature === signature);
    if (txIndex === -1) {
      console.log(`Transaction ${signature} not found in pending list`);
      return;
    }
    
    // Update last checked timestamp and retry count
    const tx = this.pendingTransactions[txIndex];
    const now = Date.now();
    
    this.pendingTransactions[txIndex] = {
      ...tx,
      lastChecked: now,
      retryCount: (tx.retryCount || 0) + 1,
      status: 'checking'
    };
    
    // Skip if retried too many times
    if ((tx.retryCount || 0) > this.maxRetries) {
      console.log(`Transaction ${signature} exceeded max retries, marking as stale`);
      this.pendingTransactions[txIndex].status = 'stale';
      this._saveToStorage();
      return;
    }
    
    try {
      console.log(`Checking status of transaction ${signature}...`);
      
      // Check transaction status on blockchain
      const status = await this.connection.getSignatureStatus(
        signature, 
        { searchTransactionHistory: true }
      );
      
      // If transaction not found
      if (!status || !status.value) {
        console.log(`Transaction ${signature} not found on chain yet (retry ${tx.retryCount}/${this.maxRetries})`);
        this.pendingTransactions[txIndex].status = 'pending';
        this._saveToStorage();
        return;
      }
      
      // If transaction failed (with null check for safety)
      if (status.value.err) {
        console.error(`Transaction ${signature} failed on chain:`, status.value.err);
        await this._markTransactionFailed(signature, status.value.err);
        return;
      }
      
      // Check confirmation status (with null check for safety)
      if (status.value.confirmationStatus === this.commitment) {
        console.log(`Transaction ${signature} is confirmed on chain with ${this.commitment} commitment`);
        await this._processTransaction(signature, amount);
      } else {
        console.log(`Transaction ${signature} is on chain but not ${this.commitment} yet (current: ${status.value.confirmationStatus})`);
        this.pendingTransactions[txIndex].status = 'confirming';
        this._saveToStorage();
      }
    } catch (error) {
      console.error(`Error checking transaction ${signature}:`, error);
      // Keep in pending list for next retry
      this.pendingTransactions[txIndex].status = 'pending';
      this._saveToStorage();
    }
  }
  
  /**
   * Process a confirmed transaction and award pong credits
   * Enhanced with robust error handling and transaction verification
   */
  async _processTransaction(signature: string, amount: number): Promise<boolean> {
    try {
      console.log(`Processing confirmed transaction ${signature} for ${amount} SOL`);
      
      // Find in pending list
      const tx = this.pendingTransactions.find(t => t.signature === signature);
      if (!tx) {
        console.warn(`Transaction ${signature} not found in pending list`);
        return false;
      }
      
      // Extract the pong credits value
      const pongCredits = tx.pongCredits || Math.floor(amount * 100);
      
      // Notify server that this transaction is confirmed and should issue pong credits
      try {
        const response = await fetch('/api/transactions/process', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            signature,
            walletAddress: this.wallet.publicKey?.toString(),
            amount,
            pongCredits
          })
        });
        
        if (!response.ok) {
          console.error(`Server failed to process transaction: ${response.status}`);
          return false;
        }
        
        const result = await response.json();
        
        if (result.success) {
          console.log(`Server successfully processed transaction ${signature}`);
          
          // Remove from pending
          this._removeFromPending(signature);
          
          // Dispatch event to update UI
          try {
            const creditEvent = new CustomEvent('pongCreditsUpdated', {
              detail: { amount: pongCredits, signature }
            });
            window.dispatchEvent(creditEvent);
            
            const txEvent = new CustomEvent('transactionCompleted', {
              detail: { signature, amount, pongCredits }
            });
            window.dispatchEvent(txEvent);
            
            // Also update via the global method if available
            if (window.updatePongCreditsUI) {
              window.updatePongCreditsUI(pongCredits);
            }
          } catch (eventError) {
            console.error('Error dispatching credit update event:', eventError);
          }
          
          return true;
        } else {
          console.error(`Server failed to process transaction: ${result.message}`);
          return false;
        }
      } catch (serverError) {
        console.error(`Error communicating with server:`, serverError);
        return false;
      }
    } catch (error) {
      console.error(`Error processing transaction ${signature}:`, error);
      return false;
    }
  }
  
  /**
   * Mark a transaction as failed and remove from pending
   */
  async _markTransactionFailed(signature: string, error: any): Promise<void> {
    try {
      console.log(`Marking transaction ${signature} as failed:`, error);
      
      // Notify server that transaction failed
      try {
        await fetch('/api/transactions/failed', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            signature,
            error: typeof error === 'object' ? JSON.stringify(error) : String(error)
          })
        });
      } catch (serverError) {
        console.error(`Error notifying server of transaction failure:`, serverError);
      }
      
      // Remove from pending list
      this._removeFromPending(signature);
      
      // Dispatch event for UI update
      try {
        const failEvent = new CustomEvent('transactionFailed', {
          detail: { 
            signature, 
            error: typeof error === 'object' ? JSON.stringify(error) : String(error)
          }
        });
        window.dispatchEvent(failEvent);
      } catch (eventError) {
        console.error('Error dispatching transaction failed event:', eventError);
      }
    } catch (err) {
      console.error(`Error marking transaction as failed:`, err);
    }
  }
  
  /**
   * Remove transaction from pending list
   */
  _removeFromPending(signature: string): void {
    this.pendingTransactions = this.pendingTransactions.filter(tx => tx.signature !== signature);
    this._saveToStorage();
    console.log(`Removed transaction ${signature} from pending list`);
  }
  
  /**
   * Get pending transactions for UI display
   */
  getPendingTransactions(): PendingTransaction[] {
    return [...this.pendingTransactions];
  }
  
  /**
   * Clean up resources when component unmounts
   */
  cleanup(): void {
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
      this.pollingInterval = null;
    }
    
    console.log('TransactionPersistence cleanup completed');
  }
}

export default TransactionPersistence;