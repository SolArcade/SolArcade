import { Connection, PublicKey } from '@solana/web3.js';
import { WalletContextState } from '@solana/wallet-adapter-react';
import { Firestore, doc, setDoc, getDoc, updateDoc, query, collection, where, getDocs } from 'firebase/firestore';

interface PendingTransaction {
  signature: string;
  amount: number;
  pongCredits: number;
  timestamp: number;
}

interface TransactionData {
  signature: string;
  walletAddress: string;
  amount: number;
  pongCredits: number;
  status: string;
  createdAt: string;
  processedAt: string | null;
  error?: string;
}

class TransactionPersistence {
  private connection: Connection;
  private wallet: WalletContextState;
  private db: Firestore;
  private pendingTransactions: PendingTransaction[];
  private commitment: 'finalized' | 'confirmed' | 'processed';
  
  constructor(connection: Connection, wallet: WalletContextState, db: Firestore) {
    this.connection = connection;
    this.wallet = wallet;
    this.db = db;
    this.pendingTransactions = [];
    this.commitment = 'finalized';
    
    // Load any pending transactions from localStorage
    this._loadFromStorage();
    
    // Start tracking immediately
    this._startTracking();
  }
  
  async _loadFromStorage(): Promise<void> {
    try {
      const stored = localStorage.getItem('pendingTransactions');
      this.pendingTransactions = stored ? JSON.parse(stored) : [];
      console.log(`Loaded ${this.pendingTransactions.length} pending transactions from storage`);
    } catch (error) {
      console.error('Error loading from storage:', error);
      this.pendingTransactions = [];
    }
  }
  
  _saveToStorage(): void {
    try {
      localStorage.setItem('pendingTransactions', JSON.stringify(this.pendingTransactions));
    } catch (error) {
      console.error('Error saving to storage:', error);
    }
  }
  
  async _startTracking(): Promise<void> {
    // Process any pending transactions from previous sessions
    if (this.pendingTransactions.length > 0) {
      console.log('Processing pending transactions from previous session');
      
      for (const tx of this.pendingTransactions) {
        await this._checkTransaction(tx.signature, tx.amount);
      }
    }
    
    // Set up periodic check for database transactions
    setInterval(() => this._checkDatabaseTransactions(), 60000); // every minute
    this._checkDatabaseTransactions(); // immediate check
  }
  
  // Main method to track a transaction
  async trackTransaction(signature: string, amount: number): Promise<number> {
    try {
      console.log(`Tracking transaction ${signature} for ${amount} SOL`);
      
      // Calculate expected pong credits
      const pongCredits = Math.floor(amount * 100);
      
      // Store in memory
      this.pendingTransactions.push({
        signature,
        amount,
        pongCredits,
        timestamp: Date.now()
      });
      
      // Save to localStorage
      this._saveToStorage();
      
      // Store in Firestore
      const txData: TransactionData = {
        signature,
        walletAddress: this.wallet.publicKey!.toString(),
        amount,
        pongCredits,
        status: 'PENDING',
        createdAt: new Date().toISOString(),
        processedAt: null
      };
      
      await setDoc(doc(this.db, 'solTransactions', signature), txData);
      
      // Begin monitoring
      this._monitorTransaction(signature, amount);
      
      return pongCredits;
    } catch (error) {
      console.error('Error tracking transaction:', error);
      return Math.floor(amount * 100); // Still return expected credits
    }
  }
  
  // Monitor a specific transaction
  async _monitorTransaction(signature: string, amount: number): Promise<void> {
    try {
      console.log(`Monitoring transaction ${signature}`);
      
      // Wait for confirmation with finalized commitment
      const confirmation = await this.connection.confirmTransaction(
        signature, 
        this.commitment
      );
      
      if (confirmation.value.err) {
        console.error(`Transaction failed: ${confirmation.value.err}`);
        return;
      }
      
      console.log(`Transaction ${signature} confirmed with finalized commitment`);
      
      // Process the confirmed transaction
      await this._processTransaction(signature, amount);
    } catch (error) {
      console.error(`Error monitoring transaction ${signature}:`, error);
      // Will be picked up by the reconciliation process
    }
  }
  
  // Check transaction status directly from blockchain
  async _checkTransaction(signature: string, amount: number): Promise<void> {
    try {
      console.log(`Checking transaction ${signature} status`);
      
      // First check if it's already processed
      const txDoc = await getDoc(doc(this.db, 'solTransactions', signature));
      if (txDoc.exists() && txDoc.data().status === 'PROCESSED') {
        console.log(`Transaction ${signature} already processed`);
        this._removeFromPending(signature);
        return;
      }
      
      // Check status on blockchain
      const status = await this.connection.getSignatureStatus(
        signature,
        { searchTransactionHistory: true }
      );
      
      if (!status || !status.value) {
        console.log(`Transaction ${signature} not found on chain yet`);
        return;
      }
      
      if (status.value.err) {
        console.error(`Transaction ${signature} failed on chain: ${status.value.err}`);
        await this._markTransactionFailed(signature, status.value.err);
        return;
      }
      
      if (status.value.confirmationStatus === this.commitment) {
        console.log(`Transaction ${signature} is confirmed on chain`);
        await this._processTransaction(signature, amount);
      } else {
        console.log(`Transaction ${signature} is on chain but not finalized yet`);
      }
    } catch (error) {
      console.error(`Error checking transaction ${signature}:`, error);
    }
  }
  
  // Process and award pong credits
  async _processTransaction(signature: string, amount: number): Promise<boolean> {
    try {
      console.log(`Processing transaction ${signature} for credits`);
      
      // Double-check if already processed (prevent double crediting)
      const txDoc = await getDoc(doc(this.db, 'solTransactions', signature));
      if (txDoc.exists() && txDoc.data().status === 'PROCESSED') {
        console.log(`Transaction ${signature} already processed, skipping`);
        this._removeFromPending(signature);
        return false;
      }
      
      // Calculate credits
      const pongCredits = Math.floor(amount * 100);
      
      // Get user document
      const userAddress = this.wallet.publicKey!.toString();
      const userDoc = doc(this.db, 'users', userAddress);
      const userSnapshot = await getDoc(userDoc);
      
      // Create user if doesn't exist
      if (!userSnapshot.exists()) {
        await setDoc(userDoc, {
          walletAddress: userAddress,
          pongCredits: 0,
          createdAt: new Date().toISOString()
        });
      }
      
      // Get current credits
      const userData = userSnapshot.exists() ? userSnapshot.data() : { pongCredits: 0 };
      const currentCredits = userData.pongCredits || 0;
      
      // Update user's credits
      await updateDoc(userDoc, {
        pongCredits: currentCredits + pongCredits,
        updatedAt: new Date().toISOString()
      });
      
      // Mark transaction as processed
      await updateDoc(doc(this.db, 'solTransactions', signature), {
        status: 'PROCESSED',
        processedAt: new Date().toISOString()
      });
      
      console.log(`Awarded ${pongCredits} pong credits for transaction ${signature}`);
      
      // Remove from pending list
      this._removeFromPending(signature);
      
      // Trigger UI update using custom event system (more reliable)
      try {
        // Dispatch event using Window event system (preferred)
        const creditUpdateEvent = new CustomEvent('pongCreditsUpdated', {
          detail: {
            credits: currentCredits + pongCredits,
            added: pongCredits,
            signature
          }
        });
        window.dispatchEvent(creditUpdateEvent);
        console.log(`Dispatched pongCreditsUpdated event with total: ${currentCredits + pongCredits}`);
        
        // Also use the legacy method as fallback
        if ((window as any).updatePongCreditsUI) {
          console.log(`Using legacy updatePongCreditsUI with value: ${currentCredits + pongCredits}`);
          (window as any).updatePongCreditsUI(currentCredits + pongCredits);
        }
        
        // Also show any pending transaction in UI
        if ((window as any).showPendingTransaction) {
          console.log(`Calling legacy showPendingTransaction for ${signature}`);
          (window as any).showPendingTransaction(signature, amount, pongCredits);
        }
        
        // Make API call to ensure PostgreSQL database is updated
        try {
          // Get API base URL from current location
          const baseUrl = window.location.origin;
          const apiUrl = `${baseUrl}/api/user/${userAddress}/update-credits`;
          
          // Send update to server
          const response = await fetch(apiUrl, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              walletAddress: userAddress,
              creditsDelta: pongCredits,
              signature
            })
          });
          
          if (response.ok) {
            console.log(`Successfully updated PostgreSQL database with credits: ${pongCredits}`);
          } else {
            console.error(`Failed to update PostgreSQL database: ${response.statusText}`);
          }
        } catch (apiError) {
          console.error('Error updating PostgreSQL via API:', apiError);
        }
      } catch (eventError) {
        console.error('Error dispatching credit update event:', eventError);
      }
      
      // Also make a server request to ensure PostgreSQL is updated as well
      try {
        // Call server API to record transaction in PostgreSQL
        const serverResponse = await fetch('/api/credit-transaction', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            walletAddress: userAddress,
            amount,
            pongCredits,
            transactionSignature: signature,
            status: 'completed'
          })
        });
        
        if (!serverResponse.ok) {
          console.error(`Server transaction recording failed: ${serverResponse.statusText}`);
        } else {
          console.log('Transaction also recorded in server database');
        }
      } catch (serverError) {
        console.error('Error recording transaction in server:', serverError);
        // Continue anyway - Firebase update was successful
      }
      
      return true;
    } catch (error) {
      console.error(`Error processing transaction ${signature}:`, error);
      return false;
    }
  }
  
  // Mark a transaction as failed
  async _markTransactionFailed(signature: string, error: any): Promise<void> {
    try {
      await updateDoc(doc(this.db, 'solTransactions', signature), {
        status: 'FAILED',
        error: typeof error === 'object' ? JSON.stringify(error) : String(error),
        updatedAt: new Date().toISOString()
      });
      
      this._removeFromPending(signature);
    } catch (err) {
      console.error(`Error marking transaction ${signature} as failed:`, err);
    }
  }
  
  // Remove transaction from pending list
  _removeFromPending(signature: string): void {
    this.pendingTransactions = this.pendingTransactions.filter(tx => tx.signature !== signature);
    this._saveToStorage();
  }
  
  // Check database for any pending transactions
  async _checkDatabaseTransactions(): Promise<void> {
    try {
      if (!this.wallet || !this.wallet.publicKey) return;
      
      const userAddress = this.wallet.publicKey.toString();
      
      // Query for pending transactions for this user
      const q = query(
        collection(this.db, 'solTransactions'),
        where('walletAddress', '==', userAddress),
        where('status', '==', 'PENDING')
      );
      
      const querySnapshot = await getDocs(q);
      
      console.log(`Found ${querySnapshot.size} pending transactions in database`);
      
      for (const doc of querySnapshot.docs) {
        const tx = doc.data();
        await this._checkTransaction(tx.signature, tx.amount);
      }
    } catch (error) {
      console.error('Error checking database transactions:', error);
    }
  }
}

export default TransactionPersistence;