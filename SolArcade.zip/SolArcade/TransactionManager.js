import { doc, setDoc, getDoc, updateDoc, query, collection, where, getDocs } from 'firebase/firestore';

/**
 * Enhanced transaction manager with robust debugging
 * and direct blockchain verification
 */
class TransactionManager {
  constructor(connection, wallet, db) {
    this.connection = connection;
    this.wallet = wallet;
    this.db = db;
    this.pendingTransactions = [];
    
    // Important: Use 'confirmed' first for speed, then verify 'finalized'
    this.initialCommitment = 'confirmed';
    this.finalCommitment = 'finalized';
    
    // Debug mode - leave enabled to diagnose issues
    this.debugMode = true;
    
    this._log("Transaction Manager initializing...");
    this._loadFromStorage();
    
    // Start checking immediately and periodically
    this._startPeriodicChecking();
  }
  
  /**
   * Enhanced logging for diagnosing issues
   */
  _log(message, data = null) {
    if (this.debugMode) {
      const timestamp = new Date().toISOString();
      const formattedMsg = `[TxManager ${timestamp}] ${message}`;
      
      if (data) {
        console.log(formattedMsg, data);
      } else {
        console.log(formattedMsg);
      }
      
      // Add to debug log in localStorage for persistence
      try {
        const logs = JSON.parse(localStorage.getItem('txDebugLogs') || '[]');
        logs.push({ time: timestamp, msg: message, data: data ? JSON.stringify(data) : null });
        if (logs.length > 100) logs.shift(); // Keep last 100 logs
        localStorage.setItem('txDebugLogs', JSON.stringify(logs));
      } catch (e) {
        // Silent catch - don't break on logging error
      }
    }
  }
  
  /**
   * Error logging with persistence
   */
  _logError(message, error) {
    console.error(`[TxManager] ${message}`, error);
    
    // Store errors for debugging
    try {
      const errors = JSON.parse(localStorage.getItem('txErrors') || '[]');
      errors.push({
        time: new Date().toISOString(),
        message,
        error: error?.toString() || "Unknown error",
        stack: error?.stack
      });
      if (errors.length > 50) errors.shift(); // Keep last 50 errors
      localStorage.setItem('txErrors', JSON.stringify(errors));
    } catch (e) {
      // Silent catch
    }
  }
  
  /**
   * Load pending transactions from localStorage
   */
  _loadFromStorage() {
    try {
      const stored = localStorage.getItem('pendingTransactions');
      this.pendingTransactions = stored ? JSON.parse(stored) : [];
      this._log(`Loaded ${this.pendingTransactions.length} pending transactions from storage`);
    } catch (error) {
      this._logError('Error loading from storage', error);
      this.pendingTransactions = [];
    }
  }
  
  /**
   * Save pending transactions to localStorage
   */
  _saveToStorage() {
    try {
      this._log(`Saving ${this.pendingTransactions.length} pending transactions to storage`);
      localStorage.setItem('pendingTransactions', JSON.stringify(this.pendingTransactions));
    } catch (error) {
      this._logError('Error saving to storage', error);
    }
  }
  
  /**
   * Start periodic checking for transactions
   */
  _startPeriodicChecking() {
    // Process existing pending transactions immediately
    this._checkAllPendingTransactions();
    
    // Set up periodic checks every 15 seconds
    const FIFTEEN_SECONDS = 15 * 1000;
    this.checkingInterval = setInterval(() => {
      this._checkAllPendingTransactions();
    }, FIFTEEN_SECONDS);
    
    this._log("Periodic transaction checking started");
  }
  
  /**
   * Check all pending transactions from both sources
   */
  async _checkAllPendingTransactions() {
    this._log("Checking all pending transactions");
    
    // First check localStorage transactions
    const localPromises = this.pendingTransactions.map(tx => 
      this._verifyAndProcessTransaction(tx.signature, tx.amount)
    );
    
    // Also check database for any transactions we don't have locally
    try {
      await this._checkDatabaseTransactions();
    } catch (error) {
      this._logError("Error checking database transactions", error);
    }
    
    // Wait for all local checks to complete
    try {
      await Promise.allSettled(localPromises);
    } catch (error) {
      this._logError("Error processing local transactions", error);
    }
    
    this._log("Finished checking all pending transactions");
  }
  
  /**
   * Track a new transaction - main entry point
   */
  async trackTransaction(signature, amount) {
    this._log(`Tracking new transaction: ${signature} for ${amount} SOL`);
    
    try {
      // Calculate expected pong credits
      const pongCredits = Math.floor(amount * 100);
      
      // Create transaction data
      const txData = {
        signature,
        walletAddress: this.wallet.publicKey.toString(),
        amount: Number(amount),
        pongCredits,
        status: 'PENDING',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        processedAt: null,
        retryCount: 0
      };
      
      // Store in memory and localStorage
      this.pendingTransactions.push({
        signature,
        amount: Number(amount),
        pongCredits,
        timestamp: Date.now()
      });
      this._saveToStorage();
      
      // Store in Firestore - use transaction ID as document ID
      try {
        this._log(`Saving transaction to Firestore: ${signature}`);
        await setDoc(doc(this.db, 'solTransactions', signature), txData);
      } catch (dbError) {
        this._logError(`Failed to save transaction to Firestore: ${signature}`, dbError);
        // Continue - we've saved to localStorage as backup
      }
      
      // Start monitoring with initial (faster) commitment level
      this._monitorTransaction(signature, amount);
      
      // Show in UI if possible
      if (typeof window.showPendingTransaction === 'function') {
        window.showPendingTransaction(signature, amount, pongCredits);
      }
      
      // Immediately trigger UI update for pending state
      const pendingEvent = new CustomEvent('transactionPending', {
        detail: { signature, amount, pongCredits }
      });
      window.dispatchEvent(pendingEvent);
      
      return pongCredits;
    } catch (error) {
      this._logError(`Error tracking transaction: ${signature}`, error);
      return Math.floor(amount * 100); // Return expected credits anyway
    }
  }
  
  /**
   * Monitor a transaction for confirmation - optimized for speed
   */
  async _monitorTransaction(signature, amount) {
    this._log(`Started monitoring transaction: ${signature}`);
    
    try {
      // First wait for initial confirmation (faster)
      this._log(`Waiting for initial confirmation of transaction: ${signature}`);
      const initialConfirmation = await this.connection.confirmTransaction(
        signature, 
        this.initialCommitment
      );
      
      if (initialConfirmation.value?.err) {
        this._logError(`Transaction failed during initial confirmation: ${signature}`, initialConfirmation.value.err);
        await this._markTransactionFailed(signature, initialConfirmation.value.err);
        return;
      }
      
      this._log(`Transaction received initial confirmation: ${signature}`);
      
      // Update in Firestore
      try {
        await updateDoc(doc(this.db, 'solTransactions', signature), {
          status: 'CONFIRMING',
          updatedAt: new Date().toISOString()
        });
      } catch (dbError) {
        this._logError(`Failed to update transaction status in Firestore: ${signature}`, dbError);
      }
      
      // Now wait for finality (more secure)
      this._log(`Waiting for finality of transaction: ${signature}`);
      
      // Here use a timeout to limit the waiting time
      const THIRTY_SECONDS = 30 * 1000;
      
      const finalityPromise = this.connection.confirmTransaction(
        signature, 
        this.finalCommitment
      );
      
      // Create a timeout promise
      const timeoutPromise = new Promise((resolve, reject) => {
        setTimeout(() => resolve({
          context: { slot: 0 },
          value: { err: null }
        }), THIRTY_SECONDS);
      });
      
      // Race the promises - either get confirmation or timeout
      const finalConfirmation = await Promise.race([finalityPromise, timeoutPromise]);
      
      if (finalConfirmation.value?.err) {
        this._logError(`Transaction failed during finality: ${signature}`, finalConfirmation.value.err);
        await this._markTransactionFailed(signature, finalConfirmation.value.err);
        return;
      }
      
      // Process the transaction - even if we timed out, we'll verify status first
      this._log(`Transaction ready for processing: ${signature}`);
      await this._verifyAndProcessTransaction(signature, amount);
    } catch (error) {
      this._logError(`Error monitoring transaction: ${signature}`, error);
      // Don't mark as failed - will be retried in periodic checks
    }
  }
  
  /**
   * Verify transaction on blockchain and process if confirmed
   */
  async _verifyAndProcessTransaction(signature, amount) {
    try {
      this._log(`Verifying transaction status: ${signature}`);
      
      // First check if it's already processed (prevent double processing)
      try {
        const txDoc = await getDoc(doc(this.db, 'solTransactions', signature));
        if (txDoc.exists()) {
          const status = txDoc.data().status;
          if (status === 'PROCESSED') {
            this._log(`Transaction already processed: ${signature}`);
            this._removeFromPending(signature);
            return true;
          } else if (status === 'FAILED') {
            this._log(`Transaction previously failed: ${signature}`);
            this._removeFromPending(signature);
            return false;
          }
        }
      } catch (dbError) {
        this._logError(`Error checking transaction status in Firestore: ${signature}`, dbError);
        // Continue to check blockchain since Firestore might be having issues
      }
      
      // Check directly on blockchain 
      const status = await this.connection.getSignatureStatus(
        signature,
        { searchTransactionHistory: true }
      );
      
      if (!status || !status.value) {
        this._log(`Transaction not found on chain: ${signature}`);
        return false;
      }
      
      if (status.value?.err) {
        this._logError(`Transaction failed on chain: ${signature}`, status.value.err);
        await this._markTransactionFailed(signature, status.value.err);
        return false;
      }
      
      // Check if confirmed with required commitment level
      if (status.value?.confirmationStatus === this.finalCommitment || 
          status.value?.confirmationStatus === 'processed') {
        this._log(`Transaction confirmed on chain: ${signature} with status ${status.value.confirmationStatus}`);
        
        // Additional verification: fetch transaction detail to verify the amount
        try {
          const txDetail = await this.connection.getTransaction(signature, {
            commitment: this.finalCommitment
          });
          
          if (txDetail) {
            this._log(`Transaction details fetched for: ${signature}`);
            await this._processTransaction(signature, amount);
            return true;
          } else {
            this._log(`Couldn't fetch transaction details for: ${signature}`);
            return false;
          }
        } catch (detailError) {
          this._logError(`Error fetching transaction details: ${signature}`, detailError);
          return false;
        }
      } else {
        this._log(`Transaction not yet finalized: ${signature} (status: ${status.value?.confirmationStatus})`);
        return false;
      }
    } catch (error) {
      this._logError(`Error verifying transaction: ${signature}`, error);
      return false;
    }
  }
  
  /**
   * Process a confirmed transaction and award pong credits
   */
  async _processTransaction(signature, amount) {
    this._log(`Processing transaction to award credits: ${signature}`);
    
    try {
      // Use a retry mechanism with exponential backoff for Firestore operations
      const MAX_RETRIES = 3;
      
      let success = false;
      let retryCount = 0;
      let lastError = null;
      
      while (!success && retryCount < MAX_RETRIES) {
        try {
          // First check if already processed (again, to be absolutely sure)
          const txDoc = await getDoc(doc(this.db, 'solTransactions', signature));
          if (txDoc.exists() && txDoc.data().status === 'PROCESSED') {
            this._log(`Transaction already processed (double-check): ${signature}`);
            this._removeFromPending(signature);
            return true;
          }
          
          // Calculate credits
          const pongCredits = Math.floor(amount * 100);
          
          // Get user document
          const userAddress = this.wallet.publicKey.toString();
          this._log(`Getting user document for: ${userAddress}`);
          
          const userDoc = doc(this.db, 'users', userAddress);
          const userSnapshot = await getDoc(userDoc);
          
          // Create user if doesn't exist
          if (!userSnapshot.exists()) {
            this._log(`Creating new user document for: ${userAddress}`);
            await setDoc(userDoc, {
              walletAddress: userAddress,
              pongCredits: 0,
              createdAt: new Date().toISOString()
            });
          }
          
          // Get current credits
          const userData = userSnapshot.exists() ? userSnapshot.data() : { pongCredits: 0 };
          const currentCredits = userData.pongCredits || 0;
          
          // Update user's credits
          this._log(`Updating user credits: ${userAddress} (+${pongCredits})`);
          await updateDoc(userDoc, {
            pongCredits: currentCredits + pongCredits,
            updatedAt: new Date().toISOString()
          });
          
          // Mark transaction as processed
          this._log(`Marking transaction as processed: ${signature}`);
          await updateDoc(doc(this.db, 'solTransactions', signature), {
            status: 'PROCESSED',
            processedAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          });
          
          this._log(`Successfully processed transaction: ${signature} - Awarded ${pongCredits} credits`);
          
          // Remove from pending list
          this._removeFromPending(signature);
          
          // Trigger UI updates
          if (typeof window.updatePongCreditsUI === 'function') {
            window.updatePongCreditsUI(currentCredits + pongCredits);
          }
          
          // Dispatch event for components to listen to
          const event = new CustomEvent('pongCreditsUpdated', {
            detail: { 
              credits: currentCredits + pongCredits,
              added: pongCredits,
              signature
            }
          });
          window.dispatchEvent(event);
          
          // Also make a server request to ensure PostgreSQL is updated as well
          try {
            // Synchronize with PostgreSQL database
            fetch('/api/credit-transaction', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                walletAddress: userAddress,
                amount,
                pongCredits,
                transactionSignature: signature,
                status: 'completed'
              })
            })
            .then(response => {
              if (!response.ok) {
                console.error(`Server transaction recording failed: ${response.statusText}`);
              } else {
                this._log('Transaction also recorded in server database');
              }
            })
            .catch(serverError => {
              console.error('Error recording transaction in server:', serverError);
            });
          } catch (serverError) {
            console.error('Error synchronizing with server:', serverError);
            // Continue anyway - Firebase update was successful
          }
          
          success = true;
          return true;
        } catch (processError) {
          lastError = processError;
          retryCount++;
          
          if (retryCount < MAX_RETRIES) {
            // Exponential backoff
            const backoffMs = Math.pow(2, retryCount) * 1000;
            this._log(`Retrying transaction processing in ${backoffMs}ms: ${signature} (attempt ${retryCount})`);
            await new Promise(resolve => setTimeout(resolve, backoffMs));
          }
        }
      }
      
      if (!success) {
        this._logError(`Failed to process transaction after ${MAX_RETRIES} attempts: ${signature}`, lastError);
        return false;
      }
    } catch (error) {
      this._logError(`Error processing transaction: ${signature}`, error);
      return false;
    }
  }
  
  /**
   * Mark a transaction as failed
   */
  async _markTransactionFailed(signature, error) {
    this._log(`Marking transaction as failed: ${signature}`);
    
    try {
      await updateDoc(doc(this.db, 'solTransactions', signature), {
        status: 'FAILED',
        error: typeof error === 'object' ? JSON.stringify(error) : String(error),
        updatedAt: new Date().toISOString()
      });
      
      this._removeFromPending(signature);
      
      // Dispatch event for failed transaction
      const event = new CustomEvent('transactionFailed', {
        detail: { 
          signature,
          error: typeof error === 'object' ? JSON.stringify(error) : String(error)
        }
      });
      window.dispatchEvent(event);
    } catch (err) {
      this._logError(`Error marking transaction as failed: ${signature}`, err);
    }
  }
  
  /**
   * Remove transaction from pending list
   */
  _removeFromPending(signature) {
    this.pendingTransactions = this.pendingTransactions.filter(tx => tx.signature !== signature);
    this._saveToStorage();
  }
  
  /**
   * Check database for any pending transactions
   */
  async _checkDatabaseTransactions() {
    if (!this.wallet || !this.wallet.publicKey) {
      this._log("Wallet not connected, skipping database transaction check");
      return;
    }
    
    const userAddress = this.wallet.publicKey.toString();
    this._log(`Checking database for pending transactions for: ${userAddress}`);
    
    try {
      // Query for pending transactions for this user
      const q = query(
        collection(this.db, 'solTransactions'),
        where('walletAddress', '==', userAddress),
        where('status', 'in', ['PENDING', 'CONFIRMING'])
      );
      
      const querySnapshot = await getDocs(q);
      this._log(`Found ${querySnapshot.size} pending transactions in database`);
      
      // Process each transaction
      const processPromises = [];
      
      for (const docSnapshot of querySnapshot.docs) {
        const tx = docSnapshot.data();
        
        // Skip transactions we already have in memory
        const alreadyTracking = this.pendingTransactions.some(p => p.signature === tx.signature);
        
        if (!alreadyTracking) {
          this._log(`Adding database transaction to tracking: ${tx.signature}`);
          
          // Add to pending list
          this.pendingTransactions.push({
            signature: tx.signature,
            amount: Number(tx.amount),
            pongCredits: tx.pongCredits,
            timestamp: Date.now()
          });
          this._saveToStorage();
        }
        
        // Process it
        processPromises.push(this._verifyAndProcessTransaction(tx.signature, tx.amount));
      }
      
      // Wait for all to complete
      await Promise.allSettled(processPromises);
    } catch (error) {
      this._logError("Error checking database transactions", error);
    }
  }
  
  /**
   * Get all pending transactions for UI display
   */
  getPendingTransactions() {
    return [...this.pendingTransactions];
  }
  
  /**
   * Cleanup resources when component unmounts
   */
  cleanup() {
    if (this.checkingInterval) {
      clearInterval(this.checkingInterval);
    }
  }
}

export default TransactionManager;