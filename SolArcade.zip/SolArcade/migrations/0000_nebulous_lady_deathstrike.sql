CREATE TABLE "transactions" (
	"id" serial PRIMARY KEY NOT NULL,
	"wallet_address" text NOT NULL,
	"amount" numeric(10, 4) NOT NULL,
	"status" text NOT NULL,
	"timestamp" text NOT NULL,
	"pong_credits" integer DEFAULT 0 NOT NULL,
	"transaction_signature" text,
	"pre_submission_id" text,
	"expected_credits" integer,
	"processing_attempts" integer DEFAULT 0,
	"last_processing_timestamp" text
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" serial PRIMARY KEY NOT NULL,
	"wallet_address" text NOT NULL,
	"pong_credits" integer DEFAULT 0 NOT NULL,
	"last_updated" text NOT NULL,
	CONSTRAINT "users_wallet_address_unique" UNIQUE("wallet_address")
);
